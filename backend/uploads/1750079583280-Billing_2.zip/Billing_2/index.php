<?php
$pageTitle = "Sales Dashboard";
$pageScripts = [
    "js/dashboard.js"
];
include 'includes/header.php';
include 'includes/sidebar.php';
?>

<main class="main-content">
    <h2>Sales Dashboard</h2>
    
    <!-- Quick Stats Row -->
    <div class="dashboard-stats">
        <div class="stat-card">
            <h4>Today's Sales</h4>
            <div class="stat-value">
                <span id="todaySales">₹0.00</span>
            </div>
            <div class="stat-subtitle">
                <span id="todayOrders">0 orders</span>
            </div>
        </div>
        <div class="stat-card">
            <h4>This Month</h4>
            <div class="stat-value">
                <span id="monthSales">₹0.00</span>
            </div>
            <div class="stat-subtitle">
                <span id="monthOrders">0 orders</span>
            </div>
        </div>
        <div class="stat-card">
            <h4>Total Products</h4>
            <div class="stat-value">
                <span id="totalProducts">0</span>
            </div>
            <div class="stat-subtitle warning">
                <span id="lowStock">0 out of stock</span>
            </div>
        </div>
        <div class="stat-card">
            <h4>Average Order Value</h4>
            <div class="stat-value">
                <span id="avgOrderValue">₹0.00</span>
            </div>
            <div class="stat-subtitle">This month</div>
        </div>
    </div>

    <!-- Charts Row -->
    <div class="dashboard-charts">
        <!-- Daily Sales Chart -->
        <div class="chart-container">
            <div class="chart-header">
                <h3>Daily Sales Comparison</h3>
                
            </div>
            <div class="chart-content">
                <canvas id="monthlySalesChart"></canvas>
            </div>
        </div>

        <!-- Top Products Chart -->
        <div class="chart-container">
            <div class="chart-header">
                <h3>Top Selling Products</h3>
              
            </div>
            <div class="chart-content">
                <canvas id="topProductsChart"></canvas>
            </div>
        </div>
    </div>

    <!-- Recent Sales Table -->
    <div class="recent-sales">
        <div class="section-header">
            <h3>Recent Sales</h3>
             
    
              
        </div>
        <div class="table-container">
            <table id="recentSalesTable">
                <thead>
                    <tr>
                        <th>Date & Time</th>
                        <th>Bill Number</th>
                        <th>Product</th>
                        <th>Quantity</th>
                        <th>Unit Price</th>
                        <th>Total Amount</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>
    </div>
</main>

<?php include 'includes/footer.php'; ?> 