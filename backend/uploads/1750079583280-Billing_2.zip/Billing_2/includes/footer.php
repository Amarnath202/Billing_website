    </div> <!-- End of layout div -->
    <?php if (isset($pageScripts)) { 
        foreach($pageScripts as $script) {
            echo "<script src=\"$script\"></script>\n";
        }
    } ?>
</body>
</html> 