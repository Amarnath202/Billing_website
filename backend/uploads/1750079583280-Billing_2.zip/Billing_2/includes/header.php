<?php
// Get the directory name of the current script
$current_dir = dirname($_SERVER['SCRIPT_NAME']);
$base_path = rtrim($current_dir, '/');

// Handle subdirectory installations
if (basename($base_path) === 'includes') {
    $base_path = dirname($base_path);
}

// Initialize pageScripts if not set
if (!isset($pageScripts)) {
    $pageScripts = [];
}

// Initialize pageTitle if not set
if (!isset($pageTitle)) {
    $pageTitle = 'Dashboard';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="base-url" content="<?php echo $base_path; ?>">
    <title><?php echo $pageTitle; ?> - Billing System</title>
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet" href="<?php echo $base_path; ?>/css/main.css" onload="console.log('CSS loaded successfully')" onerror="console.log('Failed to load CSS')">
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Define global variables
        window.BASE_URL = '<?php echo $base_path; ?>';
    </script>
    <script src="<?php echo $base_path; ?>/js/time.js" defer></script>
    <?php
    // Include page-specific scripts
    foreach ($pageScripts as $script) {
        // Convert relative path to absolute if needed
        if (strpos($script, 'http') !== 0 && strpos($script, '/') !== 0) {
            $script = $base_path . '/' . ltrim($script, './');
        }
        echo "<script src=\"{$script}\" defer></script>\n";
    }
    ?>
    <!-- Fallback styles in case main.css fails to load -->
    <style>
        /* Basic fallback styles */
        body { font-family: sans-serif; margin: 0; padding: 20px; }
        .layout { max-width: 1200px; margin: 0 auto; }
        h1, h2 { color: #FF9F43; }
    </style>
</head>
<body>
    <div class="layout"> 