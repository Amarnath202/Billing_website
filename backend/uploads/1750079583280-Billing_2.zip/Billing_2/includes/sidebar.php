<?php
$current_page = basename($_SERVER['PHP_SELF'], '.php');
?>
<aside class="sidebar">
    <div class="sidebar-header">
        <h1>Billing System</h1>
    </div>
    <nav class="sidebar-nav">
        <a href="index.php" class="nav-link <?php echo $current_page === 'index' ? 'active' : ''; ?>">
            <span class="icon">📊</span>
            Dashboard
        </a>
        <a href="billing.php" class="nav-link <?php echo $current_page === 'billing' ? 'active' : ''; ?>">
            <span class="icon">💰</span>
            Billing
        </a>
        <a href="products.php" class="nav-link <?php echo $current_page === 'products' ? 'active' : ''; ?>">
            <span class="icon">📦</span>
            Products
        </a>
        <a href="suppliers.php" class="nav-link <?php echo $current_page === 'suppliers' ? 'active' : ''; ?>">
            <span class="icon">🏢</span>
            Suppliers
        </a>
        <a href="payments.php" class="nav-link <?php echo $current_page === 'payments' ? 'active' : ''; ?>">
            <span class="icon">💳</span>
            Payment
        </a>
        <a href="sales-history.php" class="nav-link <?php echo $current_page === 'sales-history' ? 'active' : ''; ?>">
            <span class="icon">📜</span>
            Sales History
        </a>
    </nav>
    <div class="live-time">
        <div class="time-icon">⏰</div>
        <div class="time-content">
            <div class="time-label">Current Time</div>
            <div id="currentTime" class="time-value"></div>
        </div>
    </div>
</aside> 