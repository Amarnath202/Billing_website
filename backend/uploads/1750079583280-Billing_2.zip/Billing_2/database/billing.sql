-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 09, 2025 at 07:25 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `billing`
--

-- --------------------------------------------------------

--
-- Table structure for table `account_payable`
--

CREATE TABLE `account_payable` (
  `id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `invoice_number` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `due_date` date NOT NULL,
  `payment_date` date DEFAULT NULL,
  `status` enum('pending','paid','overdue') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `account_payable`
--

INSERT INTO `account_payable` (`id`, `supplier_id`, `invoice_number`, `description`, `amount`, `due_date`, `payment_date`, `status`, `created_at`, `updated_at`) VALUES
(4, 2, '1235', '', 10000.00, '2025-06-30', '2025-06-30', 'pending', '2025-06-04 05:57:09', '2025-06-04 05:57:09'),
(5, 4, '02', '', 2000.00, '2025-06-30', '2025-06-29', 'pending', '2025-06-04 07:14:12', '2025-06-04 07:14:12'),
(6, 2, '02', '', 200.00, '2025-06-05', NULL, 'overdue', '2025-06-04 09:22:20', '2025-06-05 09:02:24'),
(7, 4, '022', '', 200.00, '2025-06-14', NULL, 'pending', '2025-06-04 11:41:50', '2025-06-04 11:41:50'),
(8, 4, 'INV-2', NULL, 20.00, '2025-07-05', NULL, 'pending', '2025-06-05 11:05:14', '2025-06-05 11:05:14');

-- --------------------------------------------------------

--
-- Table structure for table `account_receivable`
--

CREATE TABLE `account_receivable` (
  `id` int(11) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `invoice_number` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `due_date` date NOT NULL,
  `payment_date` date DEFAULT NULL,
  `status` enum('pending','paid','overdue') DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `account_receivable`
--

INSERT INTO `account_receivable` (`id`, `supplier_id`, `invoice_number`, `description`, `amount`, `due_date`, `payment_date`, `status`, `created_at`, `updated_at`) VALUES
(1, 2, '2000', '', 200000.00, '2025-06-05', NULL, 'overdue', '2025-06-04 03:56:28', '2025-06-05 09:02:24');

-- --------------------------------------------------------

--
-- Table structure for table `inventory`
--

CREATE TABLE `inventory` (
  `id` int(11) NOT NULL,
  `item_code` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `brand` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `purchase_price` decimal(10,2) NOT NULL,
  `sales_price` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment_transactions`
--

CREATE TABLE `payment_transactions` (
  `id` int(11) NOT NULL,
  `type` enum('cash_hand','cash_bank') NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `amount_paid` decimal(10,2) NOT NULL,
  `transaction_date` date NOT NULL,
  `status` enum('pending','partial','paid') NOT NULL,
  `notes` text DEFAULT NULL,
  `bank_account` varchar(50) DEFAULT NULL,
  `reference_number` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `payment_transactions`
--

INSERT INTO `payment_transactions` (`id`, `type`, `supplier_id`, `product_id`, `quantity`, `amount_paid`, `transaction_date`, `status`, `notes`, `bank_account`, `reference_number`, `created_at`, `updated_at`) VALUES
(1, 'cash_hand', 2, 3, 1, 10.00, '2025-06-05', 'partial', '', NULL, NULL, '2025-06-05 11:04:21', '2025-06-05 11:04:21');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `item_code` varchar(50) NOT NULL,
  `name` varchar(255) NOT NULL,
  `brand` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `purchase_price` decimal(10,2) NOT NULL,
  `sales_price` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `item_code`, `name`, `brand`, `description`, `purchase_price`, `sales_price`, `quantity`, `created_at`, `updated_at`) VALUES
(1, '1234', 'shampoo', 'ccc', '25g', 0.50, 2.00, 289, '2025-06-02 11:06:47', '2025-06-02 13:09:35'),
(2, '234', 'soap', 'aaa', '50g', 8.00, 10.00, 498, '2025-06-02 11:21:04', '2025-06-02 11:21:34'),
(3, '12345', 'aaah', 'aaaa', 'kkk', 12.00, 20.00, 273, '2025-06-02 13:14:02', '2025-06-05 11:05:14'),
(4, '01', 'aaa', 'aaaa', '', 50.00, 80.00, 2011, '2025-06-03 07:33:47', '2025-06-04 10:02:35'),
(7, '02', 'bbb', 'bbbb', 'b', 20.00, 200.00, 198, '2025-06-04 04:22:35', '2025-06-04 10:12:53'),
(8, '03', 'ccc', 'nnn', '', 6.00, 20.00, 160, '2025-06-04 04:30:47', '2025-06-04 10:12:53');

-- --------------------------------------------------------

--
-- Table structure for table `purchases`
--

CREATE TABLE `purchases` (
  `id` int(11) NOT NULL,
  `purchase_date` date NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price_per_unit` decimal(10,2) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `purchases`
--

INSERT INTO `purchases` (`id`, `purchase_date`, `supplier_id`, `item_id`, `quantity`, `price_per_unit`, `total_amount`, `notes`, `created_at`) VALUES
(1, '2025-06-04', 2, 3, 20, 600.00, 12000.00, '', '2025-06-04 07:08:45'),
(2, '2025-06-04', 2, 4, 20, 30.00, 600.00, '', '2025-06-04 07:09:08'),
(3, '2025-06-04', 4, 4, 20, 300.00, 6000.00, '', '2025-06-04 07:09:27');

--
-- Triggers `purchases`
--
DELIMITER $$
CREATE TRIGGER `before_purchase_insert` BEFORE INSERT ON `purchases` FOR EACH ROW SET NEW.total_amount = NEW.quantity * NEW.price_per_unit
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `before_purchase_update` BEFORE UPDATE ON `purchases` FOR EACH ROW SET NEW.total_amount = NEW.quantity * NEW.price_per_unit
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `id` int(11) NOT NULL,
  `bill_number` int(11) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `sale_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` tinyint(4) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `bill_number`, `product_id`, `quantity`, `unit_price`, `total_amount`, `sale_date`, `status`) VALUES
(1, 0, 3, 1, 20.00, 20.00, '2025-06-04 05:38:21', 1),
(2, 0, 3, 20, 20.00, 400.00, '2025-06-04 06:31:23', 1),
(3, 0, 8, 30, 20.00, 600.00, '2025-06-04 06:31:23', 1),
(4, 0, 3, 20, 20.00, 400.00, '2025-06-04 09:04:19', 1),
(5, 0, 4, 20, 80.00, 1600.00, '2025-06-04 09:22:48', 1),
(6, 0, 3, 2, 20.00, 40.00, '2025-06-04 09:47:15', 1),
(7, 0, 4, 5, 80.00, 400.00, '2025-06-04 10:02:35', 1),
(8, 0, 7, 2, 200.00, 400.00, '2025-06-04 10:12:53', 1),
(9, 0, 8, 10, 20.00, 200.00, '2025-06-04 10:12:53', 1);

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `street` varchar(255) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`id`, `name`, `phone`, `email`, `street`, `city`, `state`, `created_at`, `updated_at`) VALUES
(2, 'aaa', '123', 'aaa@gmail.com', 'covai', 'covai', 'tam', '2025-06-03 09:41:22', '2025-06-03 09:41:22'),
(4, 'bbb', '12345', 'aaaa@gmail.com', 'covai', 'covai', 'tam', '2025-06-04 07:05:27', '2025-06-04 07:05:27');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account_payable`
--
ALTER TABLE `account_payable`
  ADD PRIMARY KEY (`id`),
  ADD KEY `supplier_id` (`supplier_id`);

--
-- Indexes for table `account_receivable`
--
ALTER TABLE `account_receivable`
  ADD PRIMARY KEY (`id`),
  ADD KEY `supplier_id` (`supplier_id`);

--
-- Indexes for table `inventory`
--
ALTER TABLE `inventory`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `item_code` (`item_code`);

--
-- Indexes for table `payment_transactions`
--
ALTER TABLE `payment_transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `supplier_id` (`supplier_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `item_code` (`item_code`);

--
-- Indexes for table `purchases`
--
ALTER TABLE `purchases`
  ADD PRIMARY KEY (`id`),
  ADD KEY `supplier_id` (`supplier_id`),
  ADD KEY `item_id` (`item_id`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_sales_date` (`sale_date`),
  ADD KEY `idx_sales_product` (`product_id`),
  ADD KEY `idx_sales_status` (`status`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account_payable`
--
ALTER TABLE `account_payable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `account_receivable`
--
ALTER TABLE `account_receivable`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `inventory`
--
ALTER TABLE `inventory`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment_transactions`
--
ALTER TABLE `payment_transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `purchases`
--
ALTER TABLE `purchases`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `account_payable`
--
ALTER TABLE `account_payable`
  ADD CONSTRAINT `account_payable_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `account_receivable`
--
ALTER TABLE `account_receivable`
  ADD CONSTRAINT `account_receivable_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `payment_transactions`
--
ALTER TABLE `payment_transactions`
  ADD CONSTRAINT `payment_transactions_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`id`),
  ADD CONSTRAINT `payment_transactions_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `purchases`
--
ALTER TABLE `purchases`
  ADD CONSTRAINT `purchases_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `purchases_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sales`
--
ALTER TABLE `sales`
  ADD CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
