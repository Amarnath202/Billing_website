<?php
$pageTitle = "Payment Management";
$pageScripts = [
    "../js/payments.js"
];
include 'includes/header.php';
include 'includes/sidebar.php';
?>

<main class="main-content">
    <div class="section-header">
        <h2>Payment Management</h2>
    </div>
    
    <!-- Payment Sub-tabs -->
    <div class="payment-tabs">
        <button class="payment-tab-btn active" data-subtab="cash-hand">Cash in Hand</button>
        <button class="payment-tab-btn" data-subtab="cash-bank">Cash in Bank</button>
    </div>

    <!-- Cash in Hand Tab -->
    <div class="payment-tab-content active" id="cash-hand">
        <div class="section-header">
            <h3>Cash in Hand Transactions</h3>
            <div class="search-container">
                <input type="text" id="cashHandSearch" placeholder="Search by supplier or product..." class="search-input">
            </div>
            <button id="showAddCashHandForm" class="add-btn">
                <span class="icon">➕</span> Add New Transaction
            </button>
        </div>

        <!-- Cash in Hand Table -->
        <div class="table-container">
            <table id="cashHandTable">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Supplier Name</th>
                        <th>Product Name</th>
                        <th>Quantity</th>
                        <th>Total Amount</th>
                        <th>Amount Paid</th>
                        <th>Balance</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>

        <!-- Add Cash Hand Transaction Form -->
        <div id="cashHandFormContainer" class="form-container" style="display: none;">
            <form id="addCashHandForm" class="cash-hand-form">
                <div class="form-header">
                    <h3>Add New Cash Transaction</h3>
                    <button type="button" class="close-btn" onclick="closeCashHandForm()">×</button>
                </div>
                <input type="hidden" id="cashHandId" value="">
                <div class="form-row">
                    <div class="form-group">
                        <label for="cashHandSupplier">Supplier</label>
                        <select id="cashHandSupplier" required>
                            <option value="">Select Supplier</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="cashHandProduct">Product</label>
                        <select id="cashHandProduct" required>
                            <option value="">Select Product</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="cashHandQuantity">Quantity</label>
                        <input type="number" id="cashHandQuantity" min="1" required>
                    </div>
                    <div class="form-group">
                        <label for="cashHandAmount">Amount Paid</label>
                        <input type="number" id="cashHandAmount" step="0.01" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="cashHandDate">Transaction Date</label>
                        <input type="date" id="cashHandDate" required>
                    </div>
                    <div class="form-group">
                        <label for="cashHandStatus">Status</label>
                        <select id="cashHandStatus" required>
                            <option value="pending">Pending</option>
                            <option value="partial">Partial</option>
                            <option value="paid">Paid</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group full-width">
                        <label for="cashHandNotes">Notes</label>
                        <textarea id="cashHandNotes" placeholder="Enter any additional notes"></textarea>
                    </div>
                </div>
                <div class="form-actions">
                    <button type="button" id="cancelCashHandEdit" style="display: none;" onclick="closeCashHandForm()">Cancel</button>
                    <button type="submit" id="submitCashHandButton">Add Transaction</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Cash in Bank Tab -->
    <div class="payment-tab-content" id="cash-bank">
        <div class="section-header">
            <h3>Cash in Bank Transactions</h3>
            <div class="search-container">
                <input type="text" id="cashBankSearch" placeholder="Search by supplier or product..." class="search-input">
            </div>
            <button id="showAddCashBankForm" class="add-btn">
                <span class="icon">➕</span> Add New Transaction
            </button>
        </div>

        <!-- Cash in Bank Table -->
        <div class="table-container">
            <table id="cashBankTable">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Supplier Name</th>
                        <th>Product Name</th>
                        <th>Quantity</th>
                        <th>Total Amount</th>
                        <th>Amount Paid</th>
                        <th>Balance</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>

        <!-- Add Cash Bank Transaction Form -->
        <div id="cashBankFormContainer" class="form-container" style="display: none;">
            <form id="addCashBankForm" class="cash-bank-form">
                <div class="form-header">
                    <h3>Add New Bank Transaction</h3>
                    <button type="button" class="close-btn" onclick="closeCashBankForm()">×</button>
                </div>
                <input type="hidden" id="cashBankId" value="">
                <div class="form-row">
                    <div class="form-group">
                        <label for="cashBankSupplier">Supplier</label>
                        <select id="cashBankSupplier" required>
                            <option value="">Select Supplier</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="cashBankProduct">Product</label>
                        <select id="cashBankProduct" required>
                            <option value="">Select Product</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="cashBankQuantity">Quantity</label>
                        <input type="number" id="cashBankQuantity" min="1" required>
                    </div>
                    <div class="form-group">
                        <label for="cashBankAmount">Amount Paid</label>
                        <input type="number" id="cashBankAmount" step="0.01" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="cashBankDate">Transaction Date</label>
                        <input type="date" id="cashBankDate" required>
                    </div>
                    <div class="form-group">
                        <label for="cashBankStatus">Status</label>
                        <select id="cashBankStatus" required>
                            <option value="pending">Pending</option>
                            <option value="partial">Partial</option>
                            <option value="paid">Paid</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="cashBankAccount">Bank Account</label>
                        <input type="text" id="cashBankAccount" required>
                    </div>
                    <div class="form-group">
                        <label for="cashBankReference">Reference Number</label>
                        <input type="text" id="cashBankReference" required>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group full-width">
                        <label for="cashBankNotes">Notes</label>
                        <textarea id="cashBankNotes" placeholder="Enter any additional notes"></textarea>
                    </div>
                </div>
                <div class="form-actions">
                    <button type="button" id="cancelCashBankEdit" style="display: none;" onclick="closeCashBankForm()">Cancel</button>
                    <button type="submit" id="submitCashBankButton">Add Transaction</button>
                </div>
            </form>
        </div>
    </div>
</main>

<?php include 'includes/footer.php'; ?> 