<?php
$pageTitle = "Supplier Management";
$pageScripts = [
    "js/suppliers.js"
];
include 'includes/header.php';
include 'includes/sidebar.php';
?>

<div class="content-wrapper">
    <div class="position-relative overflow-auto w-full">
        <div class="tab-navigation">
            <button class="tab-button active" data-tab="supplier-info">Supplier Info</button>
            <button class="tab-button" data-tab="purchases">Purchases</button>
            <button class="tab-button" data-tab="account-payable">Account Payable</button>
            <button class="tab-button" data-tab="account-receivable">Account Receivable</button>
        </div>

        <!-- Supplier Info Tab -->
        <div class="tab-content active" id="supplier-info">
            <div class="section-title">Supplier Management</div>
            <button class="add-button" id="addSupplierBtn">
                <i class="fas fa-plus"></i> Add New Supplier
            </button>
            
            <div class="table-container">
                <table class="data-table" id="supplierTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>NAME</th>
                            <th>PHONE</th>
                            <th>EMAIL</th>
                            <th>ADDRESS</th>
                            <th>ACTIONS</th>
                        </tr>
                    </thead>
                    <tbody id="supplierTableBody">
                        <!-- Supplier data will be loaded here -->
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Purchases Tab -->
        <div class="tab-content" id="purchases">
            <div class="section-title">Purchase Management</div>
            <div class="search-container">
                <input type="text" id="supplierSearch" placeholder="Search by supplier name...">
            </div>
            <button class="add-button" id="addPurchaseBtn">
                <i class="fas fa-plus"></i> Add New Purchase
            </button>
            
            <div class="table-container">
                <table class="data-table" id="purchaseTable">
                    <thead>
                        <tr>
                            <th>DATE</th>
                            <th>SUPPLIER</th>
                            <th>PRODUCT</th>
                            <th>QUANTITY</th>
                            <th>RATE/UNIT</th>
                            <th>TOTAL</th>
                            <th>ACTIONS</th>
                        </tr>
                    </thead>
                    <tbody id="purchaseTableBody">
                        <!-- Purchase data will be loaded here -->
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Account Payable Tab -->
        <div class="tab-content" id="account-payable">
            <div class="section-title">Account Payable</div>
            <button class="add-button" id="addPayableBtn">
                <i class="fas fa-plus"></i> Add New Payable
            </button>
            <div class="table-container">
                <table class="data-table" id="payableTable">
                    <thead>
                        <tr>
                            <th>SUPPLIER</th>
                            <th>INVOICE #</th>
                            <th>DESCRIPTION</th>
                            <th>AMOUNT</th>
                            <th>DUE DATE</th>
                            <th>PAYMENT DATE</th>
                            <th>STATUS</th>
                            <th>ACTIONS</th>
                        </tr>
                    </thead>
                    <tbody id="payableTableBody">
                        <!-- Payable data will be loaded here -->
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Account Receivable Tab -->
        <div class="tab-content" id="account-receivable">
            <div class="section-title">Account Receivable</div>
            <button class="add-button" id="addReceivableBtn">
                <i class="fas fa-plus"></i> Add New Receivable
            </button>
            <div class="table-container">
                <table class="data-table" id="receivableTable">
                    <thead>
                        <tr>
                            <th>SUPPLIER</th>
                            <th>INVOICE #</th>
                            <th>DESCRIPTION</th>
                            <th>AMOUNT</th>
                            <th>DUE DATE</th>
                            <th>PAYMENT DATE</th>
                            <th>STATUS</th>
                            <th>ACTIONS</th>
                        </tr>
                    </thead>
                    <tbody id="receivableTableBody">
                        <!-- Receivable data will be loaded here -->
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Add/Edit Supplier Modal -->
<div id="supplierModal" class="modal">
    <div class="modal-content">
        <h2 id="modalTitle">Add New Supplier</h2>
        <form id="supplierForm">
            <input type="hidden" id="supplierId" name="id">
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required>
            </div>
            <div class="form-group">
                <label for="phone">Phone:</label>
                <input type="text" id="phone" name="phone" required>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email">
            </div>
            <div class="form-group">
                <label for="address">Street Address:</label>
                <input type="text" id="address" name="address" required>
            </div>
            <div class="form-group">
                <label for="city">City:</label>
                <input type="text" id="city" name="city" required>
            </div>
            <div class="form-group">
                <label for="state">State:</label>
                <input type="text" id="state" name="state" required>
            </div>
            <div class="form-actions">
                <button type="submit" class="save-btn">Save</button>
                <button type="button" class="cancel-btn">Cancel</button>
            </div>
        </form>
    </div>
</div>

<!-- Add/Edit Purchase Modal -->
<div id="purchaseModal" class="modal">
    <div class="modal-content">
        <h2 id="purchaseModalTitle">Add New Purchase</h2>
        <form id="purchaseForm">
            <input type="hidden" id="purchaseId" name="id">
            <div class="form-group">
                <label for="purchaseDate">Date:</label>
                <input type="date" id="purchaseDate" name="date" required>
            </div>
            <div class="form-group">
                <label for="supplierSelect">Supplier:</label>
                <select id="supplierSelect" name="supplier_id" required>
                    <option value="">Select Supplier</option>
                </select>
            </div>
            <div class="form-group">
                <label for="productSelect">Product:</label>
                <select id="productSelect" name="product" required>
                    <option value="">Select Product</option>
                </select>
            </div>
            <div class="form-group">
                <label for="quantity">Quantity:</label>
                <input type="number" id="quantity" name="quantity" min="1" required>
            </div>
            <div class="form-group">
                <label for="rate">Rate/Unit:</label>
                <input type="number" id="rate" name="rate" step="0.01" min="0.01" required>
            </div>
            <div class="form-actions">
                <button type="submit" class="save-btn">Save</button>
                <button type="button" class="cancel-btn">Cancel</button>
            </div>
        </form>
    </div>
</div>

<!-- Add/Edit Payable Modal -->
<div id="payableModal" class="modal">
    <div class="modal-content">
        <h2 id="payableModalTitle">Add New Payable</h2>
        <form id="payableForm">
            <input type="hidden" name="id">
            <div class="form-group">
                <label for="payableSupplier">Supplier:</label>
                <select name="supplier_id" id="payableSupplier" required>
                    <!-- Suppliers will be loaded here -->
                </select>
            </div>
            <div class="form-group">
                <label for="payableInvoice">Invoice Number:</label>
                <input type="text" id="payableInvoice" name="invoice_number" required>
            </div>
            <div class="form-group">
                <label for="payableDescription">Description:</label>
                <textarea id="payableDescription" name="description" rows="3"></textarea>
            </div>
            <div class="form-group">
                <label for="payableAmount">Amount:</label>
                <input type="number" id="payableAmount" name="amount" step="0.01" required>
            </div>
            <div class="form-group">
                <label for="payableDueDate">Due Date:</label>
                <input type="date" id="payableDueDate" name="due_date" required>
            </div>
            <div class="form-group">
                <label for="payablePaymentDate">Payment Date:</label>
                <input type="date" id="payablePaymentDate" name="payment_date">
            </div>
            <div class="form-group">
                <label for="payableStatus">Status:</label>
                <select id="payableStatus" name="status" required>
                    <option value="pending">Pending</option>
                    <option value="paid">Paid</option>
                    <option value="overdue">Overdue</option>
                </select>
            </div>
            <div class="form-actions">
                <button type="submit" class="save-btn">Save Payable</button>
                <button type="button" class="cancel-btn">Cancel</button>
            </div>
        </form>
    </div>
</div>

<!-- Add/Edit Receivable Modal -->
<div id="receivableModal" class="modal">
    <div class="modal-content">
        <h2 id="receivableModalTitle">Add New Receivable</h2>
        <form id="receivableForm">
            <input type="hidden" name="id">
            <div class="form-group">
                <label for="receivableSupplier">Supplier:</label>
                <select name="supplier_id" id="receivableSupplier" required>
                    <!-- Suppliers will be loaded here -->
                </select>
            </div>
            <div class="form-group">
                <label for="receivableInvoice">Invoice Number:</label>
                <input type="text" id="receivableInvoice" name="invoice_number" required>
            </div>
            <div class="form-group">
                <label for="receivableDescription">Description:</label>
                <textarea id="receivableDescription" name="description" rows="3"></textarea>
            </div>
            <div class="form-group">
                <label for="receivableAmount">Amount:</label>
                <input type="number" id="receivableAmount" name="amount" step="0.01" required>
            </div>
            <div class="form-group">
                <label for="receivableDueDate">Due Date:</label>
                <input type="date" id="receivableDueDate" name="due_date" required>
            </div>
            <div class="form-group">
                <label for="receivablePaymentDate">Payment Date:</label>
                <input type="date" id="receivablePaymentDate" name="payment_date">
            </div>
            <div class="form-group">
                <label for="receivableStatus">Status:</label>
                <select id="receivableStatus" name="status" required>
                    <option value="pending">Pending</option>
                    <option value="received">Received</option>
                    <option value="overdue">Overdue</option>
                </select>
            </div>
            <div class="form-actions">
                <button type="submit" class="save-btn">Save Receivable</button>
                <button type="button" class="cancel-btn">Cancel</button>
            </div>
        </form>
    </div>
</div>

<?php include 'includes/footer.php'; ?> 