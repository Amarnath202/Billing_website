<?php
$pageTitle = "Billing";
include 'includes/header.php';
include 'includes/sidebar.php';
?>

<div class="main-content">
    <div class="billing-section">
        <h2>Billing</h2>
        <form id="billingForm" autocomplete="off">
            <!-- Bill Info Section -->
            <div class="bill-info">
                <div class="form-group">
                    <label for="billNumber">Bill Number</label>
                    <input type="text" id="billNumber" class="form-control" value="BILL-<?php echo time(); ?>-<?php echo rand(10,99); ?>" readonly>
                </div>
                <div class="form-group">
                    <label for="billDate">Date</label>
                    <input type="date" id="billDate" class="form-control" value="<?php echo date('Y-m-d'); ?>" required>
                </div>
            </div>

            <!-- Product Selection Section -->
            <div class="product-selection">
                <div class="form-group">
                    <label for="product">Select Product</label>
                    <select id="product" class="form-control" required>
                        <option value="">Select Product</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="quantity">Quantity</label>
                    <input type="number" id="quantity" class="form-control" min="1" placeholder="Enter quantity" required>
                </div>
                <button type="button" class="add-to-list-btn">Add to List</button>
            </div>

            <!-- Bill Items Table -->
            <div class="bill-container">
                <table id="billItemsTable">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Total</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Items will be added here dynamically -->
                    </tbody>
                </table>
            </div>

            <!-- Bill Summary -->
            <div class="bill-summary">
                <div class="summary-row total">
                    <span>Total:</span>
                    <span id="total">₹0.00</span>
                </div>
            </div>

            <!-- Action Buttons -->
            <div class="action-buttons">
                <button type="submit" class="process-sale-btn">Process Sale</button>
                <button type="button" class="print-bill-btn" disabled>Print Bill</button>
            </div>
        </form>
    </div>
</div>

<script src="js/billing.js"></script>
<?php include 'includes/footer.php'; ?>