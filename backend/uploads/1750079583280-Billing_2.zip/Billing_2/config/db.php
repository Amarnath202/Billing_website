<?php
// Prevent any output before JSON response
error_reporting(E_ALL);
ini_set('display_errors', 0);

// Database configuration
$host = 'localhost';
$dbname = 'billing';
$username = 'root';
$password = '';

// PDO Connection
try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    error_log("PDO Database connection error: " . $e->getMessage());
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode([
        'status' => 'error',
        'message' => 'Database connection error'
    ]);
    exit;
}

// MySQLi Connection
function getDBConnection() {
    global $host, $dbname, $username, $password;
    
    $conn = new mysqli($host, $username, $password, $dbname);
    
    if ($conn->connect_error) {
        error_log("MySQLi Database connection error: " . $conn->connect_error);
        header('HTTP/1.1 500 Internal Server Error');
        echo json_encode([
            'success' => false,
            'message' => 'Database connection error'
        ]);
        exit;
    }
    
    $conn->set_charset("utf8");
    return $conn;
}

// Create tables if they don't exist
try {
    // Create supplier table if not exists
    $pdo->exec("CREATE TABLE IF NOT EXISTS supplier (
        id INT PRIMARY KEY AUTO_INCREMENT,
        name VARCHAR(255) NOT NULL,
        phone VARCHAR(20) NOT NULL,
        email VARCHAR(255),
        street VARCHAR(255) NOT NULL,
        city VARCHAR(100) NOT NULL,
        state VARCHAR(100) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_supplier_name (name)
    )");

    // Create account_payable table if not exists
    $pdo->exec("CREATE TABLE IF NOT EXISTS account_payable (
        id INT PRIMARY KEY AUTO_INCREMENT,
        supplier_id INT NOT NULL,
        invoice_number VARCHAR(50) NOT NULL,
        description TEXT,
        amount DECIMAL(10,2) NOT NULL,
        due_date DATE NOT NULL,
        payment_date DATE,
        status ENUM('pending', 'paid', 'overdue') DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (supplier_id) REFERENCES supplier(id) ON DELETE CASCADE,
        INDEX idx_payable_dates (due_date, payment_date),
        INDEX idx_payable_status (status)
    )");

    // Create account_receivable table if not exists
    $pdo->exec("CREATE TABLE IF NOT EXISTS account_receivable (
        id INT PRIMARY KEY AUTO_INCREMENT,
        supplier_id INT NOT NULL,
        invoice_number VARCHAR(50) NOT NULL,
        description TEXT,
        amount DECIMAL(10,2) NOT NULL,
        due_date DATE NOT NULL,
        payment_date DATE,
        status ENUM('pending', 'paid', 'overdue') DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (supplier_id) REFERENCES supplier(id) ON DELETE CASCADE,
        INDEX idx_receivable_dates (due_date, payment_date),
        INDEX idx_receivable_status (status)
    )");

    // Create products table if not exists
    $pdo->exec("CREATE TABLE IF NOT EXISTS products (
        id INT PRIMARY KEY AUTO_INCREMENT,
        item_code VARCHAR(50) UNIQUE NOT NULL,
        name VARCHAR(255) NOT NULL,
        brand VARCHAR(100) NOT NULL,
        description TEXT,
        purchase_price DECIMAL(10,2) NOT NULL,
        sales_price DECIMAL(10,2) NOT NULL,
        quantity INT NOT NULL DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_product_name (name),
        INDEX idx_product_brand (brand),
        INDEX idx_product_quantity (quantity)
    )");

    // Create payment_transactions table if not exists
    $pdo->exec("CREATE TABLE IF NOT EXISTS payment_transactions (
        id INT PRIMARY KEY AUTO_INCREMENT,
        type ENUM('cash_hand', 'cash_bank') NOT NULL,
        supplier_id INT NOT NULL,
        product_id INT NOT NULL,
        quantity INT NOT NULL,
        amount_paid DECIMAL(10,2) NOT NULL,
        transaction_date DATE NOT NULL,
        status ENUM('pending', 'partial', 'paid') NOT NULL,
        notes TEXT,
        bank_account VARCHAR(50),
        reference_number VARCHAR(50),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (supplier_id) REFERENCES supplier(id),
        FOREIGN KEY (product_id) REFERENCES products(id)
    )");

    // Create sales table if not exists
    $pdo->exec("CREATE TABLE IF NOT EXISTS sales (
        id INT PRIMARY KEY AUTO_INCREMENT,
        product_id INT,
        quantity INT NOT NULL,
        unit_price DECIMAL(10,2) NOT NULL,
        total_amount DECIMAL(10,2) NOT NULL,
        sale_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        status TINYINT DEFAULT 1,
        FOREIGN KEY (product_id) REFERENCES products(id),
        INDEX idx_sales_date (sale_date),
        INDEX idx_sales_product (product_id),
        INDEX idx_sales_status (status)
    )");

    // Add indexes if they don't exist
    try {
        $pdo->exec("ALTER TABLE sales ADD INDEX IF NOT EXISTS idx_sales_date (sale_date)");
        $pdo->exec("ALTER TABLE sales ADD INDEX IF NOT EXISTS idx_sales_product (product_id)");
        $pdo->exec("ALTER TABLE sales ADD INDEX IF NOT EXISTS idx_sales_status (status)");
    } catch (PDOException $e) {
        // Ignore if indexes already exist
        if ($e->getCode() !== '42000') {
            throw $e;
        }
    }

} catch(PDOException $e) {
    error_log("Table creation error: " . $e->getMessage());
    header('HTTP/1.1 500 Internal Server Error');
    echo json_encode([
        'status' => 'error',
        'message' => 'Database setup error'
    ]);
    exit;
}
?> 