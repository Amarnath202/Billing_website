// Payment Tab Management
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM Content Loaded - Payment Tab Management');
    
    // Initialize payment tabs
    const paymentTabs = document.querySelectorAll('.payment-tab-btn');
    const paymentContents = document.querySelectorAll('.payment-tab-content');
    
    console.log('Found payment tabs:', paymentTabs.length);
    console.log('Found payment contents:', paymentContents.length);
    
    paymentTabs.forEach(tab => {
        tab.addEventListener('click', () => {
            console.log('Payment tab clicked:', tab.getAttribute('data-subtab'));
            // Remove active class from all tabs and contents
            paymentTabs.forEach(t => t.classList.remove('active'));
            paymentContents.forEach(c => c.classList.remove('active'));
            
            // Add active class to clicked tab and corresponding content
            tab.classList.add('active');
            const contentId = tab.getAttribute('data-subtab');
            const content = document.getElementById(contentId);
            console.log('Activating content:', contentId, content);
            if (content) {
                content.classList.add('active');
            } else {
                console.error('Content element not found:', contentId);
            }
        });
    });

    // Load initial data
    console.log('Loading initial transaction data...');
    loadCashHandTransactions();
    loadCashBankTransactions();
    loadSuppliers();
    loadProducts();

    // Add event listeners for forms
    const cashHandForm = document.getElementById('addCashHandForm');
    const cashBankForm = document.getElementById('addCashBankForm');
    
    console.log('Cash Hand Form element:', cashHandForm);
    console.log('Cash Bank Form element:', cashBankForm);
    
    if (cashHandForm) {
        console.log('Adding submit listener to Cash Hand Form');
        cashHandForm.addEventListener('submit', handleCashHandSubmit);
    } else {
        console.error('Cash Hand Form not found in DOM');
    }
    
    if (cashBankForm) {
        console.log('Adding submit listener to Cash Bank Form');
        cashBankForm.addEventListener('submit', handleCashBankSubmit);
    } else {
        console.error('Cash Bank Form not found in DOM');
    }

    // Add event listeners for search inputs
    const cashHandSearch = document.getElementById('cashHandSearch');
    const cashBankSearch = document.getElementById('cashBankSearch');
    
    console.log('Cash Hand Search element:', cashHandSearch);
    console.log('Cash Bank Search element:', cashBankSearch);
    
    if (cashHandSearch) {
        console.log('Adding input listener to Cash Hand Search');
        cashHandSearch.addEventListener('input', handleCashHandSearch);
    } else {
        console.error('Cash Hand Search not found in DOM');
    }
    
    if (cashBankSearch) {
        console.log('Adding input listener to Cash Bank Search');
        cashBankSearch.addEventListener('input', handleCashBankSearch);
    } else {
        console.error('Cash Bank Search not found in DOM');
    }

    // Add event listeners for showing forms
    const showAddCashHandForm = document.getElementById('showAddCashHandForm');
    const showAddCashBankForm = document.getElementById('showAddCashBankForm');

    console.log('Show Add Cash Hand Form button:', showAddCashHandForm);
    console.log('Show Add Cash Bank Form button:', showAddCashBankForm);

    if (showAddCashHandForm) {
        console.log('Adding click listener to Cash Hand Form button');
        showAddCashHandForm.addEventListener('click', () => {
            console.log('Cash Hand Form button clicked');
            showTransactionForm('cashHand');
        });
    } else {
        console.error('Show Add Cash Hand Form button not found in DOM');
    }

    if (showAddCashBankForm) {
        console.log('Adding click listener to Cash Bank Form button');
        showAddCashBankForm.addEventListener('click', () => {
            console.log('Cash Bank Form button clicked');
            showTransactionForm('cashBank');
        });
    } else {
        console.error('Show Add Cash Bank Form button not found in DOM');
    }

    // Add event listeners for close buttons
    document.querySelectorAll('.close-form').forEach(button => {
        button.addEventListener('click', () => {
            const formContainer = button.closest('.form-container');
            if (formContainer) {
                const type = formContainer.id.replace('FormContainer', '');
                closeTransactionForm(type);
            }
        });
    });
});

// Show transaction form
function showTransactionForm(type) {
    console.log('showTransactionForm called with type:', type);
    
    // Get form container and form
    const formContainer = document.getElementById(`${type}FormContainer`);
    const form = document.getElementById(`add${type}Form`);
    
    console.log('Form Container:', formContainer);
    console.log('Form:', form);
    
    if (!formContainer || !form) {
        console.error(`Form elements not found for ${type}`);
        return;
    }
    
    // Reset form
    console.log('Resetting form...');
    form.reset();
    
    // Reset hidden ID field
    const idField = document.getElementById(`${type}Id`);
    if (idField) {
        idField.value = '';
    }
    
    // Reset form title and button text
    const formTitle = formContainer.querySelector('.form-title');
    if (formTitle) {
        formTitle.textContent = 'Add Transaction';
    }
    
    const submitButton = form.querySelector('button[type="submit"]');
    if (submitButton) {
        submitButton.textContent = 'Add Transaction';
    }
    
    // Load suppliers and products
    console.log('Loading suppliers and products...');
    loadSuppliers();
    loadProducts();
    
    // Set default date to today
    console.log('Setting default date to today');
    const dateInput = form.querySelector('input[type="date"]');
    if (dateInput) {
        dateInput.valueAsDate = new Date();
    }
    
    // Remove any existing overlay
    const existingOverlay = document.querySelector('.form-overlay');
    if (existingOverlay) {
        existingOverlay.remove();
    }
    
    // Show form container and ensure it's visible
    console.log('Showing form container');
    formContainer.style.display = 'block';
    formContainer.style.visibility = 'visible';
    formContainer.style.opacity = '1';
    
    // Add new overlay
    console.log('Adding overlay');
    const overlay = document.createElement('div');
    overlay.className = 'form-overlay';
    document.body.appendChild(overlay);
    
    // Ensure the form is visible in the viewport
    setTimeout(() => {
        formContainer.scrollIntoView({ behavior: 'smooth', block: 'center' });
        console.log('Scrolled form into view');
    }, 100);
}

// Close transaction form
function closeTransactionForm(type) {
    console.log('Closing transaction form:', type);
    
    // Get form container and form
    const formContainer = document.getElementById(`${type}FormContainer`);
    const form = document.getElementById(`add${type}Form`);
    
    if (!formContainer || !form) {
        console.error(`Form elements not found for ${type}`);
        return;
    }
    
    // Hide form container
    formContainer.style.display = 'none';
    
    // Remove overlay
    const overlay = document.querySelector('.form-overlay');
    if (overlay) {
        overlay.remove();
    }
    
    // Reset form
    form.reset();
    
    // Reset hidden ID field
    const idField = document.getElementById(`${type}Id`);
    if (idField) {
        idField.value = '';
    }
    
    // Reset form title and button text
    const formTitle = formContainer.querySelector('.form-title');
    if (formTitle) {
        formTitle.textContent = 'Add Transaction';
    }
    
    const submitButton = form.querySelector('button[type="submit"]');
    if (submitButton) {
        submitButton.textContent = 'Add Transaction';
    }
    
    console.log('Form closed and reset');
}

// Close Cash Hand Form
window.closeCashHandForm = function() {
    closeTransactionForm('cashHand');
};

// Close Cash Bank Form
window.closeCashBankForm = function() {
    closeTransactionForm('cashBank');
};

// Load suppliers into select element
async function loadSuppliers() {
    try {
        console.log('Loading suppliers...');
        const response = await fetch('api/supplier.php');
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || 'Failed to load suppliers');
        }
        
        const data = await response.json();
        console.log('Received suppliers:', data);
        
        if (data.status === 'success') {
            // Update both cash hand and cash bank supplier selects
            const cashHandSelect = document.getElementById('cashHandSupplier');
            const cashBankSelect = document.getElementById('cashBankSupplier');
            
            if (!cashHandSelect || !cashBankSelect) {
                console.error('Supplier select elements not found');
                return;
            }
            
            const defaultOption = '<option value="">Select Supplier</option>';
            cashHandSelect.innerHTML = defaultOption;
            cashBankSelect.innerHTML = defaultOption;
            
            if (data.data && data.data.length > 0) {
                data.data.forEach(supplier => {
                    const option = document.createElement('option');
                    option.value = supplier.id;
                    option.textContent = supplier.name;
                    
                    // Clone the option for both selects
                    cashHandSelect.appendChild(option.cloneNode(true));
                    cashBankSelect.appendChild(option);
                });
            } else {
                console.log('No suppliers found');
            }
        } else {
            throw new Error(data.message || 'Error loading suppliers');
        }
    } catch (error) {
        console.error('Error loading suppliers:', error);
        showAlert('error', error.message || 'Error loading suppliers');
    }
}

// Load products into select element
async function loadProducts() {
    try {
        console.log('Loading products...');
        const response = await fetch('api/products.php');
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || 'Failed to load products');
        }
        
        const data = await response.json();
        console.log('Received products:', data);
        
        if (data.success) {
            // Update both cash hand and cash bank product selects
            const cashHandSelect = document.getElementById('cashHandProduct');
            const cashBankSelect = document.getElementById('cashBankProduct');
            
            if (!cashHandSelect || !cashBankSelect) {
                console.error('Product select elements not found');
                return;
            }
            
            const defaultOption = '<option value="">Select Product</option>';
            cashHandSelect.innerHTML = defaultOption;
            cashBankSelect.innerHTML = defaultOption;
            
            if (data.products && data.products.length > 0) {
                data.products.forEach(product => {
                    const option = document.createElement('option');
                    option.value = product.id;
                    option.textContent = `${product.name} (${product.brand}) - $${product.purchase_price}`;
                    
                    // Clone the option for both selects
                    cashHandSelect.appendChild(option.cloneNode(true));
                    cashBankSelect.appendChild(option);
                });
            } else {
                console.log('No products found');
            }
        } else {
            throw new Error(data.message || 'Error loading products');
        }
    } catch (error) {
        console.error('Error loading products:', error);
        showAlert(error.message || 'Error loading products', 'error');
    }
}

// Load Cash Hand Transactions
async function loadCashHandTransactions() {
    try {
        console.log('Fetching cash hand transactions...');
        const response = await fetch('api/payment.php?type=cash_hand');
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || 'Failed to load cash hand transactions');
        }
        
        const data = await response.json();
        console.log('Received cash hand transactions:', data);
        
        if (data.status === 'success') {
            const tbody = document.querySelector('#cashHandTable tbody');
            if (!tbody) {
                console.error('Cash Hand table body not found');
                return;
            }
            
            tbody.innerHTML = '';
            
            if (data.data && data.data.length > 0) {
                data.data.forEach(transaction => {
                    tbody.appendChild(createTransactionRow(transaction, 'cash_hand'));
                });
            } else {
                const row = document.createElement('tr');
                row.innerHTML = '<td colspan="9" class="text-center">No transactions found</td>';
                tbody.appendChild(row);
            }
        } else {
            showAlert('error', data.message || 'Error loading cash hand transactions');
        }
    } catch (error) {
        console.error('Error loading cash hand transactions:', error);
        showAlert('error', error.message || 'Error loading cash hand transactions');
    }
}

// Load Cash Bank Transactions
async function loadCashBankTransactions() {
    try {
        console.log('Fetching cash bank transactions...');
        const response = await fetch('api/payment.php?type=cash_bank');
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || 'Failed to load cash bank transactions');
        }
        
        const data = await response.json();
        console.log('Received cash bank transactions:', data);
        
        if (data.status === 'success') {
            const tbody = document.querySelector('#cashBankTable tbody');
            if (!tbody) {
                console.error('Cash Bank table body not found');
                return;
            }
            
            tbody.innerHTML = '';
            
            if (data.data && data.data.length > 0) {
                data.data.forEach(transaction => {
                    tbody.appendChild(createTransactionRow(transaction, 'cash_bank'));
                });
            } else {
                const row = document.createElement('tr');
                row.innerHTML = '<td colspan="9" class="text-center">No transactions found</td>';
                tbody.appendChild(row);
            }
        } else {
            showAlert('error', data.message || 'Error loading cash bank transactions');
        }
    } catch (error) {
        console.error('Error loading cash bank transactions:', error);
        showAlert('error', error.message || 'Error loading cash bank transactions');
    }
}

// Create Transaction Row
function createTransactionRow(transaction, type) {
    const row = document.createElement('tr');
    
    const totalAmount = transaction.purchase_price * transaction.quantity;
    const balance = transaction.balance || (totalAmount - transaction.amount_paid);
    
    row.innerHTML = `
        <td>${formatDate(transaction.transaction_date)}</td>
        <td>${escapeHtml(transaction.supplier_name || 'N/A')}</td>
        <td>${escapeHtml(transaction.product_name || 'N/A')}</td>
        <td>${transaction.quantity}</td>
        <td>${formatCurrency(totalAmount)}</td>
        <td>${formatCurrency(transaction.amount_paid)}</td>
        <td>${formatCurrency(balance)}</td>
        <td><span class="status-badge status-${transaction.status.toLowerCase()}">${escapeHtml(transaction.status)}</span></td>
        <td class="action-buttons">
            <button type="button" onclick="handleEdit(${transaction.id}, '${type}')" class="btn-edit" title="Edit transaction">✏️</button>
            <button type="button" onclick="handleDelete(${transaction.id}, '${type}')" class="btn-delete" title="Delete transaction">🗑️</button>
        </td>
    `;
    
    return row;
}

// Handle Edit Button Click
window.handleEdit = async function(id, type) {
    try {
        console.log('Edit clicked for:', id, type);
        
        // 1. Fetch transaction details
        const response = await fetch(`api/payment.php?id=${id}`);
        const data = await response.json();
        
        if (!data.status === 'success' || !data.data) {
            throw new Error('Failed to load transaction details');
        }
        
        const transaction = data.data;
        
        // 2. Determine form type and get elements
        const formType = type === 'cash_hand' ? 'cashHand' : 'cashBank';
        const formContainer = document.getElementById(`${formType}FormContainer`);
        const form = document.getElementById(`add${formType}Form`);
        
        if (!formContainer || !form) {
            throw new Error('Form elements not found');
        }
        
        // 3. Reset and show form
        form.reset();
        formContainer.style.display = 'block';
        
        // 4. Set form values
        const fields = {
            [`${formType}Id`]: transaction.id,
            [`${formType}Supplier`]: transaction.supplier_id,
            [`${formType}Product`]: transaction.product_id,
            [`${formType}Quantity`]: transaction.quantity,
            [`${formType}Amount`]: transaction.amount_paid,
            [`${formType}Date`]: transaction.transaction_date.split(' ')[0],
            [`${formType}Status`]: transaction.status,
            [`${formType}Notes`]: transaction.notes || ''
        };
        
        if (type === 'cash_bank') {
            fields[`${formType}Account`] = transaction.bank_account;
            fields[`${formType}Reference`] = transaction.reference_number;
        }
        
        // Set field values
        Object.entries(fields).forEach(([id, value]) => {
            const field = document.getElementById(id);
            if (field) {
                field.value = value;
            }
        });
        
        // 5. Update form title and button
        const formTitle = formContainer.querySelector('.form-title');
        if (formTitle) formTitle.textContent = 'Edit Transaction';
        
        const submitBtn = form.querySelector('button[type="submit"]');
        if (submitBtn) submitBtn.textContent = 'Update Transaction';
        
        // 6. Show form
        formContainer.style.display = 'block';
        formContainer.scrollIntoView({ behavior: 'smooth' });
        
    } catch (error) {
        console.error('Edit error:', error);
        showAlert('error', 'Failed to load transaction details');
    }
};

// Handle Delete Button Click
window.handleDelete = async function(id, type) {
    if (confirm('Are you sure you want to delete this transaction?')) {
        try {
            const response = await fetch(`api/payment.php?id=${id}`, {
                method: 'DELETE'
            });
            
            const data = await response.json();
            
            if (data.status === 'success') {
                showAlert('success', 'Transaction deleted successfully');
                if (type === 'cash_hand') {
                    loadCashHandTransactions();
                } else {
                    loadCashBankTransactions();
                }
            } else {
                throw new Error(data.message || 'Failed to delete transaction');
            }
        } catch (error) {
            console.error('Delete error:', error);
            showAlert('error', error.message || 'Failed to delete transaction');
        }
    }
};

// Handle Cash Hand Form Submit
async function handleCashHandSubmit(event) {
    event.preventDefault();
    
    const transactionId = document.getElementById('cashHandId').value;
    const isEdit = transactionId !== '';
    
    const formData = {
        type: 'cash_hand',
        supplier_id: document.getElementById('cashHandSupplier').value,
        product_id: document.getElementById('cashHandProduct').value,
        quantity: document.getElementById('cashHandQuantity').value,
        amount_paid: document.getElementById('cashHandAmount').value,
        transaction_date: document.getElementById('cashHandDate').value,
        status: document.getElementById('cashHandStatus').value,
        notes: document.getElementById('cashHandNotes').value
    };
    
    try {
        const response = await fetch(isEdit ? `api/payment.php?id=${transactionId}` : 'api/payment.php', {
            method: isEdit ? 'PUT' : 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        });
        
        const result = await response.json();
        
        if (result.status === 'success') {
            showAlert('success', `Transaction ${isEdit ? 'updated' : 'added'} successfully`);
            document.getElementById('cashHandFormContainer').style.display = 'none';
            loadCashHandTransactions();
        } else {
            throw new Error(result.message || `Failed to ${isEdit ? 'update' : 'add'} transaction`);
        }
    } catch (error) {
        console.error('Form submit error:', error);
        showAlert('error', error.message || `Failed to ${isEdit ? 'update' : 'add'} transaction`);
    }
}

// Handle Cash Bank Form Submit
async function handleCashBankSubmit(event) {
    event.preventDefault();
    
    const transactionId = document.getElementById('cashBankId').value;
    const isEdit = transactionId !== '';
    
    const formData = {
        type: 'cash_bank',
        supplier_id: document.getElementById('cashBankSupplier').value,
        product_id: document.getElementById('cashBankProduct').value,
        quantity: document.getElementById('cashBankQuantity').value,
        amount_paid: document.getElementById('cashBankAmount').value,
        transaction_date: document.getElementById('cashBankDate').value,
        status: document.getElementById('cashBankStatus').value,
        notes: document.getElementById('cashBankNotes').value,
        bank_account: document.getElementById('cashBankAccount').value,
        reference_number: document.getElementById('cashBankReference').value
    };
    
    try {
        const response = await fetch(isEdit ? `api/payment.php?id=${transactionId}` : 'api/payment.php', {
            method: isEdit ? 'PUT' : 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        });
        
        const result = await response.json();
        
        if (result.status === 'success') {
            showAlert('success', `Transaction ${isEdit ? 'updated' : 'added'} successfully`);
            document.getElementById('cashBankFormContainer').style.display = 'none';
            loadCashBankTransactions();
        } else {
            throw new Error(result.message || `Failed to ${isEdit ? 'update' : 'add'} transaction`);
        }
    } catch (error) {
        console.error('Form submit error:', error);
        showAlert('error', error.message || `Failed to ${isEdit ? 'update' : 'add'} transaction`);
    }
}

// Handle Cash Hand Search
function handleCashHandSearch(event) {
    const searchTerm = event.target.value.toLowerCase();
    const rows = document.querySelectorAll('#cashHandTable tbody tr');
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(searchTerm) ? '' : 'none';
    });
}

// Handle Cash Bank Search
function handleCashBankSearch(event) {
    const searchTerm = event.target.value.toLowerCase();
    const rows = document.querySelectorAll('#cashBankTable tbody tr');
    
    rows.forEach(row => {
        const text = row.textContent.toLowerCase();
        row.style.display = text.includes(searchTerm) ? '' : 'none';
    });
}

// Utility Functions
function formatDate(dateString) {
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
}

function formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
    }).format(amount);
}

function showAlert(message, type) {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type}`;
    alertDiv.textContent = message;
    
    document.body.appendChild(alertDiv);
    
    setTimeout(() => {
        alertDiv.remove();
    }, 3000);
} 