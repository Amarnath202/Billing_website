// Update current time in the sidebar
function updateCurrentTime() {
    const now = new Date();
    const timeString = now.toLocaleTimeString();
    const dateString = now.toLocaleDateString();
    document.getElementById('currentTime').textContent = `${dateString} ${timeString}`;
}

// Initialize common functionality
document.addEventListener('DOMContentLoaded', function() {
    // Update time every second
    updateCurrentTime();
    setInterval(updateCurrentTime, 1000);

    // Add any other common initialization here
});

// Common utility functions
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR',
        minimumFractionDigits: 2
    }).format(amount);
}

function showNotification(message, type = 'info') {
    // You can enhance this with a proper notification library
    alert(message);
}

// Utility functions for date and number formatting
function formatNumber(number) {
    return (Number(number) || 0).toLocaleString('en-IN', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

function formatDate(dateString) {
    try {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-IN', {
            month: 'short',
            day: 'numeric'
        });
    } catch (e) {
        return dateString;
    }
}

function formatDateTime(dateString) {
    try {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-IN', {
            day: 'numeric',
            month: 'short',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    } catch (e) {
        return dateString;
    }
}

// HTML escaping for security
function escapeHtml(unsafe) {
    if (typeof unsafe !== 'string') return '';
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

// Error handling and display
function showError(message) {
    const alertsContainer = $('#alerts-container');
    if (alertsContainer.length === 0) {
        $('body').append('<div id="alerts-container"></div>');
    }
    
    const alert = $('<div class="alert alert-error"></div>').text(message);
    $('#alerts-container').append(alert);
    
    setTimeout(() => {
        alert.fadeOut(300, function() {
            $(this).remove();
            if ($('#alerts-container').children().length === 0) {
                $('#alerts-container').remove();
            }
        });
    }, 3000);
}

// AJAX helper function
function fetchData(url) {
    return fetch(url)
        .then(response => response.json())
        .catch(error => {
            showError('Network error while loading data: ' + error.message);
        });
}

// Chart update functions
function updateDailySalesChart(data) {
    if (!window.dailySalesChart || !data || !data.dates || !data.amounts) return;
    
    window.dailySalesChart.data.labels = data.dates;
    window.dailySalesChart.data.datasets[0].data = data.amounts;
    window.dailySalesChart.update();
}

function updateTopProductsChart(data) {
    if (!window.topProductsChart || !data || !data.products || !data.amounts) return;
    
    window.topProductsChart.data.labels = data.products;
    window.topProductsChart.data.datasets[0].data = data.amounts;
    window.topProductsChart.update();
}

// Table update function
function updateTables(data) {
    // Recent Sales Table
    const recentSalesTable = $('#recentSalesTable tbody');
    recentSalesTable.empty();

    if (data.recent_sales && data.recent_sales.length > 0) {
        data.recent_sales.forEach(sale => {
            recentSalesTable.append(`
                <tr>
                    <td>${formatDateTime(sale.sale_date)}</td>
                    <td>${sale.item_code}</td>
                    <td>${escapeHtml(sale.product_name)}</td>
                    <td>${sale.quantity}</td>
                    <td>₹${formatNumber(sale.unit_price)}</td>
                    <td>₹${formatNumber(sale.total_amount)}</td>
                </tr>
            `);
        });
    } else {
        recentSalesTable.append('<tr><td colspan="6" class="no-data">No recent sales</td></tr>');
    }
} 