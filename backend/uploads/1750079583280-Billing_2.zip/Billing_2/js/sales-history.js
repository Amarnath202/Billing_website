document.addEventListener('DOMContentLoaded', function() {
    // Initialize year dropdown for month filter
    initializeYearDropdown();
    
    // Initialize filter type change handler
    initializeFilterTypeHandler();
    
    // Initialize product filter
    loadProducts();
    
    // Load initial data
    loadSalesHistory();
    
    // Initialize filter buttons
    document.getElementById('applyFilter').addEventListener('click', applyFilters);
    document.getElementById('resetFilter').addEventListener('click', resetFilters);
    
    // Initialize product filter change handler
    document.getElementById('productFilter').addEventListener('change', handleProductSelection);
});

// Initialize year dropdown with last 5 years
function initializeYearDropdown() {
    const yearSelect = document.getElementById('historyYear');
    const currentYear = new Date().getFullYear();
    
    for (let year = currentYear; year >= currentYear - 4; year--) {
        const option = document.createElement('option');
        option.value = year;
        option.textContent = year;
        yearSelect.appendChild(option);
    }
}

// Handle filter type changes
function initializeFilterTypeHandler() {
    const filterType = document.getElementById('filterType');
    filterType.addEventListener('change', function() {
        // Hide all filter sections
        document.getElementById('dateFilterSection').style.display = 'none';
        document.getElementById('monthFilterSection').style.display = 'none';
        document.getElementById('productFilterSection').style.display = 'none';
        
        // Show selected filter section
        switch(this.value) {
            case 'date':
                document.getElementById('dateFilterSection').style.display = 'block';
                break;
            case 'month':
                document.getElementById('monthFilterSection').style.display = 'block';
                break;
            case 'product':
                document.getElementById('productFilterSection').style.display = 'block';
                break;
        }
    });
}

// Load products for product filter
function loadProducts() {
    fetchData('api/products.php')
        .then(response => {
            if (!response.success || !response.products) {
                throw new Error('Invalid response format');
            }
            const select = document.getElementById('productFilter');
            response.products.forEach(product => {
                const option = document.createElement('option');
                option.value = product.id;
                option.textContent = product.name;
                select.appendChild(option);
            });
        })
        .catch(error => {
            console.error('Error loading products:', error);
            showNotification('Error loading products', 'error');
        });
}

// Handle product selection
function handleProductSelection(e) {
    const productId = e.target.value;
    if (productId) {
        fetchData(`api/products.php?id=${productId}`)
            .then(response => {
                if (!response.success || !response.product) {
                    throw new Error('Invalid response format');
                }
                const product = response.product;
                document.getElementById('selectedItemCode').textContent = product.item_code;
                document.getElementById('selectedBrand').textContent = product.brand;
                document.getElementById('selectedStock').textContent = product.quantity;
                document.querySelector('.product-info').style.display = 'block';
            })
            .catch(error => {
                console.error('Error loading product details:', error);
                showNotification('Error loading product details', 'error');
            });
    } else {
        document.querySelector('.product-info').style.display = 'none';
    }
}

// Load sales history data
function loadSalesHistory(filters = {}) {
    let url = 'api/sales.php?action=history';
    
    // Add filters to URL if present
    if (Object.keys(filters).length > 0) {
        const params = new URLSearchParams(filters);
        url += '&' + params.toString();
    }
    
    fetchData(url)
        .then(response => {
            if (!response.success) {
                throw new Error(response.message || 'Failed to load sales history');
            }
            updateSummary(response.summary);
            updateHistoryTable(response.sales);
        })
        .catch(error => {
            console.error('Error loading sales history:', error);
            showNotification('Error loading sales history', 'error');
        });
}

// Update summary cards
function updateSummary(summary) {
    if (!summary) {
        console.error('Summary data is missing');
        return;
    }
    
    document.getElementById('totalSales').textContent = formatCurrency(summary.totalSales);
    document.getElementById('totalTransactions').textContent = summary.totalTransactions;
    document.getElementById('averageBill').textContent = formatCurrency(summary.averageBill);
    document.getElementById('topProduct').textContent = summary.topProduct || 'N/A';
}

// Update history table
function updateHistoryTable(sales) {
    if (!Array.isArray(sales)) {
        console.error('Sales data is not an array');
        return;
    }
    
    const tbody = document.querySelector('#historyTable tbody');
    tbody.innerHTML = '';
    
    sales.forEach(sale => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${formatDateTime(sale.datetime)}</td>
            <td>${sale.billNumber}</td>
            <td>${sale.product}</td>
            <td>${sale.brand}</td>
            <td>${sale.quantity}</td>
            <td>${formatCurrency(sale.unitPrice)}</td>
            <td>${formatCurrency(sale.totalAmount)}</td>
            <td>
                <button onclick="viewBillDetails('${sale.billNumber}')" class="action-btn view-btn">
                    <span class="icon">👁️</span>
                </button>
                <button onclick="printBill('${sale.billNumber}')" class="action-btn print-btn">
                    <span class="icon">🖨️</span>
                </button>
            </td>
        `;
        tbody.appendChild(row);
    });
}

// Apply filters
function applyFilters() {
    const filterType = document.getElementById('filterType').value;
    let filters = {};
    
    switch(filterType) {
        case 'date':
            filters.startDate = document.getElementById('startDate').value;
            filters.endDate = document.getElementById('endDate').value;
            break;
            
        case 'month':
            filters.month = document.getElementById('historyMonth').value;
            filters.year = document.getElementById('historyYear').value;
            break;
            
        case 'product':
            filters.productId = document.getElementById('productFilter').value;
            break;
    }
    
    loadSalesHistory(filters);
}

// Reset filters
function resetFilters() {
    document.getElementById('filterType').value = 'all';
    document.getElementById('startDate').value = '';
    document.getElementById('endDate').value = '';
    document.getElementById('historyMonth').value = '01';
    document.getElementById('historyYear').value = new Date().getFullYear();
    document.getElementById('productFilter').value = '';
    document.querySelector('.product-info').style.display = 'none';
    
    // Hide all filter sections
    document.getElementById('dateFilterSection').style.display = 'none';
    document.getElementById('monthFilterSection').style.display = 'none';
    document.getElementById('productFilterSection').style.display = 'none';
    
    // Load all data
    loadSalesHistory();
}

// View bill details
function viewBillDetails(billNumber) {
    fetchData(`api/sales.php?action=bill&id=${billNumber}`)
        .then(response => {
            if (!response.success) {
                throw new Error(response.message || 'Failed to load bill details');
            }
            const bill = response.data;
            document.getElementById('modalBillNumber').textContent = bill.billNumber;
            document.getElementById('modalBillDate').textContent = formatDateTime(bill.datetime);
            
            const tbody = document.getElementById('modalBillItems');
            tbody.innerHTML = '';
            
            let total = 0;
            bill.items.forEach(item => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${item.product}</td>
                    <td>${item.brand}</td>
                    <td>${item.quantity}</td>
                    <td>${formatCurrency(item.unitPrice)}</td>
                    <td>${formatCurrency(item.totalAmount)}</td>
                `;
                tbody.appendChild(row);
                total += item.totalAmount;
            });
            
            document.getElementById('modalTotalAmount').textContent = formatCurrency(total);
            document.getElementById('billDetailsModal').style.display = 'block';
        })
        .catch(error => {
            console.error('Error loading bill details:', error);
            showNotification('Error loading bill details', 'error');
        });
}

// Close bill details modal
function closeBillDetails() {
    document.getElementById('billDetailsModal').style.display = 'none';
}

// Print bill
function printBill() {
    const billNumber = document.getElementById('modalBillNumber').textContent;
    window.open(`api/sales.php?action=print&id=${billNumber}`, '_blank');
}

// Download bill as PDF
function downloadBill() {
    const billNumber = document.getElementById('modalBillNumber').textContent;
    window.location.href = `api/sales.php?action=download&id=${billNumber}`;
}

// Download history as PDF
function downloadHistory(format) {
    // Get current filters
    const filterType = document.getElementById('filterType').value;
    let filters = {};
    
    switch(filterType) {
        case 'date':
            filters.startDate = document.getElementById('startDate').value;
            filters.endDate = document.getElementById('endDate').value;
            break;
            
        case 'month':
            filters.month = document.getElementById('historyMonth').value;
            filters.year = document.getElementById('historyYear').value;
            break;
            
        case 'product':
            filters.productId = document.getElementById('productFilter').value;
            break;
    }
    
    // Add format to filters
    filters.format = format;
    
    // Create URL with filters
    const params = new URLSearchParams(filters);
    window.location.href = `api/sales.php?action=download_history&${params.toString()}`;
}

// Helper Functions
function fetchData(url, options = {}) {
    const defaultOptions = {
        headers: {
            'Content-Type': 'application/json'
        }
    };

    return fetch(url, { ...defaultOptions, ...options })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        });
}

function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

function formatCurrency(amount) {
    return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR'
    }).format(amount);
}

function formatDateTime(datetime) {
    return new Date(datetime).toLocaleString('en-IN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit'
    });
} 