document.addEventListener('DOMContentLoaded', function() {
    // Initialize tab functionality
    initializeTabs();
    
    // Load initial data
    loadCashHandTransactions();
    loadCashBankTransactions();
    
    // Initialize form submissions
    initializeCashHandForm();
    initializeCashBankForm();
    
    // Initialize search functionality
    initializeSearch();
    
    // Load suppliers and products for dropdowns
    loadSuppliers();
    loadProducts();
});

// Tab Management
function initializeTabs() {
    const tabButtons = document.querySelectorAll('.payment-tab-btn');
    const tabContents = document.querySelectorAll('.payment-tab-content');

    tabButtons.forEach(button => {
        button.addEventListener('click', () => {
            const targetTab = button.getAttribute('data-subtab');
            
            // Update active states
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));
            
            button.classList.add('active');
            document.getElementById(targetTab).classList.add('active');
        });
    });
}

// Load Data Functions
function loadCashHandTransactions() {
    fetchData('api/transactions/cash-hand.php')
        .then(response => {
            if (!response.success || !response.transactions) {
                throw new Error('Invalid response format');
            }
            const tbody = document.querySelector('#cashHandTable tbody');
            tbody.innerHTML = '';
            
            response.transactions.forEach(transaction => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${formatDate(transaction.transaction_date)}</td>
                    <td>${transaction.supplier_name}</td>
                    <td>${transaction.product_name}</td>
                    <td>${transaction.quantity}</td>
                    <td>${formatCurrency(transaction.total_amount)}</td>
                    <td>${formatCurrency(transaction.amount_paid)}</td>
                    <td>${formatCurrency(transaction.balance)}</td>
                    <td><span class="status-badge ${transaction.status}">${transaction.status}</span></td>
                    <td>
                        <button onclick="editCashHandTransaction(${transaction.id})" class="action-btn edit-btn">
                            <span class="icon">✏️</span>
                        </button>
                        <button onclick="deleteCashHandTransaction(${transaction.id})" class="action-btn delete-btn">
                            <span class="icon">🗑️</span>
                        </button>
                    </td>
                `;
                tbody.appendChild(row);
            });
        })
        .catch(error => {
            console.error('Error loading cash hand transactions:', error);
            showNotification('Error loading transactions', 'error');
        });
}

function loadCashBankTransactions() {
    fetchData('api/transactions/cash-bank.php')
        .then(response => {
            if (!response.success || !response.transactions) {
                throw new Error('Invalid response format');
            }
            const tbody = document.querySelector('#cashBankTable tbody');
            tbody.innerHTML = '';
            
            response.transactions.forEach(transaction => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${formatDate(transaction.transaction_date)}</td>
                    <td>${transaction.supplier_name}</td>
                    <td>${transaction.product_name}</td>
                    <td>${transaction.quantity}</td>
                    <td>${formatCurrency(transaction.total_amount)}</td>
                    <td>${formatCurrency(transaction.amount_paid)}</td>
                    <td>${formatCurrency(transaction.balance)}</td>
                    <td><span class="status-badge ${transaction.status}">${transaction.status}</span></td>
                    <td>
                        <button onclick="editCashBankTransaction(${transaction.id})" class="action-btn edit-btn">
                            <span class="icon">✏️</span>
                        </button>
                        <button onclick="deleteCashBankTransaction(${transaction.id})" class="action-btn delete-btn">
                            <span class="icon">🗑️</span>
                        </button>
                    </td>
                `;
                tbody.appendChild(row);
            });
        })
        .catch(error => {
            console.error('Error loading cash bank transactions:', error);
            showNotification('Error loading transactions', 'error');
        });
}

// Form Management
function initializeCashHandForm() {
    const form = document.getElementById('addCashHandForm');
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = {
            supplierId: document.getElementById('cashHandSupplier').value,
            productId: document.getElementById('cashHandProduct').value,
            quantity: document.getElementById('cashHandQuantity').value,
            amountPaid: document.getElementById('cashHandAmount').value,
            date: document.getElementById('cashHandDate').value,
            status: document.getElementById('cashHandStatus').value,
            notes: document.getElementById('cashHandNotes').value
        };

        const transactionId = document.getElementById('cashHandId').value;
        const method = transactionId ? 'PUT' : 'POST';
        const url = transactionId ? 
            `api/transactions/cash-hand.php?id=${transactionId}` : 
            'api/transactions/cash-hand.php';

        fetchData(url, {
            method: method,
            body: JSON.stringify(formData)
        })
        .then(() => {
            showNotification('Transaction saved successfully');
            closeCashHandForm();
            loadCashHandTransactions();
        });
    });
}

function initializeCashBankForm() {
    const form = document.getElementById('addCashBankForm');
    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const formData = {
            supplierId: document.getElementById('cashBankSupplier').value,
            productId: document.getElementById('cashBankProduct').value,
            quantity: document.getElementById('cashBankQuantity').value,
            amountPaid: document.getElementById('cashBankAmount').value,
            date: document.getElementById('cashBankDate').value,
            status: document.getElementById('cashBankStatus').value,
            bankAccount: document.getElementById('cashBankAccount').value,
            referenceNumber: document.getElementById('cashBankReference').value,
            notes: document.getElementById('cashBankNotes').value
        };

        const transactionId = document.getElementById('cashBankId').value;
        const method = transactionId ? 'PUT' : 'POST';
        const url = transactionId ? 
            `api/transactions/cash-bank.php?id=${transactionId}` : 
            'api/transactions/cash-bank.php';

        fetchData(url, {
            method: method,
            body: JSON.stringify(formData)
        })
        .then(() => {
            showNotification('Transaction saved successfully');
            closeCashBankForm();
            loadCashBankTransactions();
        });
    });
}

// Load Dropdowns
function loadSuppliers() {
    fetchData('api/suppliers.php')
        .then(response => {
            if (!response.success || !response.suppliers) {
                throw new Error('Invalid response format');
            }
            const cashHandSelect = document.getElementById('cashHandSupplier');
            const cashBankSelect = document.getElementById('cashBankSupplier');
            
            response.suppliers.forEach(supplier => {
                const option = document.createElement('option');
                option.value = supplier.id;
                option.textContent = supplier.name;
                
                cashHandSelect.appendChild(option.cloneNode(true));
                cashBankSelect.appendChild(option);
            });
        })
        .catch(error => {
            console.error('Error loading suppliers:', error);
            showNotification('Error loading suppliers', 'error');
        });
}

function loadProducts() {
    fetchData('api/products.php')
        .then(response => {
            if (!response.success || !response.products) {
                throw new Error('Invalid response format');
            }
            const cashHandSelect = document.getElementById('cashHandProduct');
            const cashBankSelect = document.getElementById('cashBankProduct');
            
            response.products.forEach(product => {
                const option = document.createElement('option');
                option.value = product.id;
                option.textContent = product.name;
                
                cashHandSelect.appendChild(option.cloneNode(true));
                cashBankSelect.appendChild(option);
            });
        })
        .catch(error => {
            console.error('Error loading products:', error);
            showNotification('Error loading products', 'error');
        });
}

// Search Functionality
function initializeSearch() {
    document.getElementById('cashHandSearch').addEventListener('input', function(e) {
        const searchTerm = e.target.value.toLowerCase();
        const rows = document.querySelectorAll('#cashHandTable tbody tr');
        
        rows.forEach(row => {
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(searchTerm) ? '' : 'none';
        });
    });

    document.getElementById('cashBankSearch').addEventListener('input', function(e) {
        const searchTerm = e.target.value.toLowerCase();
        const rows = document.querySelectorAll('#cashBankTable tbody tr');
        
        rows.forEach(row => {
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(searchTerm) ? '' : 'none';
        });
    });
}

// Form Display Functions
function showAddCashHandForm() {
    document.getElementById('cashHandFormContainer').style.display = 'block';
    document.getElementById('cashHandId').value = '';
    document.getElementById('addCashHandForm').reset();
    document.getElementById('submitCashHandButton').textContent = 'Add Transaction';
}

function closeCashHandForm() {
    document.getElementById('cashHandFormContainer').style.display = 'none';
}

function showAddCashBankForm() {
    document.getElementById('cashBankFormContainer').style.display = 'block';
    document.getElementById('cashBankId').value = '';
    document.getElementById('addCashBankForm').reset();
    document.getElementById('submitCashBankButton').textContent = 'Add Transaction';
}

function closeCashBankForm() {
    document.getElementById('cashBankFormContainer').style.display = 'none';
}

// Edit Functions
function editCashHandTransaction(id) {
    fetchData(`api/transactions/cash-hand.php?id=${id}`)
        .then(transaction => {
            document.getElementById('cashHandId').value = transaction.id;
            document.getElementById('cashHandSupplier').value = transaction.supplier_id;
            document.getElementById('cashHandProduct').value = transaction.product_id;
            document.getElementById('cashHandQuantity').value = transaction.quantity;
            document.getElementById('cashHandAmount').value = transaction.amount_paid;
            document.getElementById('cashHandDate').value = transaction.transaction_date;
            document.getElementById('cashHandStatus').value = transaction.status;
            document.getElementById('cashHandNotes').value = transaction.notes;
            
            document.getElementById('submitCashHandButton').textContent = 'Update Transaction';
            document.getElementById('cancelCashHandEdit').style.display = 'inline-block';
            document.getElementById('cashHandFormContainer').style.display = 'block';
        });
}

function editCashBankTransaction(id) {
    fetchData(`api/transactions/cash-bank.php?id=${id}`)
        .then(transaction => {
            document.getElementById('cashBankId').value = transaction.id;
            document.getElementById('cashBankSupplier').value = transaction.supplier_id;
            document.getElementById('cashBankProduct').value = transaction.product_id;
            document.getElementById('cashBankQuantity').value = transaction.quantity;
            document.getElementById('cashBankAmount').value = transaction.amount_paid;
            document.getElementById('cashBankDate').value = transaction.transaction_date;
            document.getElementById('cashBankStatus').value = transaction.status;
            document.getElementById('cashBankAccount').value = transaction.bank_account;
            document.getElementById('cashBankReference').value = transaction.reference_number;
            document.getElementById('cashBankNotes').value = transaction.notes;
            
            document.getElementById('submitCashBankButton').textContent = 'Update Transaction';
            document.getElementById('cancelCashBankEdit').style.display = 'inline-block';
            document.getElementById('cashBankFormContainer').style.display = 'block';
        });
}

// Delete Functions
function deleteCashHandTransaction(id) {
    if (confirm('Are you sure you want to delete this transaction?')) {
        fetchData(`api/transactions/cash-hand.php?id=${id}`, { method: 'DELETE' })
            .then(() => {
                showNotification('Transaction deleted successfully');
                loadCashHandTransactions();
            });
    }
}

function deleteCashBankTransaction(id) {
    if (confirm('Are you sure you want to delete this transaction?')) {
        fetchData(`api/transactions/cash-bank.php?id=${id}`, { method: 'DELETE' })
            .then(() => {
                showNotification('Transaction deleted successfully');
                loadCashBankTransactions();
            });
    }
}

// Helper function to format date
function formatDate(date) {
    return new Date(date).toLocaleDateString('en-IN', {
        year: 'numeric',
        month: '2-digit',
        day: '2-digit'
    });
}

// Helper Functions
function fetchData(url, options = {}) {
    const defaultOptions = {
        headers: {
            'Content-Type': 'application/json'
        }
    };

    return fetch(url, { ...defaultOptions, ...options })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (!data.success) {
                throw new Error(data.message || 'API request failed');
            }
            return data;
        });
}

function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 3000);
}

function formatCurrency(amount) {
    return new Intl.NumberFormat('en-IN', {
        style: 'currency',
        currency: 'INR'
    }).format(amount);
} 