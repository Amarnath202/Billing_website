// Add this at the beginning of your script.js file
let dailySalesChart = null;
let topProductsChart = null;

let salesViewMode = 'amount'; // 'amount' or 'orders'
let productsViewMode = 'quantity'; // 'quantity' or 'revenue'

// Add cart array to store selected products
let cart = [];

// Initialize products list
let productsList = [];

// Show alert message
function showAlert(message, type = 'info') {
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type}`;
    alertDiv.textContent = message;
    
    // Add to document
    document.body.appendChild(alertDiv);
    
    // Remove after 3 seconds
    setTimeout(() => {
        alertDiv.remove();
    }, 3000);
}

// Load dashboard data
async function loadDashboard() {
    try {
        const response = await fetch('api/dashboard.php');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        if (data.status !== 'success') {
            throw new Error(data.message || 'Failed to load dashboard data');
        }

        // Update today's stats
        document.getElementById('todaySales').textContent = `₹${formatCurrency(data.data.today.sales)}`;
        document.getElementById('todayOrders').textContent = `${data.data.today.transactions} orders`;

        // Update month's stats
        document.getElementById('monthSales').textContent = `₹${formatCurrency(data.data.month.sales)}`;
        document.getElementById('monthOrders').textContent = `${data.data.month.transactions} orders`;

        // Update inventory stats
        document.getElementById('totalProducts').textContent = data.data.inventory.total_products;
        document.getElementById('lowStock').textContent = `${data.data.inventory.low_stock_items} low in stock`;

        // Update average order value
        document.getElementById('avgOrderValue').textContent = `₹${formatCurrency(data.data.month.avg_transaction)}`;

        // Update charts
        updateDailySalesChart(data.data.daily_sales);
        updateTopProductsChart(data.data.top_products);

        // Update recent sales table
        updateRecentSalesTable(data.data.recent_sales);

    } catch (error) {
        console.error('Error loading dashboard:', error);
        showAlert('error', 'Failed to load dashboard data: ' + error.message);
    }
}

// Tab switching functionality
document.querySelectorAll('.tab-btn').forEach(button => {
    button.addEventListener('click', () => {
        document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
        button.classList.add('active');
        
        document.querySelectorAll('.tab-content').forEach(content => {
            content.style.display = 'none';
        });
        document.getElementById(button.dataset.tab).style.display = 'block';
        
        if (button.dataset.tab === 'dashboard') {
            loadDashboard();
        }
    });
});

// Add product form submission
document.getElementById('addProductForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    try {
        // Validate form data
        const productId = document.getElementById('productId').value.trim();
        const itemCode = document.getElementById('itemCode').value.trim();
        const name = document.getElementById('productName').value.trim();
        const brand = document.getElementById('productBrand').value.trim();
        const description = document.getElementById('productDescription').value.trim();
        const purchasePrice = parseFloat(document.getElementById('purchasePrice').value);
        const salesPrice = parseFloat(document.getElementById('salesPrice').value);
        const quantity = parseInt(document.getElementById('productQuantity').value);

        // Additional validation
        if (!itemCode) {
            throw new Error('Item code is required');
        }
        if (!name) {
            throw new Error('Product name is required');
        }
        if (!brand) {
            throw new Error('Brand name is required');
        }
        if (isNaN(purchasePrice) || purchasePrice <= 0) {
            throw new Error('Please enter a valid purchase price');
        }
        if (isNaN(salesPrice) || salesPrice <= 0) {
            throw new Error('Please enter a valid sales price');
        }
        if (isNaN(quantity) || quantity < 0) {
            throw new Error('Please enter a valid quantity');
        }

        const formData = new FormData();
        formData.append('action', productId ? 'update' : 'add');
        if (productId) formData.append('id', productId);
        formData.append('item_code', itemCode);
        formData.append('name', name);
        formData.append('brand', brand);
        formData.append('description', description);
        formData.append('purchase_price', purchasePrice.toFixed(2));
        formData.append('sales_price', salesPrice.toFixed(2));
        formData.append('quantity', quantity);

        const response = await fetch('api/inventory.php', {
            method: 'POST',
            body: formData
        }); 

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        
        if (data.status === 'error') {
            throw new Error(data.message || 'Error managing product');
        }

        // Success
        alert(data.message || 'Product saved successfully');
        loadInventory();
        resetForm();
    } catch (error) {
        console.error('Error managing product:', error);
        alert(error.message || 'Error managing product. Please try again.');
    }
});

// Reset form function
function resetForm() {
    const form = document.getElementById('addProductForm');
    form.reset();
    document.getElementById('productId').value = '';
    document.getElementById('itemCode').value = '';
    document.getElementById('submitButton').textContent = 'Add Product';
    document.getElementById('cancelEdit').style.display = 'none';
    form.classList.remove('editing');
}

// Cancel edit function
function cancelEdit() {
    if (confirm('Are you sure you want to cancel editing? Any changes will be lost.')) {
        resetForm();
    }
}

// Edit product function
function editProduct(product) {
    try {
        if (!product || !product.id) {
            throw new Error('Invalid product data');
        }

        // Parse the product data if it's a string
        if (typeof product === 'string') {
            try {
                product = JSON.parse(product);
            } catch (e) {
                throw new Error('Invalid product data format');
            }
        }

        const form = document.getElementById('addProductForm');
        document.getElementById('productId').value = product.id;
        document.getElementById('itemCode').value = product.item_code || '';
        document.getElementById('productName').value = product.name || '';
        document.getElementById('productBrand').value = product.brand || '';
        document.getElementById('productDescription').value = product.description || '';
        document.getElementById('purchasePrice').value = product.purchase_price || '';
        document.getElementById('salesPrice').value = product.sales_price || '';
        document.getElementById('productQuantity').value = product.quantity || '';
        
        document.getElementById('submitButton').textContent = 'Update Product';
        document.getElementById('cancelEdit').style.display = 'inline-block';
        
        form.classList.add('editing');
        form.scrollIntoView({ behavior: 'smooth', block: 'start' });
    } catch (error) {
        console.error('Error setting up edit form:', error);
        alert('Error loading product for editing. Please try again.');
    }
}

// Delete product function
async function deleteProduct(product) {
    try {
        if (!product || !product.id) {
            throw new Error('Invalid product data');
        }

        // Ask for confirmation
        if (!confirm(`Are you sure you want to delete "${product.name}"? This action cannot be undone.`)) {
            return;
        }

        const formData = new FormData();
        formData.append('action', 'delete');
        formData.append('id', product.id);

        const response = await fetch('api/inventory.php', {
            method: 'POST',
            body: formData
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        
        if (data.status === 'error') {
            throw new Error(data.message || 'Error deleting product');
        }

        // Success
        alert(data.message || 'Product deleted successfully');
        loadInventory(); // Refresh the inventory list
    } catch (error) {
        console.error('Error deleting product:', error);
        alert(error.message || 'Error deleting product. Please try again.');
    }
}

// Load inventory
async function loadInventory() {
    const tbody = document.querySelector('#inventoryTable tbody');
    
    try {
        // Show loading state
        tbody.innerHTML = `
            <tr>
                <td colspan="8" class="loading">
                    Loading inventory...
                </td>
            </tr>
        `;

        const response = await fetch('api/inventory.php?action=list');
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const result = await response.json();
        
        if (result.status === 'error') {
            throw new Error(result.message || 'Failed to load inventory');
        }

        const products = result.data;
        
        if (!Array.isArray(products)) {
            throw new Error('Invalid data received from server');
        }

        // Update inventory table
        tbody.innerHTML = '';
        
        if (products.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="8" class="no-data">No products found</td>
                </tr>
            `;
            return;
        }

        products.forEach(product => {
            if (!product || !product.id) return; // Skip invalid products

            const purchasePrice = parseFloat(product.purchase_price) || 0;
            const salesPrice = parseFloat(product.sales_price) || 0;
            const quantity = parseInt(product.quantity) || 0;

            tbody.innerHTML += `
                <tr>
                    <td>${escapeHtml(product.item_code || '')}</td>
                    <td>${escapeHtml(product.name || '')}</td>
                    <td>${escapeHtml(product.brand || '')}</td>
                    <td>${escapeHtml(product.description || '')}</td>
                    <td>₹${purchasePrice.toLocaleString('en-IN', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                    })}</td>
                    <td>₹${salesPrice.toLocaleString('en-IN', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2
                    })}</td>
                    <td>${quantity}</td>
                    <td>
                        <div class="action-buttons">
                            <button onclick="editProduct(${JSON.stringify(product).replace(/"/g, '&quot;')})" class="edit-btn" title="Edit product">
                                ✏️
                            </button>
                            <button onclick="deleteProduct(${JSON.stringify(product).replace(/"/g, '&quot;')})" class="delete-btn" title="Delete product">
                                🗑️
                            </button>
                        </div>
                    </td>
                </tr>
            `;
        });

        // Update product select dropdowns
        const productSelects = document.querySelectorAll('.product-select');
        productSelects.forEach(select => {
            // Store current value if it exists
            const currentValue = select.value;
            
            // Clear and add default option
            select.innerHTML = '<option value="">Select Product</option>';
            
            // Add product options
            products.forEach(product => {
                if (!product || !product.id) return; // Skip invalid products
                
                const salesPrice = parseFloat(product.sales_price) || 0;
                const quantity = parseInt(product.quantity) || 0;
                
                const option = document.createElement('option');
                option.value = product.id;
                option.textContent = `${product.item_code} - ${product.name} - ₹${salesPrice.toFixed(2)}`;
                option.dataset.price = salesPrice;
                option.dataset.quantity = quantity;
                select.appendChild(option);
            });

            // Restore previous value if it exists
            if (currentValue) {
                select.value = currentValue;
            }
        });

        // Clear search input when reloading
        const searchInput = document.getElementById('productSearch');
        if (searchInput) {
            searchInput.value = '';
        }

    } catch (error) {
        console.error('Error loading inventory:', error);
        tbody.innerHTML = `
            <tr>
                <td colspan="8" class="error">
                    Failed to load inventory. Please try refreshing the page.
                    <br>
                    <small>${error.message}</small>
                </td>
            </tr>
        `;
    }
}

// Update current time
function updateCurrentTime() {
    const now = new Date();
    const options = { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric',
        hour: '2-digit', 
        minute: '2-digit', 
        second: '2-digit' 
    };
    document.getElementById('currentTime').textContent = now.toLocaleDateString('en-US', options);
}

// Update time every second
setInterval(updateCurrentTime, 1000);
updateCurrentTime();

// Generate bill number
function generateBillNumber() {
    const now = new Date();
    const year = now.getFullYear().toString().substr(-2);
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const random = String(Math.floor(Math.random() * 1000)).padStart(3, '0');
    return `BILL-${year}${month}${day}-${random}`;
}

// Add product row
function addProductRow() {
    const productRows = document.getElementById('productRows');
    const newRow = document.createElement('div');
    newRow.className = 'product-row';
    newRow.innerHTML = `
        <div class="product-selection">
            <div class="form-group">
                <label>Select Product</label>
                <select class="product-select">
                    <option value="">Select Product</option>
                    ${document.querySelector('.product-select').innerHTML.split('<option value="">Select Product</option>')[1] || ''}
                </select>
            </div>
            <div class="form-group">
                <label>Quantity</label>
                <input type="number" class="quantity-input" min="1" placeholder="Quantity">
            </div>
            <button type="button" class="remove-row-btn" onclick="removeProductRow(this)">×</button>
        </div>
    `;
    productRows.appendChild(newRow);
}

// Remove product row
function removeProductRow(button) {
    const productRows = document.getElementById('productRows');
    if (productRows.children.length > 1) {
        button.closest('.product-row').remove();
    } else {
        // If it's the last row, just clear the inputs
        const row = button.closest('.product-row');
        row.querySelector('.product-select').value = '';
        row.querySelector('.quantity-input').value = '';
    }
}

// Add selected products to bill
function addSelectedProducts() {
    const rows = document.querySelectorAll('.product-row');
    let hasValidProducts = false;
    let errorMessages = [];

    try {
        rows.forEach(row => {
            const productSelect = row.querySelector('.product-select');
            const quantityInput = row.querySelector('.quantity-input');
            
            if (productSelect.value && quantityInput.value) {
                const selectedOption = productSelect.options[productSelect.selectedIndex];
                if (!selectedOption) {
                    throw new Error('Invalid product selection');
                }

                const availableQuantity = parseInt(selectedOption.dataset.quantity) || 0;
                const requestedQuantity = parseInt(quantityInput.value) || 0;

                // Validate quantity input
                if (isNaN(requestedQuantity) || requestedQuantity <= 0) {
                    errorMessages.push('Please enter a valid quantity');
                    return;
                }

                // Check if requested quantity is available
                if (requestedQuantity > availableQuantity) {
                    errorMessages.push(`Only ${availableQuantity} units available for ${selectedOption.text.split(' - ')[0]}`);
                    return;
                }

                // Check if product already exists in the list
                const existingProductIndex = productsList.findIndex(item => item.product_id === productSelect.value);
                
                if (existingProductIndex !== -1) {
                    const totalQuantity = productsList[existingProductIndex].quantity + requestedQuantity;
                    if (totalQuantity > availableQuantity) {
                        errorMessages.push(`Cannot add more units of ${selectedOption.text.split(' - ')[0]}. Total quantity (${totalQuantity}) exceeds available stock (${availableQuantity})`);
                        return;
                    }
                    // Update existing product quantity and total
                    productsList[existingProductIndex].quantity = totalQuantity;
                    productsList[existingProductIndex].total = totalQuantity * productsList[existingProductIndex].price;
                } else {
                    // Add new product to list
                    const price = parseFloat(selectedOption.dataset.price) || 0;
                    productsList.push({
                        product_id: productSelect.value,
                        name: selectedOption.text.split(' - ')[0],
                        quantity: requestedQuantity,
                        price: price,
                        total: requestedQuantity * price
                    });
                }
                hasValidProducts = true;
            }
        });

        if (errorMessages.length > 0) {
            alert(errorMessages.join('\n'));
            return;
        }

        if (!hasValidProducts) {
            alert('Please select at least one product and specify its quantity');
            return;
        }

        // Update display
        updateProductsListDisplay();
        
        // Reset all rows except the first one
        const productRows = document.getElementById('productRows');
        while (productRows.children.length > 1) {
            productRows.lastChild.remove();
        }
        
        // Clear first row inputs
        const firstRow = productRows.firstChild;
        if (firstRow) {
            const select = firstRow.querySelector('.product-select');
            const input = firstRow.querySelector('.quantity-input');
            if (select) select.value = '';
            if (input) input.value = '';
        }

    } catch (error) {
        console.error('Error adding products:', error);
        alert('Error adding products. Please try again.');
    }
}

// Update products list display
function updateProductsListDisplay() {
    const billDetails = document.getElementById('billDetails');
    let grandTotal = 0;

    if (productsList.length === 0) {
        billDetails.innerHTML = '<p class="no-items">No products added to bill yet</p>';
        document.getElementById('processSaleBtn').style.display = 'none';
        return;
    }

    let listHtml = `
        <div class="products-list">
            <table class="products-table">
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Total</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
    `;

    productsList.forEach((item, index) => {
        grandTotal += item.total;
        listHtml += `
            <tr>
                <td>${escapeHtml(item.name)}</td>
                <td>${item.quantity}</td>
                <td>₹${item.price.toLocaleString('en-IN', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                })}</td>
                <td>₹${item.total.toLocaleString('en-IN', {
                    minimumFractionDigits: 2,
                    maximumFractionDigits: 2
                })}</td>
                <td>
                    <button onclick="removeFromList(${index})" class="remove-btn" title="Remove item">×</button>
                </td>
            </tr>
        `;
    });

    listHtml += `
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="3"><strong>Grand Total:</strong></td>
                        <td colspan="2"><strong>₹${grandTotal.toLocaleString('en-IN', {
                            minimumFractionDigits: 2,
                            maximumFractionDigits: 2
                        })}</strong></td>
                    </tr>
                </tfoot>
            </table>
        </div>
    `;

    billDetails.innerHTML = listHtml;
    document.getElementById('processSaleBtn').style.display = 'block';
}

// Remove from list
function removeFromList(index) {
    productsList.splice(index, 1);
    updateProductsListDisplay();
}

// Process sale
async function processSale() {
    if (productsList.length === 0) {
        alert('Please add products to the list');
        return;
    }

    try {
        const formData = new FormData();
        formData.append('cart', JSON.stringify(productsList));

        const response = await fetch('api/sales.php', {
            method: 'POST',
            body: formData
        });
        const data = await response.json();
        
        if (data.status === 'success') {
            // Show final bill
            const billNumber = generateBillNumber();
            const billTime = new Date().toLocaleString();
            
            const finalBillHtml = `
                <div class="final-bill">
                    <div class="bill-header">
                        <div class="bill-title">Sales Invoice</div>
                        <div class="bill-number">Bill No: ${billNumber}</div>
                        <div class="bill-time">Date: ${billTime}</div>
                    </div>
                    <div class="bill-items">
                        <table class="bill-table">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Quantity</th>
                                    <th>Price</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${productsList.map(item => `
                                    <tr>
                                        <td>${escapeHtml(item.name)}</td>
                                        <td>${item.quantity}</td>
                                        <td>₹${item.price.toLocaleString('en-IN', {
                                            minimumFractionDigits: 2,
                                            maximumFractionDigits: 2
                                        })}</td>
                                        <td>₹${item.total.toLocaleString('en-IN', {
                                            minimumFractionDigits: 2,
                                            maximumFractionDigits: 2
                                        })}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="3"><strong>Grand Total:</strong></td>
                                    <td><strong>₹${data.total_amount.toLocaleString('en-IN', {
                                        minimumFractionDigits: 2,
                                        maximumFractionDigits: 2
                                    })}</strong></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                    <div class="bill-footer">
                        <p>Thank you for your business!</p>
                    </div>
                </div>
                <button onclick="printBill()" class="print-btn">Print Bill</button>
            `;
            
            document.getElementById('billDetails').innerHTML = finalBillHtml;
            document.getElementById('processSaleBtn').style.display = 'none';
            
            // Clear products list and reload inventory
            productsList = [];
            loadInventory();

            // Refresh dashboard to update recent sales
            if (document.querySelector('.tab-btn[data-tab="dashboard"]').classList.contains('active')) {
                loadDashboard();
            } else {
                // If not on dashboard, fetch and update just the recent sales
                updateRecentSalesAfterPurchase();
            }
        } else {
            alert(data.message || 'Error processing sale');
        }
    } catch (error) {
        console.error('Error processing sale:', error);
        alert('Error processing sale');
    }
}

// Function to update recent sales after a purchase
async function updateRecentSalesAfterPurchase() {
    try {
        const response = await fetch('api/dashboard.php');
        const data = await response.json();

        if (data.status === 'success' && Array.isArray(data.data.recentSales)) {
            updateRecentSalesTable(data.data.recentSales);
        }
    } catch (error) {
        console.error('Error updating recent sales:', error);
    }
}

// Print bill function
function printBill() {
    const billContent = document.querySelector('.final-bill').innerHTML;
    const printWindow = window.open('', '', 'height=600,width=800');
    
    printWindow.document.write(`
        <html>
            <head>
                <title>Bill</title>
                <style>
                    body { font-family: Arial, sans-serif; padding: 20px; }
                    .bill-header { text-align: center; margin-bottom: 20px; }
                    .bill-title { font-size: 24px; font-weight: bold; margin-bottom: 10px; }
                    .bill-number, .bill-time { margin-bottom: 5px; }
                    table { width: 100%; border-collapse: collapse; margin: 20px 0; }
                    th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
                    th { background-color: #f8f9fa; }
                    tfoot tr { font-weight: bold; }
                    .bill-footer { text-align: center; margin-top: 30px; }
                    @media print {
                        body { padding: 0; }
                        button { display: none; }
                    }
                </style>
            </head>
            <body>
                ${billContent}
            </body>
        </html>
    `);
    
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => {
        printWindow.print();
        printWindow.close();
    }, 250);
}

// Load inventory on page load
loadInventory();

// Initialize year dropdown
function initializeYearDropdown() {
    const yearSelect = document.getElementById('historyYear');
    const currentYear = new Date().getFullYear();
    const startYear = 2020; // You can adjust this as needed
    
    for (let year = currentYear; year >= startYear; year--) {
        const option = document.createElement('option');
        option.value = year;
        option.textContent = year;
        yearSelect.appendChild(option);
    }
}

// Set current month and year
function setCurrentMonthYear() {
    const now = new Date();
    document.getElementById('historyMonth').value = String(now.getMonth() + 1).padStart(2, '0');
    document.getElementById('historyYear').value = now.getFullYear();
}

// Update filter type change handler
document.getElementById('filterType').addEventListener('change', function() {
    const dateFilterSection = document.getElementById('dateFilterSection');
    const monthFilterSection = document.getElementById('monthFilterSection');
    const productFilterSection = document.getElementById('productFilterSection');
    
    dateFilterSection.style.display = 'none';
    monthFilterSection.style.display = 'none';
    productFilterSection.style.display = 'none';
    
    switch(this.value) {
        case 'date':
            dateFilterSection.style.display = 'block';
            break;
        case 'month':
            monthFilterSection.style.display = 'block';
            break;
        case 'product':
            productFilterSection.style.display = 'block';
            loadProductsForFilter(); // Load products when switching to product filter
            break;
    }
    
    loadHistory();
});

// Initialize product filter when history tab is shown
document.querySelector('.tab-btn[data-tab="history"]').addEventListener('click', function() {
    loadProductsForFilter();
});

// Load products for filter
async function loadProductsForFilter() {
    try {
        const response = await fetch('api/inventory.php?action=list');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        if (data.status === 'success' && Array.isArray(data.data)) {
            const productFilter = document.getElementById('productFilter');
            
            // Store products data for search functionality
            window.productsData = data.data;
            
            // Create datalist for search suggestions
            const datalist = document.createElement('datalist');
            datalist.id = 'productOptions';
            
            // Add default option
            productFilter.innerHTML = '<option value="">All Products</option>';
            
            // Add products to datalist and select
            data.data.forEach(product => {
                // Add to datalist
                const option = document.createElement('option');
                option.value = `${product.name} (${product.brand})`;
                option.dataset.id = product.id;
                option.dataset.itemCode = product.item_code;
                option.dataset.brand = product.brand;
                option.dataset.stock = product.quantity;
                datalist.appendChild(option);
                
                // Add to select
                const selectOption = document.createElement('option');
                selectOption.value = product.id;
                selectOption.textContent = `${product.name} (${product.brand})`;
                selectOption.dataset.itemCode = product.item_code;
                selectOption.dataset.brand = product.brand;
                selectOption.dataset.stock = product.quantity;
                productFilter.appendChild(selectOption);
            });
            
            // Add datalist to document
            document.body.appendChild(datalist);
            
            // Add search functionality to select
            productFilter.addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase();
                const options = this.options;
                
                // Show/hide options based on search
                for (let i = 1; i < options.length; i++) {
                    const option = options[i];
                    const text = option.textContent.toLowerCase();
                    option.style.display = text.includes(searchTerm) ? '' : 'none';
                }
            });
            
            // Add product selection handler
            productFilter.addEventListener('change', function() {
                const selectedOption = this.options[this.selectedIndex];
                const productInfo = document.querySelector('.product-info');
                
                if (this.value) {
                    document.getElementById('selectedItemCode').textContent = selectedOption.dataset.itemCode || '-';
                    document.getElementById('selectedBrand').textContent = selectedOption.dataset.brand || '-';
                    document.getElementById('selectedStock').textContent = selectedOption.dataset.stock || '-';
                    productInfo.style.display = 'block';
                } else {
                    productInfo.style.display = 'none';
                }
                
                // Load sales history with the selected product
                loadHistory();
            });
        }
    } catch (error) {
        console.error('Error loading products for filter:', error);
        showAlert('error', 'Failed to load products: ' + error.message);
    }
}

// Load sales history
async function loadHistory() {
        const filterType = document.getElementById('filterType').value;
        let url = 'api/sales.php?action=history';
        
    try {
        switch(filterType) {
            case 'date':
                const startDate = document.getElementById('startDate').value;
                const endDate = document.getElementById('endDate').value;
                if (!startDate || !endDate) {
                    alert('Please select both start and end dates');
                    return;
                }
                url += `&start_date=${startDate}&end_date=${endDate}`;
                break;
            
            case 'month':
                const month = document.getElementById('historyMonth').value;
                const year = document.getElementById('historyYear').value;
                url += `&month=${month}&year=${year}`;
                break;
                
            case 'product':
                const productId = document.getElementById('productFilter').value;
                if (productId) {
                    url += `&product_id=${productId}`;
                }
                break;
        }
        
        // Show loading state
        const tbody = document.querySelector('#historyTable tbody');
        tbody.innerHTML = '<tr><td colspan="7" style="text-align: center;">Loading...</td></tr>';
        
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        
        const data = await response.json();
        if (!data || !data.status === 'success' || !Array.isArray(data.data)) {
            throw new Error('Invalid response format');
        }
        
        // Clear loading message
            tbody.innerHTML = '';
            
        if (data.data.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" style="text-align: center;">No sales found</td></tr>';
            document.getElementById('totalSales').textContent = '₹0.00';
            document.getElementById('totalTransactions').textContent = '0';
                return;
            }
            
            let totalAmount = 0;
            
        data.data.forEach(sale => {
            const row = document.createElement('tr');
            const saleDate = new Date(sale.sale_date);
            
            row.innerHTML = `
                <td>${formatDateTime(saleDate)}</td>
                <td>${escapeHtml(sale.bill_number)}</td>
                <td>${escapeHtml(sale.product_name)}</td>
                        <td>${escapeHtml(sale.brand)}</td>
                        <td>${sale.quantity}</td>
                        <td>₹${formatCurrency(sale.unit_price)}</td>
                        <td>₹${formatCurrency(sale.total_amount)}</td>
                `;
                
            tbody.appendChild(row);
                totalAmount += parseFloat(sale.total_amount);
            });
            
        // Update summary
        document.getElementById('totalSales').textContent = `₹${formatCurrency(totalAmount)}`;
        document.getElementById('totalTransactions').textContent = data.data.length;
            
    } catch (error) {
        console.error('Error loading sales history:', error);
        const tbody = document.querySelector('#historyTable tbody');
        tbody.innerHTML = '<tr><td colspan="7" style="text-align: center; color: red;">Error loading sales history</td></tr>';
        document.getElementById('totalSales').textContent = '₹0.00';
        document.getElementById('totalTransactions').textContent = '0';
    }
}

// Helper function to format currency
function formatCurrency(amount) {
    return parseFloat(amount).toLocaleString('en-IN', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

// Helper function to format date and time
function formatDateTime(date) {
    return date.toLocaleString('en-US', {
        year: 'numeric',
        month: 'numeric',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true
    });
}

// Helper function to get filter period text
function getFilterPeriodText(filterType) {
    switch(filterType) {
        case 'date':
            const start = new Date(document.getElementById('startDate').value);
            const end = new Date(document.getElementById('endDate').value);
            return `${start.toLocaleDateString()} - ${end.toLocaleDateString()}`;
        
        case 'month':
            const monthSelect = document.getElementById('historyMonth');
            const monthName = monthSelect.options[monthSelect.selectedIndex].text;
            const year = document.getElementById('historyYear').value;
            return `${monthName} ${year}`;
        
        case 'all':
            return 'All Time';
        
        default:
            return '';
    }
}

// Helper function to update summary cards
function updateSummaryCards(totalAmount, transactionCount, periodText) {
    document.getElementById('totalSales').innerHTML = `
        <div class="amount">₹${formatCurrency(totalAmount)}</div>
        <div class="period">${periodText}</div>
    `;
    
    document.getElementById('totalTransactions').innerHTML = `
        <div class="count">${transactionCount}</div>
        <div class="period">${periodText}</div>
    `;
}

// Helper function to escape HTML to prevent XSS
function escapeHtml(unsafe) {
    if (typeof unsafe !== 'string') return '';
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

// Update download function to include date filters
function downloadHistory(format) {
    const filterType = document.getElementById('filterType').value;
    let url = `api/download_history.php?format=${format}`;
    
    switch(filterType) {
        case 'date':
            const startDate = document.getElementById('startDate').value;
            const endDate = document.getElementById('endDate').value;
            if (startDate && endDate) {
                url += `&start_date=${startDate}&end_date=${endDate}`;
            }
            break;
        
        case 'month':
            const month = document.getElementById('historyMonth').value;
            const year = document.getElementById('historyYear').value;
            url += `&month=${month}&year=${year}`;
            break;
    }
    
    window.location.href = url;
}

// Set default dates for date range filter
function setDefaultDates() {
    const today = new Date();
    const startDate = new Date();
    startDate.setDate(today.getDate() - 30); // Default to last 30 days
    
    document.getElementById('startDate').value = startDate.toISOString().split('T')[0];
    document.getElementById('endDate').value = today.toISOString().split('T')[0];
}

// Add event listeners for filter buttons
document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('applyFilter').addEventListener('click', applyFilter);
    document.getElementById('resetFilter').addEventListener('click', resetFilter);
    
    // Initialize controls
    initializeYearDropdown();
    setCurrentMonthYear();
    setDefaultDates();
    loadHistory();
});

// Update top products chart
function updateTopProductsChart(productsData) {
    const ctx = document.getElementById('topProductsChart');
    
    // Destroy existing chart if it exists
    if (topProductsChart instanceof Chart) {
        topProductsChart.destroy();
    }

    const labels = productsData.map(product => product.name);
    const values = productsData.map(product => 
        productsViewMode === 'quantity' ? product.total_quantity : product.total_revenue
    );

    // Create new chart
    topProductsChart = new Chart(ctx, {
        type: 'pie',
        data: {
            labels: labels,
            datasets: [{
                data: values,
                backgroundColor: [
                    'rgba(74, 144, 226, 0.7)',
                    'rgba(46, 204, 113, 0.7)',
                    'rgba(241, 196, 15, 0.7)',
                    'rgba(231, 76, 60, 0.7)',
                    'rgba(155, 89, 182, 0.7)'
                ]
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom'
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const value = context.raw;
                            return productsViewMode === 'quantity' 
                                ? `${context.label}: ${value} units`
                                : `${context.label}: ₹${formatCurrency(value)}`;
                        }
                    }
                }
            }
        }
    });
}

// Update recent sales table with animation
function updateRecentSalesTable(salesData) {
    const tbody = document.querySelector('#recentSalesTable tbody');
    
    if (!Array.isArray(salesData) || salesData.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="no-data">No recent sales found</td></tr>';
        return;
    }
    
    // Clear existing rows with fade out effect
    const existingRows = tbody.querySelectorAll('tr');
    existingRows.forEach(row => {
        row.style.opacity = '0';
        row.style.transform = 'translateY(20px)';
    });

    // Add new rows after a short delay
    setTimeout(() => {
        tbody.innerHTML = salesData.map(sale => `
                <tr class="new-sale-row">
                <td>${formatDateTime(sale.sale_date)}</td>
                <td>${escapeHtml(sale.item_code)}</td>
                    <td>${escapeHtml(sale.product_name)}</td>
                    <td>${sale.quantity}</td>
                    <td>₹${formatCurrency(sale.unit_price)}</td>
                    <td>₹${formatCurrency(sale.total_amount)}</td>
                </tr>
        `).join('');

        // Fade in new rows
        const newRows = tbody.querySelectorAll('.new-sale-row');
        newRows.forEach(row => {
            row.style.opacity = '1';
            row.style.transform = 'translateY(0)';
        });
    }, 300);
}

// Add event listeners for chart toggles
document.getElementById('toggleSalesView').addEventListener('click', function() {
    salesViewMode = salesViewMode === 'amount' ? 'orders' : 'amount';
    this.textContent = `Show ${salesViewMode === 'amount' ? 'Orders' : 'Amount'}`;
    loadDashboard();
});

document.getElementById('toggleProductsView').addEventListener('click', function() {
    productsViewMode = productsViewMode === 'quantity' ? 'revenue' : 'quantity';
    this.textContent = `Show ${productsViewMode === 'quantity' ? 'Revenue' : 'Quantity'}`;
    loadDashboard();
});

// Add refresh button functionality
document.getElementById('refreshSales').addEventListener('click', loadDashboard);

// Initial load of dashboard if it's the active tab
if (document.querySelector('.tab-btn[data-tab="dashboard"]').classList.contains('active')) {
    loadDashboard();
}

// Refresh dashboard data every 5 minutes
setInterval(() => {
    if (document.querySelector('.tab-btn[data-tab="dashboard"]').classList.contains('active')) {
        loadDashboard();
    }
}, 300000);

// Initialize billing form event listener
document.addEventListener('DOMContentLoaded', function() {
    // Load products for billing dropdown
    loadProductsForBilling();

    // Load initial inventory
    loadInventory();

    // Add billing form submit handler
    const billingForm = document.getElementById('billingForm');
    if (billingForm) {
        billingForm.addEventListener('submit', function(e) {
            e.preventDefault();
            addToList();
        });
    }
});

// Load products for billing dropdown
async function loadProductsForBilling() {
    try {
        const response = await fetch('api/inventory.php?action=list');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const result = await response.json();
        if (result.status === 'error') {
            throw new Error(result.message || 'Failed to load products');
        }

        const products = result.data;
        const productSelect = document.querySelector('#billingForm .product-select');
        
        if (!productSelect) {
            throw new Error('Product select element not found');
        }

        // Clear existing options
        productSelect.innerHTML = '<option value="">Select Product</option>';

        // Add products to select
        products.forEach(product => {
            if (product.quantity > 0) { // Only show products with stock
                const option = document.createElement('option');
                option.value = product.id;
                option.textContent = `${product.name} - ${product.brand} (₹${product.sales_price})`;
                option.dataset.price = product.sales_price;
                option.dataset.quantity = product.quantity;
                productSelect.appendChild(option);
            }
        });
    } catch (error) {
        console.error('Error loading products:', error);
        alert('Error loading products. Please try again.');
    }
}

// Add to list function
function addToList() {
        const productSelect = document.querySelector('#billingForm .product-select');
        const quantityInput = document.querySelector('#billingForm .quantity-input');
        
        if (!productSelect || !quantityInput) {
            alert('Error: Form elements not found');
            return;
        }

        if (!productSelect.value || !quantityInput.value) {
            alert('Please select a product and quantity');
            return;
        }

        const selectedOption = productSelect.options[productSelect.selectedIndex];
        if (!selectedOption) {
            alert('Please select a valid product');
            return;
        }

    const quantity = parseInt(quantityInput.value);
    if (isNaN(quantity) || quantity <= 0) {
            alert('Please enter a valid quantity');
            return;
        }

    // Check available quantity
    const availableQuantity = parseInt(selectedOption.dataset.quantity);
    if (quantity > availableQuantity) {
        alert(`Only ${availableQuantity} units available in stock`);
            return;
        }

    // Get the product details from the selected option
    const productId = selectedOption.value;
    const productName = selectedOption.text;
    const price = parseFloat(selectedOption.dataset.price);

    if (isNaN(price)) {
        alert('Error: Invalid product price');
                return;
            }

    // Add to products list
            productsList.push({
        product_id: productId,
        name: productName,
        quantity: quantity,
        price: price,
        total: price * quantity
    });

    // Clear inputs
    productSelect.value = '';
    quantityInput.value = '';

        // Update display
        updateProductsListDisplay();
}

// Add search functionality
const productSearch = document.getElementById('productSearch');
if (productSearch) {
    productSearch.addEventListener('input', function(e) {
        const searchTerm = e.target.value.toLowerCase().trim();
        const rows = document.querySelectorAll('#inventoryTable tbody tr');

        rows.forEach(row => {
            const itemCode = row.querySelector('td:nth-child(1)').textContent.toLowerCase();
            const name = row.querySelector('td:nth-child(2)').textContent.toLowerCase();
            const brand = row.querySelector('td:nth-child(3)').textContent.toLowerCase();
            const description = row.querySelector('td:nth-child(4)').textContent.toLowerCase();
            
            if (itemCode.includes(searchTerm) || 
                name.includes(searchTerm) || 
                brand.includes(searchTerm) || 
                description.includes(searchTerm)) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    });
}

// Add payable search functionality
const payableSearch = document.getElementById('payableSearch');
if (payableSearch) {
    payableSearch.addEventListener('input', function(e) {
        const searchTerm = e.target.value.toLowerCase().trim();
        const rows = document.querySelectorAll('#payableTable tbody tr');

        rows.forEach(row => {
            const invoiceNo = row.querySelector('td:nth-child(1)').textContent.toLowerCase();
            const supplier = row.querySelector('td:nth-child(2)').textContent.toLowerCase();
            const description = row.querySelector('td:nth-child(3)').textContent.toLowerCase();
            
            if (invoiceNo.includes(searchTerm) || 
                supplier.includes(searchTerm) || 
                description.includes(searchTerm)) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    });
}

// Add receivable search functionality
const receivableSearch = document.getElementById('receivableSearch');
if (receivableSearch) {
    receivableSearch.addEventListener('input', function(e) {
        const searchTerm = e.target.value.toLowerCase().trim();
        const rows = document.querySelectorAll('#receivableTable tbody tr');

        rows.forEach(row => {
            const invoiceNo = row.querySelector('td:nth-child(1)').textContent.toLowerCase();
            const supplier = row.querySelector('td:nth-child(2)').textContent.toLowerCase();
            const description = row.querySelector('td:nth-child(3)').textContent.toLowerCase();
            
            if (invoiceNo.includes(searchTerm) || 
                supplier.includes(searchTerm) || 
                description.includes(searchTerm)) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    });
}

// Clear search inputs when switching tabs
document.querySelectorAll('.supplier-tab-btn').forEach(button => {
    button.addEventListener('click', () => {
        // Clear payable search
        const payableSearch = document.getElementById('payableSearch');
        if (payableSearch) {
            payableSearch.value = '';
            const payableRows = document.querySelectorAll('#payableTable tbody tr');
            payableRows.forEach(row => {
                row.style.display = '';
            });
        }

        // Clear receivable search
        const receivableSearch = document.getElementById('receivableSearch');
        if (receivableSearch) {
            receivableSearch.value = '';
            const receivableRows = document.querySelectorAll('#receivableTable tbody tr');
            receivableRows.forEach(row => {
                row.style.display = '';
            });
        }
    });
});

// Function to load suppliers
async function loadSuppliers() {
    try {
        const response = await fetch('api/supplier.php?action=list');
        const data = await response.json();
        
        const tbody = document.querySelector('#supplierTable tbody');
        tbody.innerHTML = '';

        if (data.status === 'success' && Array.isArray(data.data)) {
            data.data.forEach(supplier => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${escapeHtml(supplier.id)}</td>
                    <td>${escapeHtml(supplier.name)}</td>
                    <td>${escapeHtml(supplier.phone)}</td>
                    <td>${escapeHtml(supplier.email)}</td>
                    <td>${escapeHtml(supplier.address)}</td>
                    <td>
                        <div class="action-buttons">
                            <button onclick="editSupplier(${supplier.id})" class="edit-btn" title="Edit supplier">✏️</button>
                            <button onclick="deleteSupplier(${supplier.id})" class="delete-btn" title="Delete supplier">🗑️</button>
                    </div>
                </td>
                `;
                tbody.appendChild(row);
            });
        } else {
            tbody.innerHTML = '<tr><td colspan="6" class="no-data">No suppliers found</td></tr>';
        }
    } catch (error) {
        console.error('Error loading suppliers:', error);
        const tbody = document.querySelector('#supplierTable tbody');
        tbody.innerHTML = '<tr><td colspan="6" class="error">Error loading suppliers</td></tr>';
    }
}

// Function to load purchases
async function loadPurchases() {
    try {
        const response = await fetch('api/purchases.php');
        const data = await response.json();

        const tbody = document.querySelector('#purchaseTable tbody');
        tbody.innerHTML = '';

        if (data.status === 'success' && Array.isArray(data.data)) {
            data.data.forEach((purchase, index) => {
                const row = document.createElement('tr');
                const purchaseDate = new Date(purchase.purchase_date);
                row.innerHTML = `
                    <td>${index + 1}</td>
                    <td>${formatDate(purchaseDate)}</td>
                    <td>${escapeHtml(purchase.supplier_name)}</td>
                    <td>${escapeHtml(purchase.product_name)}</td>
                    <td>${purchase.quantity}</td>
                    <td>₹${formatCurrency(purchase.price_per_unit)}</td>
                    <td>₹${formatCurrency(purchase.total_amount)}</td>
                    <td>${escapeHtml(purchase.notes || '-')}</td>
                    <td>
                        <div class="action-buttons">
                            <button type="button" onclick="editPurchase(${purchase.id})" class="edit-btn btn btn-sm" title="Edit purchase">✏️</button>
                            <button type="button" onclick="deletePurchase(${purchase.id})" class="delete-btn btn btn-sm" title="Delete purchase">🗑️</button>
                        </div>
                    </td>
                `;
                tbody.appendChild(row);
            });
        } else {
            tbody.innerHTML = '<tr><td colspan="9" class="no-data">No purchases found</td></tr>';
        }
    } catch (error) {
        console.error('Error loading purchases:', error);
        const tbody = document.querySelector('#purchaseTable tbody');
        tbody.innerHTML = '<tr><td colspan="9" class="error">Error loading purchases</td></tr>';
    }
}

// Helper function to format date
function formatDate(date) {
    return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

// Load suppliers and purchases when their respective tabs are shown
document.querySelectorAll('.supplier-tab-btn').forEach(button => {
    button.addEventListener('click', () => {
        if (button.dataset.subtab === 'supplier-info') {
            loadSuppliers();
        } else if (button.dataset.subtab === 'purchases') {
            loadPurchases();
        }
    });
});

// Initial load of suppliers if supplier-info tab is active
if (document.querySelector('.supplier-tab-btn[data-subtab="supplier-info"]').classList.contains('active')) {
    loadSuppliers();
}

// Initial load of purchases if purchases tab is active
if (document.querySelector('.supplier-tab-btn[data-subtab="purchases"]').classList.contains('active')) {
    loadPurchases();
}

// Load products for the product filter
async function loadProducts() {
    const productFilter = document.getElementById('productFilter');
    const productSearchFilter = document.getElementById('productSearchFilter');
    
    try {
        const response = await fetch('api/inventory.php?action=list');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const result = await response.json();
        if (result.status !== 'success' || !Array.isArray(result.data)) {
            throw new Error('Invalid data received from server');
        }
        
        // Clear existing options
        productFilter.innerHTML = '<option value="">All Products</option>';
        
        // Add products to dropdown
        result.data.forEach(product => {
            const option = document.createElement('option');
            option.value = product.id;
            option.textContent = `${product.name} (${product.brand})`;
            option.dataset.itemCode = product.item_code;
            option.dataset.brand = product.brand;
            option.dataset.stock = product.quantity;
            productFilter.appendChild(option);
        });
        
        // Add search functionality
        productSearchFilter.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const options = productFilter.options;
            
            for (let i = 1; i < options.length; i++) {
                const option = options[i];
                const text = option.textContent.toLowerCase();
                option.style.display = text.includes(searchTerm) ? '' : 'none';
            }
        });
        
        // Add product selection handler
        productFilter.addEventListener('change', function() {
            const selectedOption = this.options[this.selectedIndex];
            const productInfo = document.querySelector('.product-info');
            
            if (this.value) {
                document.getElementById('selectedItemCode').textContent = selectedOption.dataset.itemCode;
                document.getElementById('selectedBrand').textContent = selectedOption.dataset.brand;
                document.getElementById('selectedStock').textContent = selectedOption.dataset.stock;
                productInfo.style.display = 'block';
            } else {
                productInfo.style.display = 'none';
            }
        });
        
    } catch (error) {
        console.error('Error loading products:', error);
        showAlert('error', 'Failed to load products: ' + error.message);
    }
}

// Apply filter function
async function applyFilter() {
    const filterType = document.getElementById('filterType').value;
    let url = 'api/sales.php?action=history';
    
    try {
        switch(filterType) {
            case 'date':
                const startDate = document.getElementById('startDate').value;
                const endDate = document.getElementById('endDate').value;
                if (!startDate || !endDate) {
                    alert('Please select both start and end dates');
                    return;
                }
                url += `&start_date=${startDate}&end_date=${endDate}`;
                break;
            
            case 'month':
                const month = document.getElementById('historyMonth').value;
                const year = document.getElementById('historyYear').value;
                url += `&month=${month}&year=${year}`;
                break;
        }
        
        // Show loading state
        const tbody = document.querySelector('#historyTable tbody');
        tbody.innerHTML = '<tr><td colspan="7" class="loading">Loading sales history...</td></tr>';
        
        const response = await fetch(url);
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        
        const data = await response.json();
        if (!data || data.status !== 'success' || !Array.isArray(data.data)) {
            throw new Error('Invalid response format');
        }
        
        // Update table with results
        updateHistoryTable(data.data);
        
    } catch (error) {
        console.error('Error applying filters:', error);
        const tbody = document.querySelector('#historyTable tbody');
        tbody.innerHTML = '<tr><td colspan="7" class="error">Error loading sales history</td></tr>';
        document.getElementById('totalSales').textContent = '₹0.00';
        document.getElementById('totalTransactions').textContent = '0';
    }
}

// Reset filter function
function resetFilter() {
    // Reset filter type to default
    document.getElementById('filterType').value = 'all';
    
    // Reset date inputs
    document.getElementById('startDate').value = '';
    document.getElementById('endDate').value = '';
    
    // Reset month/year to current
    setCurrentMonthYear();
    
    // Hide all filter sections
    document.getElementById('dateFilterSection').style.display = 'none';
    document.getElementById('monthFilterSection').style.display = 'none';
    
    // Load all sales history
    loadHistory();
}

// Update history table function
function updateHistoryTable(sales) {
    const tbody = document.querySelector('#historyTable tbody');
    tbody.innerHTML = '';
    
    if (sales.length === 0) {
        tbody.innerHTML = '<tr><td colspan="7" class="no-data">No sales found</td></tr>';
        document.getElementById('totalSales').textContent = '₹0.00';
        document.getElementById('totalTransactions').textContent = '0';
        return;
    }
    
    let totalAmount = 0;
    
    sales.forEach(sale => {
        const row = document.createElement('tr');
        const saleDate = new Date(sale.sale_date);
        
        row.innerHTML = `
            <td>${formatDateTime(saleDate)}</td>
            <td>${escapeHtml(sale.item_code)}</td>
            <td>${escapeHtml(sale.product_name)}</td>
            <td>${escapeHtml(sale.brand)}</td>
            <td>${sale.quantity}</td>
            <td>₹${formatCurrency(sale.unit_price)}</td>
            <td>₹${formatCurrency(sale.total_amount)}</td>
        `;
        
        tbody.appendChild(row);
        totalAmount += parseFloat(sale.total_amount);
    });
    
    // Update summary
    document.getElementById('totalSales').textContent = `₹${formatCurrency(totalAmount)}`;
    document.getElementById('totalTransactions').textContent = sales.length;
}

// Add event listeners for filter buttons
document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('applyFilter').addEventListener('click', applyFilter);
    document.getElementById('resetFilter').addEventListener('click', resetFilter);
    
    // Initialize controls
    initializeYearDropdown();
    setCurrentMonthYear();
    setDefaultDates();
    loadHistory();
}); 

// Function to load products for filter
async function loadProductsForFilter() {
    try {
        const response = await fetch('api/inventory.php?action=list');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        if (data.status === 'success' && Array.isArray(data.data)) {
            const productFilter = document.getElementById('productFilter');
            
            // Store products data for search functionality
            window.productsData = data.data;
            
            // Create datalist for search suggestions
            const datalist = document.createElement('datalist');
            datalist.id = 'productOptions';
            
            // Add default option
            productFilter.innerHTML = '<option value="">All Products</option>';
            
            // Add products to datalist and select
            data.data.forEach(product => {
                // Add to datalist
                const option = document.createElement('option');
                option.value = `${product.name} (${product.brand})`;
                option.dataset.id = product.id;
                option.dataset.itemCode = product.item_code;
                option.dataset.brand = product.brand;
                option.dataset.stock = product.quantity;
                datalist.appendChild(option);
                
                // Add to select
                const selectOption = document.createElement('option');
                selectOption.value = product.id;
                selectOption.textContent = `${product.name} (${product.brand})`;
                selectOption.dataset.itemCode = product.item_code;
                selectOption.dataset.brand = product.brand;
                selectOption.dataset.stock = product.quantity;
                productFilter.appendChild(selectOption);
            });
            
            // Add datalist to document
            document.body.appendChild(datalist);
            
            // Add search functionality to select
            productFilter.addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase();
                const options = this.options;
                
                // Show/hide options based on search
                for (let i = 1; i < options.length; i++) {
                    const option = options[i];
                    const text = option.textContent.toLowerCase();
                    option.style.display = text.includes(searchTerm) ? '' : 'none';
                }
            });
            
            // Add product selection handler
            productFilter.addEventListener('change', function() {
                const selectedOption = this.options[this.selectedIndex];
                const productInfo = document.querySelector('.product-info');
                
                if (this.value) {
                    document.getElementById('selectedItemCode').textContent = selectedOption.dataset.itemCode || '-';
                    document.getElementById('selectedBrand').textContent = selectedOption.dataset.brand || '-';
                    document.getElementById('selectedStock').textContent = selectedOption.dataset.stock || '-';
                    productInfo.style.display = 'block';
                } else {
                    productInfo.style.display = 'none';
                }
                
                // Load sales history with the selected product
                loadHistory();
            });
        }
    } catch (error) {
        console.error('Error loading products for filter:', error);
        showAlert('error', 'Failed to load products: ' + error.message);
    }
}

// Update product selection handler
document.getElementById('productFilter').addEventListener('change', function() {
    const selectedOption = this.options[this.selectedIndex];
    const productInfo = document.querySelector('.product-info');
    
    if (this.value) {
        // Show product info
        document.getElementById('selectedItemCode').textContent = selectedOption.dataset.itemCode || '-';
        document.getElementById('selectedBrand').textContent = selectedOption.dataset.brand || '-';
        document.getElementById('selectedStock').textContent = selectedOption.dataset.stock || '-';
        productInfo.style.display = 'block';
    } else {
        // Hide product info
        productInfo.style.display = 'none';
    }
    
    // Load sales history with the selected product
    loadHistory();
});

// Clear product search when filter type changes
document.getElementById('filterType').addEventListener('change', function() {
    if (this.value !== 'product') {
        document.getElementById('productSearchFilter').value = '';
        document.getElementById('productFilter').value = '';
        document.querySelector('.product-info').style.display = 'none';
    }
});

function updateDailySalesChart(data) {
    console.log('=== Daily Sales Chart Update ===');
    console.log('Raw data received:', data);
    
    const ctx = document.getElementById('dailySalesChart');
    if (!ctx) {
        console.error('Daily sales chart canvas not found');
        return;
    }
    
    // Destroy existing chart if it exists
    if (dailySalesChart instanceof Chart) {
        console.log('Destroying existing chart instance');
        dailySalesChart.destroy();
    }
    
    // Format dates and prepare data
    const labels = data.map(item => {
        const date = new Date(item.date);
        return date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
    });
    
    const values = data.map(item => {
        const value = salesViewMode === 'amount' ? parseFloat(item.total_sales) : parseInt(item.transactions);
        console.log(`Date: ${item.date}, Value: ${value} (${salesViewMode})`);
        return value;
    });
    
    console.log('Formatted labels:', labels);
    console.log('Formatted values:', values);
    console.log('Current view mode:', salesViewMode);
    
    // Create new chart
    try {
        dailySalesChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: salesViewMode === 'amount' ? 'Daily Sales (₹)' : 'Number of Orders',
                    data: values,
                    borderColor: '#4a90e2',
                    backgroundColor: 'rgba(74, 144, 226, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const value = context.raw;
                                return salesViewMode === 'amount' 
                                    ? `₹${formatCurrency(value)}`
                                    : `${value} orders`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)'
                        },
                        ticks: {
                            callback: function(value) {
                                return salesViewMode === 'amount' 
                                    ? '₹' + formatCurrency(value)
                                    : value;
                            }
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
        console.log('Chart created successfully');
    } catch (error) {
        console.error('Error creating chart:', error);
    }
} 