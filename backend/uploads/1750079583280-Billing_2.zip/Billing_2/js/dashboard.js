// Global variables and chart initialization
if (typeof window.dashboardCharts === 'undefined') {
    window.dashboardCharts = {
        topProductsChart: null,
        monthlySalesChart: null,
        monthlyViewMode: 'revenue', // 'revenue' or 'quantity'
        productsViewMode: 'revenue' // 'revenue' or 'quantity'
    };
}

$(document).ready(function() {
    // Initialize charts
    initializeCharts();

    // Initialize event listeners
    $('#toggleProductsView').on('click', function() {
        const btn = $(this);
        const isQuantity = btn.text() === 'Show Quantity';
        btn.text(isQuantity ? 'Show Revenue' : 'Show Quantity');
        window.dashboardCharts.productsViewMode = isQuantity ? 'quantity' : 'revenue';
        loadDashboard();
    });

    $('#toggleMonthlyView').on('click', function() {
        const btn = $(this);
        const isRevenue = window.dashboardCharts.monthlyViewMode === 'revenue';
        btn.text(isRevenue ? 'Show Quantity' : 'Show Revenue');
        window.dashboardCharts.monthlyViewMode = isRevenue ? 'quantity' : 'revenue';
        loadDashboard();
    });

    // Add refresh button handler
    $('#refreshSales').on('click', function() {
        loadDashboard();
    });

    // Initial load
    loadDashboard();

    // Refresh every 5 minutes
    setInterval(loadDashboard, 300000);
});

// Initialize charts
function initializeCharts() {
    initializeTopProductsChart();
    initializeMonthlySalesChart();
}

function initializeTopProductsChart() {
    const topProductsCtx = document.getElementById('topProductsChart');
    if (topProductsCtx) {
        // Destroy existing chart if it exists
        if (window.dashboardCharts.topProductsChart instanceof Chart) {
            window.dashboardCharts.topProductsChart.destroy();
        }

        window.dashboardCharts.topProductsChart = new Chart(topProductsCtx, {
            type: 'pie',
            data: {
                labels: [],
                datasets: [{
                    data: [],
                    backgroundColor: [
                        '#FF9F43',
                        '#28C76F',
                        '#EA5455',
                        '#7367F0',
                        '#00CFE8'
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'right',
                        labels: {
                            padding: 20,
                            usePointStyle: true,
                            pointStyle: 'circle'
                        }
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const value = context.raw;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = ((value / total) * 100).toFixed(1);
                                return window.dashboardCharts.productsViewMode === 'quantity'
                                    ? `${context.label}: ${value} units (${percentage}%)`
                                    : `${context.label}: ₹${formatNumber(value)} (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });
    }
}

function initializeMonthlySalesChart() {
    const monthlySalesCtx = document.getElementById('monthlySalesChart');
    if (monthlySalesCtx) {
        // Destroy existing chart if it exists
        if (window.dashboardCharts.monthlySalesChart instanceof Chart) {
            window.dashboardCharts.monthlySalesChart.destroy();
        }

        window.dashboardCharts.monthlySalesChart = new Chart(monthlySalesCtx, {
            type: 'bar',
            data: {
                labels: [],
                datasets: [{
                    label: 'Monthly Performance',
                    data: [],
                    backgroundColor: '#7367F0',
                    borderRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                const value = context.raw;
                                return window.dashboardCharts.monthlyViewMode === 'revenue'
                                    ? `Revenue: ₹${formatNumber(value)}`
                                    : `Quantity: ${value} units`;
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return window.dashboardCharts.monthlyViewMode === 'revenue'
                                    ? '₹' + formatNumber(value)
                                    : value;
                            }
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
    }
}

// Update charts with new data
function updateCharts(data) {
    if (data.top_products && window.dashboardCharts.topProductsChart) {
        updateTopProductsChart(data.top_products);
    }
    if (data.monthly_comparison && window.dashboardCharts.monthlySalesChart) {
        updateMonthlySalesChart(data.monthly_comparison);
    }
}

function updateTopProductsChart(data) {
    if (!Array.isArray(data)) {
        console.error('Invalid top products data:', data);
        return;
    }

    const labels = data.map(product => product.name || 'Unknown');
    const values = data.map(product => {
        const value = window.dashboardCharts.productsViewMode === 'quantity' 
            ? parseInt(product.total_quantity || 0) 
            : parseFloat(product.total_revenue || 0);
        return isNaN(value) ? 0 : value;
    });

    window.dashboardCharts.topProductsChart.data.labels = labels;
    window.dashboardCharts.topProductsChart.data.datasets[0].data = values;
    window.dashboardCharts.topProductsChart.update();
}

function updateMonthlySalesChart(data) {
    if (!Array.isArray(data)) {
        console.error('Invalid daily comparison data:', data);
        return;
    }

    const labels = data.map(item => {
        try {
            // Ensure we're parsing the date correctly
            const dateParts = item.sale_day.split('-');
            const date = new Date(dateParts[0], dateParts[1] - 1, dateParts[2]); // Year, Month (0-based), Day
            
            // For debugging
            console.log('Date parts:', dateParts);
            console.log('Parsed date:', date);
            
            return date.toLocaleDateString('en-US', { 
                weekday: 'short', 
                month: 'short', 
                day: 'numeric'
            });
        } catch (e) {
            console.error('Error formatting date:', e, 'Raw date value:', item.sale_day);
            return 'Invalid Date';
        }
    });
    
    const values = data.map(item => {
        const value = window.dashboardCharts.monthlyViewMode === 'revenue'
            ? parseFloat(item.total_revenue || 0)
            : parseInt(item.total_quantity || 0);
        return isNaN(value) ? 0 : value;
    });

    window.dashboardCharts.monthlySalesChart.data.labels = labels;
    window.dashboardCharts.monthlySalesChart.data.datasets[0].label = 
        window.dashboardCharts.monthlyViewMode === 'revenue' ? 'Daily Revenue' : 'Daily Quantity';
    window.dashboardCharts.monthlySalesChart.data.datasets[0].data = values;
    window.dashboardCharts.monthlySalesChart.update();
}

// Format number with commas and decimals
function formatNumber(number) {
    return new Intl.NumberFormat('en-IN', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(number || 0);
}

// Update dashboard statistics
function updateDashboardStats(data) {
    // Update Today's Sales
    if (data.today) {
        $('#todaySales').text('₹' + formatNumber(data.today.sales));
        $('#todayOrders').text(data.today.transactions + ' orders');
    }

    // Update This Month
    if (data.month) {
        $('#monthSales').text('₹' + formatNumber(data.month.sales));
        $('#monthOrders').text(data.month.transactions + ' orders');
        $('#avgOrderValue').text('₹' + formatNumber(data.month.avg_transaction));
    }

    // Update Total Products
    if (data.inventory) {
        $('#totalProducts').text(data.inventory.total_products);
        $('#lowStock').text(data.inventory.low_stock_items + ' out of stock');
    }
}

// Update recent sales table
function updateRecentSales(sales) {
    const tbody = $('#recentSalesTable tbody');
    tbody.empty();

    if (!Array.isArray(sales) || sales.length === 0) {
        tbody.append('<tr><td colspan="6" class="text-center">No recent sales found</td></tr>');
        return;
    }

    // Sort sales by date and id in descending order (most recent first)
    sales.sort((a, b) => {
        const dateA = new Date(a.sale_date);
        const dateB = new Date(b.sale_date);
        if (dateB - dateA === 0) {
            return b.id - a.id;
        }
        return dateB - dateA;
    });

    // Take only the first 5 sales
    sales.slice(0, 5).forEach(sale => {
        const row = $('<tr>');
        row.append(`<td>${formatDateTime(sale.sale_date)}</td>`);
        row.append(`<td>${sale.bill_number}</td>`);
        row.append(`<td>${sale.product_name}</td>`);
        row.append(`<td class="text-center">${sale.quantity}</td>`);
        row.append(`<td class="text-right">₹${sale.unit_price}</td>`);
        row.append(`<td class="text-right">₹${sale.total_amount}</td>`);
        tbody.append(row);
    });
}

// Format date and time
function formatDateTime(dateString) {
    const date = new Date(dateString);
    return date.toLocaleString('en-IN', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
}

// Load dashboard data
function loadDashboard() {
    $.ajax({
        url: window.BASE_URL + '/api/dashboard.php',
        method: 'GET',
        dataType: 'json',
        success: function(response) {
            if (response.status === 'success' && response.data) {
                updateDashboardStats(response.data);
                updateCharts(response.data);
                updateRecentSales(response.data.recent_sales);
            } else {
                console.error('Failed to load dashboard data:', response.message || 'Unknown error');
            }
        },
        error: function(xhr, status, error) {
            console.error('Network error while loading dashboard:', error);
            console.error('Dashboard error details:', xhr.responseText);
        }
    });
}

function updateTables(data) {
    // Recent Sales Table
    const recentSalesTable = $('#recentSalesTable tbody');
    recentSalesTable.empty();

    if (data.recent_sales && data.recent_sales.length > 0) {
        data.recent_sales.forEach(sale => {
            recentSalesTable.append(`
                <tr>
                    <td>${formatDateTime(sale.sale_date)}</td>
                    <td>${sale.item_code}</td>
                    <td>${escapeHtml(sale.product_name)}</td>
                    <td>${sale.quantity}</td>
                    <td>₹${formatNumber(sale.unit_price)}</td>
                    <td>₹${formatNumber(sale.total_amount)}</td>
                </tr>
            `);
        });
    } else {
        recentSalesTable.append('<tr><td colspan="6" class="no-data">No recent sales</td></tr>');
    }
}

// Utility functions
function formatDate(dateString) {
    try {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-IN', {
            month: 'short',
            day: 'numeric'
        });
    } catch (e) {
        return dateString;
    }
}

function escapeHtml(unsafe) {
    if (typeof unsafe !== 'string') return '';
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function showError(message) {
    const alertsContainer = $('#alerts-container');
    if (alertsContainer.length === 0) {
        $('body').append('<div id="alerts-container"></div>');
    }
    
    const alert = $('<div class="alert alert-error"></div>').text(message);
    $('#alerts-container').append(alert);
    
    setTimeout(() => {
        alert.fadeOut(300, function() {
            $(this).remove();
            if ($('#alerts-container').children().length === 0) {
                $('#alerts-container').remove();
            }
        });
    }, 3000);
} 