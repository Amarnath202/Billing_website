document.addEventListener('DOMContentLoaded', function() {
    console.log('Billing page loaded');
    
    // Initialize date field with current date
    const dateField = document.getElementById('billDate');
    if (dateField) {
        dateField.valueAsDate = new Date();
    }
    
    // Generate bill number
    const timestamp = new Date().getTime();
    const random = Math.floor(Math.random() * 1000);
    const billNumberInput = document.getElementById('billNumber');
    if (billNumberInput) {
        billNumberInput.value = `BILL-${timestamp}-${random}`;
    }

    let products = [];
    let billItems = [];
    let currentBillProcessed = false;

    // Add to List button click handler
    const addToListBtn = document.querySelector('.add-to-list-btn');
    if (addToListBtn) {
        addToListBtn.addEventListener('click', function() {
            const productSelect = document.getElementById('product');
            const quantityInput = document.getElementById('quantity');
            
            if (!productSelect || !quantityInput) {
                console.error('Product or quantity input not found');
                return;
            }
            
            const productId = productSelect.value;
            const quantity = parseInt(quantityInput.value);
            
            if (!productId) {
                alert('Please select a product');
                return;
            }

            if (!quantity || quantity < 1) {
                alert('Please enter a valid quantity');
                return;
            }

            const selectedProduct = products.find(p => p.id === productId);
            if (!selectedProduct) {
                alert('Invalid product selected');
                return;
            }

            // Add item to bill
            const item = {
                id: selectedProduct.id,
                name: selectedProduct.name,
                quantity: quantity,
                price: parseFloat(selectedProduct.sales_price),
                total: quantity * parseFloat(selectedProduct.sales_price)
            };

            billItems.push(item);
            updateBillDisplay();
            
            // Reset form
            productSelect.value = '';
            quantityInput.value = '';
        });
    }

    // Load products
    fetch(BASE_URL + '/api/products.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                products = data.products;
                const productSelect = document.getElementById('product');
                
                if (!productSelect) {
                    console.error('Product select element not found');
                    return;
                }
                
                // Clear existing options except the first one
                while (productSelect.options.length > 1) {
                    productSelect.remove(1);
                }
                
                // Add new options
                products.forEach(product => {
                    const option = document.createElement('option');
                    option.value = product.id;
                    option.textContent = `${product.name} (₹${product.sales_price})`;
                    productSelect.appendChild(option);
                });
            } else {
                console.error('Failed to load products:', data.message);
                alert('Failed to load products. Please refresh the page.');
            }
        })
        .catch(error => {
            console.error('Error loading products:', error);
            alert('Error loading products. Please refresh the page.');
        });

    // Handle form submission
    const billingForm = document.getElementById('billingForm');
    if (billingForm) {
        billingForm.addEventListener('submit', function(e) {
            e.preventDefault();
            processSale();
        });
    }

    // Process Sale button click handler
    const processSaleBtn = document.querySelector('.process-sale-btn');
    if (processSaleBtn) {
        processSaleBtn.addEventListener('click', function(e) {
            e.preventDefault();
            processSale();
        });
    }

    // Print Bill button click handler
    const printBillBtn = document.querySelector('.print-bill-btn');
    if (printBillBtn) {
        printBillBtn.addEventListener('click', function() {
            if (!currentBillProcessed) {
                alert('Please process the sale first');
                return;
            }
            openPrintWindow();
        });
    }

    // Process sale function
    function processSale() {
        if (billItems.length === 0) {
            alert('Please add items to the bill');
            return;
        }

        const billNumber = document.getElementById('billNumber');
        const total = document.getElementById('total');

        if (!billNumber || !total) {
            console.error('Required elements not found');
            return;
        }

        const saleData = {
            bill_number: billNumber.value,
            items: billItems,
            total: parseFloat(total.textContent.replace('₹', ''))
        };

        // Process the sale
        fetch(BASE_URL + '/api/process_sale.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(saleData)
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Sale processed successfully!');
                currentBillProcessed = true;
                
                const printBtn = document.querySelector('.print-bill-btn');
                const processBtn = document.querySelector('.process-sale-btn');
                
                if (printBtn) printBtn.disabled = false;
                if (processBtn) processBtn.disabled = true;
            } else {
                alert('Error processing sale: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Error processing sale. Please try again.');
        });
    }

    // Update bill display
    function updateBillDisplay() {
        const billItemsTableBody = document.querySelector('#billItemsTable tbody');
        const total = document.getElementById('total');
        
        if (!billItemsTableBody || !total) {
            console.error('Required elements not found');
            return;
        }

        if (billItems.length === 0) {
            billItemsTableBody.innerHTML = '<tr><td colspan="5" class="text-center">No items added to bill yet</td></tr>';
            total.textContent = '₹0.00';
            return;
        }

        // Display items
        let html = '';
        let totalAmount = 0;
        
        billItems.forEach((item, index) => {
            html += `
                <tr>
                    <td>${item.name}</td>
                    <td>₹${item.price.toFixed(2)}</td>
                    <td>${item.quantity}</td>
                    <td>₹${item.total.toFixed(2)}</td>
                    <td>
                        <button type="button" class="remove-item-btn" data-index="${index}">Remove</button>
                    </td>
                </tr>
            `;
            totalAmount += item.total;
        });
        
        billItemsTableBody.innerHTML = html;
        total.textContent = `₹${totalAmount.toFixed(2)}`;

        // Add event listeners to remove buttons
        document.querySelectorAll('.remove-item-btn').forEach(button => {
            button.addEventListener('click', function() {
                const index = parseInt(this.getAttribute('data-index'));
                if (!isNaN(index)) {
                    billItems.splice(index, 1);
                    updateBillDisplay();
                }
            });
        });

        // Enable/disable print button based on items
        const printBtn = document.querySelector('.print-bill-btn');
        if (printBtn) {
            printBtn.disabled = billItems.length === 0;
        }
    }

    // Function to open print window
    function openPrintWindow() {
        // Get the current date in a formatted string
        const today = new Date();
        const dateString = today.toLocaleDateString('en-IN', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric'
        });

        // Create the print window content
        const printContent = `
            <!DOCTYPE html>
            <html>
            <head>
                <title>Bill - ${document.getElementById('billNumber').value}</title>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        margin: 0;
                        padding: 20px;
                        background: #fff;
                    }
                    .bill-container {
                        max-width: 800px;
                        margin: 0 auto;
                        padding: 20px;
                        border: 1px solid #ccc;
                        box-shadow: 0 0 10px rgba(0,0,0,0.1);
                    }
                    .bill-header {
                        text-align: center;
                        margin-bottom: 20px;
                        padding-bottom: 10px;
                        border-bottom: 2px solid #333;
                    }
                    .bill-header h1 {
                        margin: 0;
                        color: #333;
                        font-size: 24px;
                    }
                    .bill-info {
                        margin-bottom: 20px;
                        display: flex;
                        justify-content: space-between;
                    }
                    .bill-info p {
                        margin: 5px 0;
                    }
                    table {
                        width: 100%;
                        border-collapse: collapse;
                        margin-bottom: 20px;
                    }
                    th, td {
                        padding: 10px;
                        text-align: left;
                        border-bottom: 1px solid #ddd;
                    }
                    th {
                        background-color: #f5f5f5;
                        font-weight: bold;
                    }
                    .total-section {
                        text-align: right;
                        margin-top: 20px;
                        padding-top: 10px;
                        border-top: 2px solid #333;
                    }
                    .total-section h3 {
                        margin: 5px 0;
                    }
                    .thank-you {
                        text-align: center;
                        margin-top: 30px;
                        color: #666;
                    }
                    .print-buttons {
                        text-align: center;
                        margin-top: 20px;
                        padding-top: 20px;
                        border-top: 1px solid #ddd;
                    }
                    .print-buttons button {
                        padding: 10px 20px;
                        margin: 0 10px;
                        border: none;
                        border-radius: 5px;
                        cursor: pointer;
                        font-size: 14px;
                    }
                    .print-btn {
                        background-color: #4CAF50;
                        color: white;
                    }
                    .close-btn {
                        background-color: #f44336;
                        color: white;
                    }
                    @media print {
                        .print-buttons {
                            display: none;
                        }
                    }
                </style>
            </head>
            <body>
                <div class="bill-container">
                    <div class="bill-header">
                        <h1>Billing System</h1>
                    </div>
                    <div class="bill-info">
                        <div>
                            <p><strong>Bill Number:</strong> ${document.getElementById('billNumber').value}</p>
                            <p><strong>Date:</strong> ${dateString}</p>
                        </div>
                    </div>
                    <table>
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${billItems.map(item => `
                                <tr>
                                    <td>${item.name}</td>
                                    <td>₹${item.price.toFixed(2)}</td>
                                    <td>${item.quantity}</td>
                                    <td>₹${item.total.toFixed(2)}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                    <div class="total-section">
                        <h3>Total Amount: ₹${document.getElementById('total').textContent}</h3>
                    </div>
                    <div class="thank-you">
                        <p>Thank you for your business!</p>
                        <p>Please visit again</p>
                    </div>
                    <div class="print-buttons">
                        <button class="print-btn" onclick="window.print();">Print Bill</button>
                        <button class="close-btn" onclick="window.close();">Close</button>
                    </div>
                </div>
            </body>
            </html>
        `;

        // Open new window and write content
        const printWindow = window.open('', 'Print Bill', 'height=600,width=800');
        printWindow.document.write(printContent);
        printWindow.document.close();
    }
});

// Initialize all event listeners
function initializeEventListeners() {
    console.log('Initializing event listeners');
    
    // Product selection change
    const productSelect = document.getElementById('product');
    if (productSelect) {
        productSelect.addEventListener('change', handleProductSelection);
        console.log('Product select event listener added');
    } else {
        console.error('Product select element not found');
    }
    
    // Form submission
    const billingForm = document.getElementById('billingForm');
    if (billingForm) {
        billingForm.addEventListener('submit', function(e) {
            e.preventDefault();
            addItemToBill();
        });
        console.log('Billing form event listener added');
    }
    
    // Amount paid input
    const amountPaidInput = document.getElementById('amountPaid');
    if (amountPaidInput) {
        amountPaidInput.addEventListener('input', calculateBalance);
        console.log('Amount paid event listener added');
    }
    
    // Button actions
    document.getElementById('newBillBtn').addEventListener('click', resetBill);
    document.getElementById('printBillBtn').addEventListener('click', printBill);
    document.getElementById('saveBillBtn').addEventListener('click', saveBill);
    document.getElementById('clearBillBtn').addEventListener('click', clearBill);
}

// Load products into dropdown
function loadProducts() {
    console.log('Loading products...');
    
    // Get base URL from meta tag
    const baseUrl = document.querySelector('meta[name="base-url"]').content;
    const apiUrl = `${baseUrl}/api/inventory.php?action=list`;
    console.log('API URL:', apiUrl);
    
    fetch(apiUrl)
        .then(response => {
            console.log('API Response:', response);
            if (!response.ok) {
                throw new Error('Network response was not ok: ' + response.status);
            }
            return response.json();
        })
        .then(data => {
            console.log('Products data:', data);
            
            if (!data || data.status !== 'success' || !Array.isArray(data.data)) {
                throw new Error('Invalid data format received from server');
            }

            const select = document.getElementById('product');
            if (!select) {
                throw new Error('Product select element not found');
            }
            
            select.innerHTML = '<option value="">Select Product</option>';
            
            data.data.forEach(product => {
                if (product.quantity > 0) { // Only show products with stock
                    const option = document.createElement('option');
                    option.value = product.id;
                    option.textContent = `${product.name} - ${product.brand} (₹${product.sales_price})`;
                    option.dataset.price = product.sales_price;
                    option.dataset.code = product.item_code;
                    option.dataset.quantity = product.quantity;
                    select.appendChild(option);
                }
            });

            if (data.data.length === 0) {
                console.log('No products found in database');
                showError('No products available');
            } else if (select.options.length === 1) {
                console.log('No products with stock found');
                showError('No products available in stock');
            } else {
                console.log(`Loaded ${data.data.length} products`);
            }
        })
        .catch(error => {
            console.error('Error loading products:', error);
            showError('Failed to load products: ' + error.message);
        });
}

// Handle product selection
function handleProductSelection(e) {
    const selectedOption = e.target.options[e.target.selectedIndex];
    const quantityInput = document.getElementById('quantity');
    
    if (!quantityInput) {
        console.error('Quantity input not found');
        return;
    }
    
    if (selectedOption.value) {
        const maxQuantity = parseInt(selectedOption.dataset.quantity);
        quantityInput.max = maxQuantity;
        quantityInput.placeholder = `Max: ${maxQuantity}`;
        console.log(`Selected product: ${selectedOption.textContent}, Max quantity: ${maxQuantity}`);
    } else {
        quantityInput.removeAttribute('max');
        quantityInput.placeholder = 'Enter quantity';
    }
}

// Add item to bill
function addItemToBill() {
    const productSelect = document.getElementById('product');
    const selectedOption = productSelect.options[productSelect.selectedIndex];
    const quantityInput = document.getElementById('quantity');
    
    if (!productSelect.value) {
        showError('Please select a product');
        return;
    }

    const quantity = parseInt(quantityInput.value);
    const maxQuantity = parseInt(selectedOption.dataset.quantity);
    
    if (!quantity || quantity < 1) {
        showError('Please enter a valid quantity');
        return;
    }

    if (quantity > maxQuantity) {
        showError(`Only ${maxQuantity} units available in stock`);
        return;
    }

    const price = parseFloat(selectedOption.dataset.price);
    const total = quantity * price;

    // Create or update bill details
    const billDetails = document.getElementById('billDetails');
    const noItemsMsg = billDetails.querySelector('.no-items');
    if (noItemsMsg) {
        noItemsMsg.remove();
    }

    // Check if we need to create the table
    let table = billDetails.querySelector('table');
    if (!table) {
        table = document.createElement('table');
        table.id = 'billItemsTable';
        table.innerHTML = `
            <thead>
                <tr>
                    <th>Code</th>
                    <th>Product</th>
                    <th>Quantity</th>
                    <th>Price</th>
                    <th>Total</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody></tbody>
        `;
        billDetails.appendChild(table);
    }

    const tbody = table.querySelector('tbody');
    const row = document.createElement('tr');
    row.innerHTML = `
        <td>${selectedOption.dataset.code}</td>
        <td>${selectedOption.textContent}</td>
        <td>${quantity}</td>
        <td>₹${formatNumber(price)}</td>
        <td>₹${formatNumber(total)}</td>
        <td>
            <button onclick="removeItem(this)" class="action-btn delete-btn" type="button">
                <span class="icon">🗑️</span>
            </button>
        </td>
    `;
    tbody.appendChild(row);

    // Show bill summary and process sale button
    document.querySelector('.bill-summary').style.display = 'block';
    document.getElementById('processSaleBtn').style.display = 'block';

    // Update totals
    updateTotals();

    // Reset form
    productSelect.value = '';
    quantityInput.value = '';
    quantityInput.removeAttribute('max');
    quantityInput.placeholder = 'Enter quantity';
}

// Remove item from bill
function removeItem(button) {
    const row = button.closest('tr');
    const tbody = row.parentElement;
    row.remove();

    // If no items left, show the no items message and hide process button
    if (tbody.children.length === 0) {
        const billDetails = document.getElementById('billDetails');
        billDetails.innerHTML = '<p class="no-items">No products added to bill yet</p>';
        document.getElementById('processSaleBtn').style.display = 'none';
        document.querySelector('.bill-summary').style.display = 'none';
    } else {
        // Update totals if items remain
        updateTotals();
    }
}

// Update bill totals
function updateTotals() {
    const rows = document.querySelectorAll('#billItemsTable tbody tr');
    let subtotal = 0;

    rows.forEach(row => {
        const total = parseFloat(row.cells[4].textContent.replace('₹', '').replace(/,/g, ''));
        subtotal += total;
    });

    const gst = subtotal * 0.18;
    const total = subtotal + gst;

    document.getElementById('subtotal').textContent = formatNumber(subtotal);
    document.getElementById('gst').textContent = formatNumber(gst);
    document.getElementById('total').textContent = formatNumber(total);

    // Update balance if amount paid is set
    calculateBalance();
}

// Calculate balance
function calculateBalance() {
    const total = parseFloat(document.getElementById('total').textContent.replace(/,/g, ''));
    const amountPaid = parseFloat(document.getElementById('amountPaid').value) || 0;
    const balance = amountPaid - total;
    
    document.getElementById('balance').value = formatNumber(balance);
}

// Generate new bill number
function generateBillNumber() {
    const date = new Date();
    const year = date.getFullYear().toString().substr(-2);
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    
    const billNumberField = document.getElementById('billNumber');
    if (billNumberField) {
        billNumberField.value = `BILL-${year}${month}${day}-${random}`;
    }
}

// Save bill
function saveBill() {
    const billData = {
        billNumber: document.getElementById('billNumber').value,
        date: document.getElementById('billDate').value,
        customerName: document.getElementById('customerName').value,
        customerPhone: document.getElementById('customerPhone').value,
        customerAddress: document.getElementById('customerAddress').value,
        items: [],
        subtotal: parseFloat(document.getElementById('subtotal').textContent),
        gst: parseFloat(document.getElementById('gst').textContent),
        total: parseFloat(document.getElementById('total').textContent),
        paymentMode: document.getElementById('paymentMode').value,
        amountPaid: parseFloat(document.getElementById('amountPaid').value) || 0,
        balance: parseFloat(document.getElementById('balance').value)
    };

    // Collect items
    document.querySelectorAll('#billItemsTable tbody tr').forEach(row => {
        billData.items.push({
            itemCode: row.cells[0].textContent,
            productName: row.cells[1].textContent,
            quantity: parseInt(row.cells[2].textContent),
            price: parseFloat(row.cells[3].textContent.replace('₹', '')),
            total: parseFloat(row.cells[4].textContent.replace('₹', ''))
        });
    });

    // Validate
    if (!billData.customerName) {
        showNotification('Please enter customer name', 'error');
        return;
    }
    if (billData.items.length === 0) {
        showNotification('Please add at least one item', 'error');
        return;
    }
    if (!billData.paymentMode) {
        showNotification('Please select payment mode', 'error');
        return;
    }

    // Save to server
    fetchData('/api/bills', {
        method: 'POST',
        body: JSON.stringify(billData)
    })
    .then(() => {
        showNotification('Bill saved successfully');
        if (confirm('Do you want to print the bill?')) {
            printBill();
        }
        resetBill();
    });
}

// Print bill
function printBill() {
    window.print();
}

// Reset bill
function resetBill() {
    // Clear customer info
    document.getElementById('customerName').value = '';
    document.getElementById('customerPhone').value = '';
    document.getElementById('customerAddress').value = '';
    
    // Clear items
    document.querySelector('#billItemsTable tbody').innerHTML = '';
    
    // Reset totals
    document.getElementById('subtotal').textContent = '0.00';
    document.getElementById('gst').textContent = '0.00';
    document.getElementById('total').textContent = '0.00';
    
    // Reset payment
    document.getElementById('paymentMode').value = '';
    document.getElementById('amountPaid').value = '';
    document.getElementById('balance').value = '';
    
    // Generate new bill number
    generateBillNumber();
    
    // Set current date
    document.getElementById('billDate').valueAsDate = new Date();
    
    // Disable print button
    document.getElementById('printBillBtn').disabled = true;
}

// Clear current bill
function clearBill() {
    if (confirm('Are you sure you want to clear the current bill?')) {
        resetBill();
    }
}

// Format number with commas
function formatNumber(number) {
    return number.toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
}

// Show error message
function showError(message) {
    console.error('Error:', message);
    alert(message); // For now, using alert, but you should replace this with a better UI
} 