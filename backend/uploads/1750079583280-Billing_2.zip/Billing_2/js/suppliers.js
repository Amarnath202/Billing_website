// Tab Management
document.addEventListener('DOMContentLoaded', function() {
    try {
        console.log('Initializing supplier management...');
        
        // Initialize all components
        initializeTabs();
        initializeModals();
        initializeForms();
        loadInitialData();
        
        // Set initial active tab
        const defaultTab = document.querySelector('.tab-button[data-tab="supplier-info"]');
        if (defaultTab) {
            defaultTab.click();
        }
        
        console.log('Initialization complete.');
    } catch (error) {
        console.error('Error during initialization:', error);
    }
});

function initializeTabs() {
    console.log('Initializing tabs...');
    const tabButtons = document.querySelectorAll('.tab-button');
    const tabContents = document.querySelectorAll('.tab-content');

    if (!tabButtons.length || !tabContents.length) {
        console.warn('Tab elements not found');
        return;
    }

    tabButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            e.preventDefault();
            console.log('Tab clicked:', button.getAttribute('data-tab'));

            // Remove active class from all buttons and contents
            tabButtons.forEach(btn => btn.classList.remove('active'));
            tabContents.forEach(content => content.classList.remove('active'));

            // Add active class to clicked button and corresponding content
            button.classList.add('active');
            const tabId = button.getAttribute('data-tab');
            const targetContent = document.getElementById(tabId);
            if (targetContent) {
                targetContent.classList.add('active');
                // Load data based on active tab
                switch(tabId) {
                    case 'supplier-info':
                        loadSuppliers();
                        break;
                    case 'purchases':
                        loadPurchases();
                        break;
                    case 'account-payable':
                        loadPayables();
                        break;
                    case 'account-receivable':
                        loadReceivables();
                        break;
                }
            } else {
                console.warn(`Tab content not found for id: ${tabId}`);
            }
        });
    });
    console.log('Tabs initialized with', tabButtons.length, 'buttons');
}

function initializeModals() {
    console.log('Initializing modals...');
    const modals = {
        supplier: {
            modal: document.getElementById('supplierModal'),
            openBtn: document.getElementById('addSupplierBtn'),
            form: document.getElementById('supplierForm')
        },
        purchase: {
            modal: document.getElementById('purchaseModal'),
            openBtn: document.getElementById('addPurchaseBtn'),
            form: document.getElementById('purchaseForm')
        },
        payable: {
            modal: document.getElementById('payableModal'),
            openBtn: document.getElementById('addPayableBtn'),
            form: document.getElementById('payableForm')
        },
        receivable: {
            modal: document.getElementById('receivableModal'),
            openBtn: document.getElementById('addReceivableBtn'),
            form: document.getElementById('receivableForm')
        }
    };

    // Initialize modal handlers
    Object.values(modals).forEach(({ modal, openBtn, form }) => {
        if (!modal || !openBtn || !form) {
            console.error('Missing modal elements:', { modal, openBtn, form });
            return;
        }

        // Open modal handler
        openBtn.addEventListener('click', () => {
            openModal(modal);
            form.reset();
            
            // Load data for purchase form
            if (form.id === 'purchaseForm') {
                loadPurchaseFormData();
            }
            
            // Load suppliers for select dropdowns
            if (form.id === 'payableForm' || form.id === 'receivableForm') {
                loadSuppliersForSelect(form.querySelector('select[name="supplier_id"]'));
            }
        });

        // Close button handler
        const closeBtn = modal.querySelector('.close');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => closeModal(modal));
        }

        // Cancel button handler
        const cancelBtn = modal.querySelector('.cancel-btn');
        if (cancelBtn) {
            cancelBtn.addEventListener('click', () => closeModal(modal));
        }

        // Outside click handler
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                closeModal(modal);
            }
        });
    });
}

function openModal(modal) {
    if (!modal) return;
    
    // Close any open modals first
    const openModals = document.querySelectorAll('.modal[style*="display: flex"]');
    openModals.forEach(m => closeModal(m));
    
    // Open the new modal
    modal.style.display = 'flex';
    document.body.classList.add('modal-open');
    
    // Focus the first input
    const firstInput = modal.querySelector('input:not([type="hidden"])');
    if (firstInput) {
        firstInput.focus();
    }
}

function closeModal(modal) {
    if (!modal) return;
    
    modal.style.display = 'none';
    
    // Only remove modal-open class if no other modals are open
    const openModals = document.querySelectorAll('.modal[style*="display: flex"]');
    if (openModals.length === 0) {
        document.body.classList.remove('modal-open');
    }
    
    // Reset the form if it exists
    const form = modal.querySelector('form');
    if (form) {
        form.reset();
    }
}

function initializeForms() {
    console.log('Initializing forms...');
    const forms = {
        supplier: document.getElementById('supplierForm'),
        purchase: document.getElementById('purchaseForm'),
        payable: document.getElementById('payableForm'),
        receivable: document.getElementById('receivableForm')
    };

    if (forms.supplier) {
        console.log('Adding supplier form handler...');
        forms.supplier.addEventListener('submit', handleSupplierSubmit);
    }

    if (forms.purchase) {
        console.log('Adding purchase form handler...');
        forms.purchase.addEventListener('submit', handlePurchaseSubmit);
    }

    if (forms.payable) {
        console.log('Adding payable form handler...');
        forms.payable.addEventListener('submit', handlePayableSubmit);
    }

    if (forms.receivable) {
        console.log('Adding receivable form handler...');
        forms.receivable.addEventListener('submit', handleReceivableSubmit);
    }

    console.log('Forms initialized.');
}

async function handleSupplierSubmit(e) {
    e.preventDefault();
    console.log('Handling supplier form submission...');
    
    try {
        // Convert form data to JSON
        const formData = new FormData(e.target);
        const data = Object.fromEntries(formData.entries());
        
        // Combine address fields
        const addressData = {
            name: data.name,
            phone: data.phone,
            email: data.email || null,
            street: data.address || '',
            city: data.city || '',
            state: data.state || ''
        };

        const response = await fetch('api/suppliers.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(addressData)
        });

        const result = await response.json();
        
        if (result.success) {
            closeModal(document.getElementById('supplierModal'));
            loadSuppliers();
            showAlert('success', 'Supplier saved successfully');
        } else {
            throw new Error(result.message || 'Error saving supplier');
        }
    } catch (error) {
        console.error('Error saving supplier:', error);
        showAlert('error', error.message || 'Error saving supplier');
    }
}

async function handlePurchaseSubmit(e) {
    e.preventDefault();
    console.log('Handling purchase form submission...');
    
    try {
        const formData = new FormData(e.target);
        const data = Object.fromEntries(formData.entries());
        
        // Convert form data to the format expected by the API
        const purchaseData = {
            date: data.date,
            supplierId: parseInt(data.supplier_id),
            productId: parseInt(data.product),
            quantity: parseInt(data.quantity),
            pricePerUnit: parseFloat(data.rate),
            notes: data.notes || ''
        };

        const response = await fetch('api/purchases.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(purchaseData)
        });

        const result = await response.json();
        
        if (result.success) {
            closeModal(document.getElementById('purchaseModal'));
            loadPurchases();
            showAlert('success', 'Purchase saved successfully');
        } else {
            throw new Error(result.message || 'Error saving purchase');
        }
    } catch (error) {
        console.error('Error saving purchase:', error);
        showAlert('error', error.message || 'Error saving purchase');
    }
}

async function handlePayableSubmit(e) {
    e.preventDefault();
    console.log('Handling payable form submission...');
    
    try {
        const formData = new FormData(e.target);
        const data = Object.fromEntries(formData.entries());
        
        const response = await fetch('api/account_payable.php', {
            method: data.id ? 'PUT' : 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        const result = await response.json();
        
        if (result.success) {
            showAlert('success', data.id ? 'Payable updated successfully' : 'Payable added successfully');
            closeModal(document.getElementById('payableModal'));
            loadPayables();
        } else {
            throw new Error(result.message || 'Failed to save payable');
        }
    } catch (error) {
        console.error('Error saving payable:', error);
        showAlert('error', error.message);
    }
}

async function handleReceivableSubmit(e) {
    e.preventDefault();
    console.log('Handling receivable form submission...');
    
    try {
        const formData = new FormData(e.target);
        const data = Object.fromEntries(formData.entries());
        
        const response = await fetch('api/account_receivable.php', {
            method: data.id ? 'PUT' : 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        const result = await response.json();
        
        if (result.success) {
            showAlert('success', data.id ? 'Receivable updated successfully' : 'Receivable added successfully');
            closeModal(document.getElementById('receivableModal'));
            loadReceivables();
        } else {
            throw new Error(result.message || 'Failed to save receivable');
        }
    } catch (error) {
        console.error('Error saving receivable:', error);
        showAlert('error', error.message);
    }
}

function loadInitialData() {
    console.log('Loading initial data...');
    loadSuppliers();
    loadPurchases();
    loadPayables();
    loadReceivables();
}

// Load suppliers
async function loadSuppliers() {
    console.log('Loading suppliers...');
    try {
        const response = await fetch('api/suppliers.php');
        const data = await response.json();
        
        if (!data.success) {
            throw new Error(data.message || 'Failed to load suppliers');
        }

        const tableBody = document.getElementById('supplierTableBody');
        if (!tableBody) {
            console.error('Supplier table body not found');
            return;
        }

        if (!data.suppliers || !data.suppliers.length) {
            tableBody.innerHTML = '<tr><td colspan="6" class="no-data">No suppliers found</td></tr>';
            return;
        }

        tableBody.innerHTML = data.suppliers.map(supplier => `
            <tr>
                <td>${escapeHtml(supplier.id)}</td>
                <td>${escapeHtml(supplier.name)}</td>
                <td>${escapeHtml(supplier.phone)}</td>
                <td>${escapeHtml(supplier.email || '')}</td>
                <td>${escapeHtml([supplier.street, supplier.city, supplier.state].filter(Boolean).join(', '))}</td>
                <td>
                    <div class="action-buttons">
                        <button class="edit-btn" data-id="${supplier.id}" title="Edit supplier">
                            <i class="fas fa-pencil-alt"></i>
                        </button>
                        <button class="delete-btn" data-id="${supplier.id}" title="Delete supplier">
                            <i class="fas fa-trash-alt"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');

        // Add event listeners for edit and delete buttons
        tableBody.querySelectorAll('.edit-btn').forEach(btn => {
            btn.addEventListener('click', () => editSupplier(btn.dataset.id));
        });

        tableBody.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', () => deleteSupplier(btn.dataset.id));
        });

    } catch (error) {
        console.error('Error loading suppliers:', error);
        showAlert('error', 'Failed to load suppliers');
    }
}

async function editSupplier(id) {
    try {
        const response = await fetch(`api/suppliers.php?id=${id}`);
        const data = await response.json();
        
        if (!data.success || !data.suppliers || !data.suppliers[0]) {
            throw new Error('Failed to load supplier details');
        }

        const supplier = data.suppliers[0];
        const form = document.getElementById('supplierForm');
        
        if (!form) {
            throw new Error('Supplier form not found');
        }

        // Fill form with supplier data
        form.elements.supplierId.value = supplier.id;
        form.elements.name.value = supplier.name;
        form.elements.phone.value = supplier.phone;
        form.elements.email.value = supplier.email || '';
        form.elements.address.value = supplier.street || '';
        form.elements.city.value = supplier.city || '';
        form.elements.state.value = supplier.state || '';

        // Open modal
        openModal(document.getElementById('supplierModal'));
        
    } catch (error) {
        console.error('Error loading supplier details:', error);
        showAlert('error', 'Failed to load supplier details');
    }
}

async function deleteSupplier(id) {
    if (!confirm('Are you sure you want to delete this supplier?')) {
        return;
    }

    try {
        const response = await fetch(`api/suppliers.php?id=${id}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (data.success) {
            loadSuppliers();
            showAlert('success', 'Supplier deleted successfully');
        } else {
            throw new Error(data.message || 'Failed to delete supplier');
        }
    } catch (error) {
        console.error('Error deleting supplier:', error);
        showAlert('error', error.message || 'Failed to delete supplier');
    }
}

// Load purchases
async function loadPurchases() {
    console.log('Loading purchases...');
    try {
        const response = await fetch('api/purchases.php');
        const data = await response.json();
        
        if (!data.success) {
            throw new Error(data.message || 'Failed to load purchases');
        }

        const tableBody = document.getElementById('purchaseTableBody');
        if (!tableBody) {
            console.error('Purchase table body not found');
            return;
        }

        if (!data.purchases || !data.purchases.length) {
            tableBody.innerHTML = '<tr><td colspan="7" class="no-data">No purchases found</td></tr>';
            return;
        }

        tableBody.innerHTML = data.purchases.map(purchase => `
            <tr>
                <td>${escapeHtml(formatDate(purchase.purchase_date))}</td>
                <td>${escapeHtml(purchase.supplier_name)}</td>
                <td>${escapeHtml(purchase.product_name)}</td>
                <td>${escapeHtml(purchase.quantity)}</td>
                <td>${escapeHtml(formatCurrency(purchase.price_per_unit))}</td>
                <td>${escapeHtml(formatCurrency(purchase.total_amount))}</td>
                <td>
                    <button class="edit-btn" data-id="${purchase.id}">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="delete-btn" data-id="${purchase.id}">
                        <i class="fas fa-trash"></i>
                    </button>
                </td>
            </tr>
        `).join('');

        // Add event listeners for edit and delete buttons
        tableBody.querySelectorAll('.edit-btn').forEach(btn => {
            btn.addEventListener('click', () => editPurchase(btn.dataset.id));
        });

        tableBody.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', () => deletePurchase(btn.dataset.id));
        });

    } catch (error) {
        console.error('Error loading purchases:', error);
        showAlert('error', 'Failed to load purchases');
    }
}

// Load payables
async function loadPayables() {
    console.log('Loading payables...');
    try {
        const response = await fetch('api/account_payable.php');
        const data = await response.json();
        
        if (!data.success) {
            throw new Error(data.message || 'Failed to load payables');
        }

        const tableBody = document.getElementById('payableTableBody');
        if (!tableBody) {
            console.error('Payable table body not found');
            return;
        }

        const payables = data.data || [];
        if (!payables.length) {
            tableBody.innerHTML = '<tr><td colspan="8" class="no-data">No payables found</td></tr>';
            return;
        }

        tableBody.innerHTML = payables.map(payable => `
            <tr>
                <td>${escapeHtml(payable.supplier_name)}</td>
                <td>${escapeHtml(payable.invoice_number)}</td>
                <td>${escapeHtml(payable.description || '-')}</td>
                <td>${escapeHtml(formatCurrency(payable.amount))}</td>
                <td>${escapeHtml(formatDate(payable.due_date))}</td>
                <td>${payable.payment_date ? escapeHtml(formatDate(payable.payment_date)) : '-'}</td>
                <td>
                    <span class="status-badge status-${payable.status.toLowerCase()}">
                        ${escapeHtml(payable.status)}
                    </span>
                </td>
                <td>
                    <button class="edit-btn" onclick="editPayable(${payable.id})">
                        <i class="fas fa-edit"></i>
                    </button>
                    ${payable.status !== 'PAID' ? `
                        <button class="pay-btn" onclick="markAsPaid(${payable.id})">
                            <i class="fas fa-money-bill"></i>
                        </button>
                    ` : ''}
                </td>
            </tr>
        `).join('');

    } catch (error) {
        console.error('Error loading payables:', error);
        showAlert('error', 'Failed to load payables');
    }
}

// Load receivables
async function loadReceivables() {
    console.log('Loading receivables...');
    try {
        const response = await fetch('api/account_receivable.php');
        const data = await response.json();
        
        if (!data.success) {
            throw new Error(data.message || 'Failed to load receivables');
        }

        const tableBody = document.getElementById('receivableTableBody');
        if (!tableBody) {
            console.error('Receivable table body not found');
            return;
        }

        const receivables = data.data || [];
        if (!receivables.length) {
            tableBody.innerHTML = '<tr><td colspan="8" class="no-data">No receivables found</td></tr>';
            return;
        }

        tableBody.innerHTML = receivables.map(receivable => `
            <tr>
                <td>${escapeHtml(receivable.supplier_name)}</td>
                <td>${escapeHtml(receivable.invoice_number)}</td>
                <td>${escapeHtml(receivable.description || '-')}</td>
                <td>${escapeHtml(formatCurrency(receivable.amount))}</td>
                <td>${escapeHtml(formatDate(receivable.due_date))}</td>
                <td>${receivable.payment_date ? escapeHtml(formatDate(receivable.payment_date)) : '-'}</td>
                <td>
                    <span class="status-badge status-${receivable.status.toLowerCase()}">
                        ${escapeHtml(receivable.status)}
                    </span>
                </td>
                <td>
                    <button class="edit-btn" onclick="editReceivable(${receivable.id})">
                        <i class="fas fa-edit"></i>
                    </button>
                    ${receivable.status !== 'RECEIVED' ? `
                        <button class="receive-btn" onclick="markAsReceived(${receivable.id})">
                            <i class="fas fa-check"></i>
                        </button>
                    ` : ''}
                </td>
            </tr>
        `).join('');

    } catch (error) {
        console.error('Error loading receivables:', error);
        showAlert('error', 'Failed to load receivables');
    }
}

// Load suppliers for select dropdown
async function loadSuppliersForSelect(selectElement) {
    try {
        const response = await fetch('api/suppliers.php');
        const data = await response.json();
        
        if (!selectElement) return;

        if (data.success && Array.isArray(data.suppliers)) {
            selectElement.innerHTML = `
                <option value="">Select Supplier</option>
                ${data.suppliers.map(supplier => `
                    <option value="${supplier.id}">${escapeHtml(supplier.name)}</option>
                `).join('')}
            `;
        }
    } catch (error) {
        console.error('Error loading suppliers for select:', error);
    }
}

// Helper functions
function escapeHtml(unsafe) {
    if (unsafe == null) return '';
    return unsafe
        .toString()
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function showAlert(type, message) {
    const alertContainer = document.getElementById('alertContainer') || createAlertsContainer();
    const alert = document.createElement('div');
    alert.className = `alert ${type}`;
    alert.textContent = message;
    alertContainer.appendChild(alert);
    
    setTimeout(() => {
        alert.remove();
        if (alertContainer.children.length === 0) {
            alertContainer.remove();
        }
    }, 3000);
}

function createAlertsContainer() {
    const container = document.createElement('div');
    container.id = 'alertContainer';
    container.style.position = 'fixed';
    container.style.top = '1rem';
    container.style.right = '1rem';
    container.style.zIndex = '9999';
    document.body.appendChild(container);
    return container;
}

// Close all modals function
function closeAllModals() {
    // Close supplier modal
    const supplierModal = document.getElementById('supplierModal');
    if (supplierModal) {
        supplierModal.style.display = 'none';
        const supplierForm = document.getElementById('supplierForm');
        if (supplierForm) supplierForm.reset();
    }

    // Close purchase modal
    const purchaseModal = document.getElementById('purchaseModal');
    if (purchaseModal) {
        purchaseModal.style.display = 'none';
        const purchaseForm = document.getElementById('purchaseForm');
        if (purchaseForm) purchaseForm.reset();
    }
}

function formatDate(dateString) {
    if (!dateString) return '';
    return new Date(dateString).toLocaleDateString();
}

function formatCurrency(amount) {
    if (amount == null) return '';
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
    }).format(amount);
}

async function editPayable(id) {
    try {
        const response = await fetch(`api/account_payable.php?id=${id}`);
        const data = await response.json();
        
        if (!data.success) {
            throw new Error(data.message || 'Failed to load payable details');
        }

        const payable = data.data;
        const form = document.getElementById('payableForm');
        const modal = document.getElementById('payableModal');

        if (!form || !modal) {
            throw new Error('Form or modal elements not found');
        }

        // Load suppliers first
        await loadSuppliersForSelect(form.querySelector('select[name="supplier_id"]'));

        // Fill form fields
        form.elements['id'].value = payable.id;
        form.elements['supplier_id'].value = payable.supplier_id;
        form.elements['invoice_number'].value = payable.invoice_number;
        form.elements['amount'].value = payable.amount;
        form.elements['due_date'].value = payable.due_date;
        form.elements['payment_date'].value = payable.payment_date || '';
        form.elements['description'].value = payable.description || '';
        form.elements['status'].value = payable.status.toLowerCase();

        // Update modal title
        document.getElementById('payableModalTitle').textContent = 'Edit Payable';
        document.querySelector('#payableModal .save-btn').textContent = 'Update Payable';

        openModal(modal);
    } catch (error) {
        console.error('Error loading payable details:', error);
        showAlert('error', error.message);
    }
}

async function editReceivable(id) {
    try {
        const response = await fetch(`api/account_receivable.php?id=${id}`);
        const data = await response.json();
        
        if (!data.success) {
            throw new Error(data.message || 'Failed to load receivable details');
        }

        const receivable = data.data;
        const form = document.getElementById('receivableForm');
        const modal = document.getElementById('receivableModal');

        if (!form || !modal) {
            throw new Error('Form or modal elements not found');
        }

        // Load suppliers first
        await loadSuppliersForSelect(form.querySelector('select[name="supplier_id"]'));

        // Fill form fields
        form.elements['id'].value = receivable.id;
        form.elements['supplier_id'].value = receivable.supplier_id;
        form.elements['invoice_number'].value = receivable.invoice_number;
        form.elements['amount'].value = receivable.amount;
        form.elements['due_date'].value = receivable.due_date;
        form.elements['payment_date'].value = receivable.payment_date || '';
        form.elements['description'].value = receivable.description || '';
        form.elements['status'].value = receivable.status.toLowerCase();

        // Update modal title
        document.getElementById('receivableModalTitle').textContent = 'Edit Receivable';
        document.querySelector('#receivableModal .save-btn').textContent = 'Update Receivable';

        openModal(modal);
    } catch (error) {
        console.error('Error loading receivable details:', error);
        showAlert('error', error.message);
    }
}

async function markAsPaid(id) {
    try {
        const response = await fetch(`api/account_payable.php?id=${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                status: 'paid',
                payment_date: new Date().toISOString().split('T')[0]
            })
        });

        const data = await response.json();
        
        if (data.success) {
            showAlert('success', 'Payment marked as paid');
            loadPayables();
        } else {
            throw new Error(data.message || 'Failed to update payment status');
        }
    } catch (error) {
        console.error('Error marking payment as paid:', error);
        showAlert('error', error.message);
    }
}

async function markAsReceived(id) {
    try {
        const response = await fetch(`api/account_receivable.php?id=${id}`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                status: 'received',
                payment_date: new Date().toISOString().split('T')[0]
            })
        });

        const data = await response.json();
        
        if (data.success) {
            showAlert('success', 'Payment marked as received');
            loadReceivables();
        } else {
            throw new Error(data.message || 'Failed to update payment status');
        }
    } catch (error) {
        console.error('Error marking payment as received:', error);
        showAlert('error', error.message);
    }
}

// Load suppliers and products for purchase form
async function loadPurchaseFormData() {
    try {
        // Load suppliers
        const suppliersResponse = await fetch('api/suppliers.php');
        const suppliersData = await suppliersResponse.json();
        
        const supplierSelect = document.getElementById('supplierSelect');
        if (supplierSelect && suppliersData.success && Array.isArray(suppliersData.suppliers)) {
            supplierSelect.innerHTML = `
                <option value="">Select Supplier</option>
                ${suppliersData.suppliers.map(supplier => `
                    <option value="${supplier.id}">${escapeHtml(supplier.name)}</option>
                `).join('')}
            `;
        } else {
            console.error('Failed to load suppliers:', suppliersData);
        }

        // Load products
        const productsResponse = await fetch('api/inventory.php?action=list');
        const productsData = await productsResponse.json();
        
        const productSelect = document.getElementById('productSelect');
        if (productSelect && productsData.status === 'success' && Array.isArray(productsData.data)) {
            productSelect.innerHTML = `
                <option value="">Select Product</option>
                ${productsData.data.map(product => `
                    <option value="${product.id}" 
                            data-price="${product.purchase_price}"
                            data-stock="${product.quantity}">
                        ${escapeHtml(product.name)} - ${escapeHtml(product.brand)} 
                        (Stock: ${product.quantity})
                    </option>
                `).join('')}
            `;

            // Add event listener for product selection
            productSelect.addEventListener('change', function() {
                const selectedOption = this.options[this.selectedIndex];
                if (selectedOption.value) {
                    const price = selectedOption.dataset.price;
                    document.getElementById('rate').value = price || '';
                }
            });
        } else {
            console.error('Failed to load products:', productsData);
        }

    } catch (error) {
        console.error('Error loading form data:', error);
        showAlert('error', 'Failed to load suppliers and products');
    }
}