// Inventory Management
document.addEventListener('DOMContentLoaded', function() {
    // Load inventory on page load
    loadInventory();

    // Load inventory when tab is clicked
    document.querySelector('button[data-tab="inventory"]').addEventListener('click', loadInventory);
    
    // Add Product button click handler
    const addProductBtn = document.getElementById('showAddProductForm');
    if (addProductBtn) {
        addProductBtn.addEventListener('click', function(e) {
            e.preventDefault();
            const formContainer = document.getElementById('productFormContainer');
            formContainer.style.display = 'block';
            
            // Add overlay
            const overlay = document.createElement('div');
            overlay.className = 'form-overlay';
            document.body.appendChild(overlay);
            
            // Reset form
            const form = document.getElementById('addProductForm');
            form.reset();
            document.getElementById('productId').value = '';
            document.getElementById('submitButton').textContent = 'Add Product';
            document.getElementById('cancelEdit').style.display = 'none';
        });
    }
    
    // Close form when clicking overlay
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('form-overlay')) {
            closeProductForm();
        }
    });
    
    // Close button click handler
    const closeBtn = document.querySelector('.close-btn');
    if (closeBtn) {
        closeBtn.addEventListener('click', function(e) {
            e.preventDefault();
            closeProductForm();
        });
    }
    
    // Form submission
    const productForm = document.getElementById('addProductForm');
    if (productForm) {
        productForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData();
            const productId = document.getElementById('productId').value;
            
            formData.append('action', productId ? 'update' : 'add');
            formData.append('item_code', document.getElementById('itemCode').value);
            formData.append('name', document.getElementById('productName').value);
            formData.append('brand', document.getElementById('productBrand').value);
            formData.append('description', document.getElementById('productDescription').value || '');
            formData.append('purchase_price', document.getElementById('purchasePrice').value);
            formData.append('sales_price', document.getElementById('salesPrice').value);
            formData.append('quantity', document.getElementById('productQuantity').value);
            
            if (productId) {
                formData.append('id', productId);
            }
            
            fetch('api/inventory.php', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                if (data.status === 'success') {
                    closeProductForm();
                    loadInventory();
                    showAlert('Product saved successfully!', 'success');
                } else {
                    throw new Error(data.message || 'Error saving product');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showAlert(error.message, 'error');
            });
        });
    }

    // Cancel button
    const cancelBtn = document.getElementById('cancelEdit');
    if (cancelBtn) {
        cancelBtn.addEventListener('click', function(e) {
            e.preventDefault();
            closeProductForm();
        });
    }
});

// Load products
function loadInventory() {
    const tbody = document.querySelector('#inventoryTable tbody');
    if (!tbody) return;

    // Show loading state
    tbody.innerHTML = '<tr><td colspan="8" class="loading">Loading inventory...</td></tr>';

    fetch('api/inventory.php?action=list')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            tbody.innerHTML = '';
            
            if (data.data && data.data.length > 0) {
                data.data.forEach(product => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${escapeHtml(product.item_code)}</td>
                        <td>${escapeHtml(product.name)}</td>
                        <td>${escapeHtml(product.brand)}</td>
                        <td>${escapeHtml(product.description || '-')}</td>
                        <td>₹${parseFloat(product.purchase_price).toFixed(2)}</td>
                        <td>₹${parseFloat(product.sales_price).toFixed(2)}</td>
                        <td>${product.quantity}</td>
                        <td class="action-buttons">
                            <button onclick="editProduct(${product.id})" class="edit-btn" title="Edit product">✏️</button>
                            <button onclick="deleteProduct(${product.id})" class="delete-btn" title="Delete product">🗑️</button>
                        </td>
                    `;
                    tbody.appendChild(row);
                });
            } else {
                tbody.innerHTML = '<tr><td colspan="8" class="no-data">No products found</td></tr>';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            tbody.innerHTML = `<tr><td colspan="8" class="error">Error loading inventory: ${error.message}</td></tr>`;
        });
}

// Delete product
function deleteProduct(id) {
    if (confirm('Are you sure you want to delete this product? This action cannot be undone.')) {
        const formData = new FormData();
        formData.append('action', 'delete');
        formData.append('id', id);
        
        fetch('api/inventory.php', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            if (data.status === 'success') {
                loadInventory();
                showAlert('Product deleted successfully!', 'success');
            } else {
                throw new Error(data.message || 'Error deleting product');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showAlert(error.message, 'error');
        });
    }
}

// Edit product
function editProduct(id) {
    fetch('api/inventory.php?action=list')
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            const product = data.data.find(p => p.id === id);
            if (product) {
                document.getElementById('productId').value = product.id;
                document.getElementById('itemCode').value = product.item_code;
                document.getElementById('productName').value = product.name;
                document.getElementById('productBrand').value = product.brand;
                document.getElementById('productDescription').value = product.description || '';
                document.getElementById('purchasePrice').value = product.purchase_price;
                document.getElementById('salesPrice').value = product.sales_price;
                document.getElementById('productQuantity').value = product.quantity;
                
                document.getElementById('submitButton').textContent = 'Update Product';
                document.getElementById('cancelEdit').style.display = 'inline-block';
                document.getElementById('productFormContainer').style.display = 'block';
                
                // Add overlay
                const overlay = document.createElement('div');
                overlay.className = 'form-overlay';
                document.body.appendChild(overlay);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showAlert(error.message, 'error');
        });
}

// Close product form
function closeProductForm() {
    const formContainer = document.getElementById('productFormContainer');
    if (formContainer) {
        formContainer.style.display = 'none';
    }
    
    // Remove overlay
    const overlay = document.querySelector('.form-overlay');
    if (overlay) {
        overlay.remove();
    }
    
    // Reset form
    const form = document.getElementById('addProductForm');
    if (form) {
        form.reset();
    }
}

// Show alert message
function showAlert(message, type = 'success') {
    const alertsContainer = document.getElementById('alerts-container') || createAlertsContainer();
    
    const alert = document.createElement('div');
    alert.className = `alert alert-${type}`;
    alert.textContent = message;
    
    alertsContainer.appendChild(alert);
    
    // Remove alert after 3 seconds
    setTimeout(() => {
        alert.remove();
        // Remove container if empty
        if (alertsContainer.children.length === 0) {
            alertsContainer.remove();
        }
    }, 3000);
}

// Create alerts container if it doesn't exist
function createAlertsContainer() {
    const container = document.createElement('div');
    container.id = 'alerts-container';
    document.body.appendChild(container);
    return container;
}

// Helper function to escape HTML and prevent XSS
function escapeHtml(unsafe) {
    if (typeof unsafe !== 'string') return '';
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
} 