document.addEventListener('DOMContentLoaded', function() {
    // Load initial data
    loadProducts();
    
    // Initialize form submission
    initializeProductForm();
    
    // Initialize search functionality
    initializeSearch();
    
    // Initialize modal functionality
    initializeModal();
});

// Load Products
function loadProducts() {
    fetch(`${window.BASE_URL}/api/products.php`)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(response => {
            if (response.success && response.products) {
                const tbody = document.querySelector('#productsTable tbody');
                tbody.innerHTML = '';
                
                response.products.forEach(product => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${escapeHtml(product.item_code)}</td>
                        <td>${escapeHtml(product.name)}</td>
                        <td>${escapeHtml(product.brand)}</td>
                        <td>${escapeHtml(product.description || '')}</td>
                        <td>₹${formatNumber(product.purchase_price)}</td>
                        <td>₹${formatNumber(product.sales_price)}</td>
                        <td>${product.quantity}</td>
                        <td>
                            <button onclick="editProduct(${product.id})" class="action-btn edit-btn" title="Edit">
                                <span class="icon">✏️</span>
                            </button>
                            <button onclick="deleteProduct(${product.id})" class="action-btn delete-btn" title="Delete">
                                <span class="icon">🗑️</span>
                            </button>
                        </td>
                    `;
                    tbody.appendChild(row);
                });
            } else {
                showNotification('Error loading products: ' + (response.message || 'Unknown error'), 'error');
            }
        })
        .catch(error => {
            console.error('Error loading products:', error);
            showNotification('Error loading products', 'error');
        });
}

// Form Management
function initializeProductForm() {
    const form = document.getElementById('addProductForm');

    // Add event listener for item code input to check duplicates
    const itemCodeInput = document.getElementById('itemCode');
    let checkDuplicateTimeout;
    
    itemCodeInput.addEventListener('input', function() {
        clearTimeout(checkDuplicateTimeout);
        checkDuplicateTimeout = setTimeout(async function() {
            const itemCode = itemCodeInput.value.trim();
            if (itemCode) {
                try {
                    const response = await fetch(`${window.BASE_URL}/api/products.php?check_item_code=${itemCode}`);
                    const data = await response.json();
                    if (!data.success) {
                        itemCodeInput.setCustomValidity('This item code already exists');
                        showNotification('This item code already exists', 'error');
                    } else {
                        itemCodeInput.setCustomValidity('');
                    }
                } catch (error) {
                    console.error('Error checking item code:', error);
                }
            }
        }, 500);
    });

    form.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Get form values
        const productId = document.getElementById('productId').value;
        const itemCode = document.getElementById('itemCode').value.trim();
        const name = document.getElementById('productName').value.trim();
        const brand = document.getElementById('productBrand').value.trim();
        const description = document.getElementById('productDescription').value.trim();
        const purchasePrice = document.getElementById('purchasePrice').value;
        const salesPrice = document.getElementById('salesPrice').value;
        const quantity = document.getElementById('productQuantity').value;

        // Check if the item code field has any validation errors
        if (itemCodeInput.validationMessage) {
            showNotification(itemCodeInput.validationMessage, 'error');
            return;
        }

        // Validate required fields
        if (!itemCode || !name || !brand || !purchasePrice || !salesPrice) {
            showNotification('Please fill in all required fields', 'error');
            return;
        }

        // Validate numeric fields
        if (isNaN(purchasePrice) || purchasePrice <= 0) {
            showNotification('Please enter a valid purchase price', 'error');
            return;
        }

        if (isNaN(salesPrice) || salesPrice <= 0) {
            showNotification('Please enter a valid sales price', 'error');
            return;
        }

        if (isNaN(quantity) || quantity < 0) {
            showNotification('Please enter a valid quantity', 'error');
            return;
        }

        const formData = {
            id: productId || null,
            item_code: itemCode,
            name: name,
            brand: brand,
            description: description,
            purchase_price: parseFloat(purchasePrice),
            sales_price: parseFloat(salesPrice),
            quantity: parseInt(quantity) || 0
        };

        const method = productId ? 'PUT' : 'POST';
        
        fetch(`${window.BASE_URL}/api/products.php${productId ? `?id=${productId}` : ''}`, {
            method: method,
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        })
        .then(response => 
            response.json().then(data => {
                if (!response.ok) {
                    throw new Error(data.message || `HTTP error! status: ${response.status}`);
                }
                return data;
            })
        )
        .then(response => {
            if (response.success) {
                showNotification(productId ? 'Product updated successfully' : 'Product added successfully');
                closeProductForm();
                loadProducts();
            } else {
                throw new Error(response.message || 'Unknown error');
            }
        })
        .catch(error => {
            console.error('Error saving product:', error);
            showNotification(error.message || 'Error saving product', 'error');
        });
    });
}

// Search Functionality
function initializeSearch() {
    document.getElementById('productSearch').addEventListener('input', function(e) {
        const searchTerm = e.target.value.toLowerCase();
        const rows = document.querySelectorAll('#productsTable tbody tr');
        
        rows.forEach(row => {
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(searchTerm) ? '' : 'none';
        });
    });
}

// Form Display Functions
function showAddProductForm() {
    const modal = document.getElementById('productFormModal');
    if (!modal) {
        console.error('Modal element not found');
        return;
    }

    modal.style.display = 'flex';
    document.body.classList.add('modal-open');

    // Reset form and hidden input
    const form = document.getElementById('addProductForm');
    if (form) {
        form.reset();
    }

    const productIdInput = document.getElementById('productId');
    if (productIdInput) {
        productIdInput.value = '';
    }

    // Update title and button text
    const modalTitle = document.getElementById('modalTitle');
    if (modalTitle) {
        modalTitle.textContent = 'Add New Product';
    }

    const submitButton = document.getElementById('submitButton');
    if (submitButton) {
        submitButton.textContent = 'Add Product';
    }
}

function closeProductForm() {
    const modal = document.getElementById('productFormModal');
    if (modal) {
        modal.style.display = 'none';
        document.body.classList.remove('modal-open');
    }
}

// Initialize modal functionality
function initializeModal() {
    try {
        const modal = document.getElementById('productFormModal');
        const addButton = document.getElementById('showAddProductForm');
        const closeButton = modal?.querySelector('.close');
        const cancelButton = modal?.querySelector('.cancel-btn');
        
        if (!modal || !addButton) {
            console.error('Required elements not found:', { modal, addButton });
            throw new Error('Required modal elements not found');
        }

        // Add Product button click handler
        addButton.addEventListener('click', showAddProductForm);

        // Close modal when clicking outside
        modal.addEventListener('click', function(e) {
            if (e.target === this) {
                closeProductForm();
            }
        });

        // Close button handler
        if (closeButton) {
            closeButton.addEventListener('click', closeProductForm);
        }

        // Cancel button handler
        if (cancelButton) {
            cancelButton.addEventListener('click', closeProductForm);
        }

        // Add keyboard event listener to close modal with Escape key
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && modal.style.display === 'flex') {
                closeProductForm();
            }
        });
    } catch (error) {
        console.error('Error initializing modal:', error);
        showNotification('Error initializing product form', 'error');
    }
}

// Edit Function
function editProduct(id) {
    fetch(`${window.BASE_URL}/api/products.php?id=${id}`)
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(response => {
            if (response.success && response.product) {
                const product = response.product;
                document.getElementById('productId').value = product.id;
                document.getElementById('itemCode').value = product.item_code;
                document.getElementById('productName').value = product.name;
                document.getElementById('productBrand').value = product.brand;
                document.getElementById('productDescription').value = product.description || '';
                document.getElementById('purchasePrice').value = product.purchase_price;
                document.getElementById('salesPrice').value = product.sales_price;
                document.getElementById('productQuantity').value = product.quantity;
                
                document.getElementById('modalTitle').textContent = 'Edit Product';
                document.getElementById('submitButton').textContent = 'Update Product';
                
                const modal = document.getElementById('productFormModal');
                modal.style.display = 'flex';
                document.body.classList.add('modal-open');
            } else {
                showNotification('Error loading product: ' + (response.message || 'Unknown error'), 'error');
            }
        })
        .catch(error => {
            console.error('Error loading product:', error);
            showNotification('Error loading product', 'error');
        });
}

// Delete Function
function deleteProduct(id) {
    if (confirm('Are you sure you want to delete this product?')) {
        fetch(`${window.BASE_URL}/api/products.php?id=${id}`, { 
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(response => {
            return response.json().then(data => {
                if (!response.ok) {
                    throw new Error(data.message || `HTTP error! status: ${response.status}`);
                }
                return data;
            });
        })
        .then(response => {
            if (response.success) {
                showNotification('Product deleted successfully');
                loadProducts();
            } else {
                showNotification('Error: ' + (response.message || 'Unknown error'), 'error');
            }
        })
        .catch(error => {
            console.error('Error deleting product:', error);
            showNotification(error.message || 'Error deleting product', 'error');
        });
    }
}

// Helper Functions
function formatNumber(number) {
    return parseFloat(number).toLocaleString('en-IN', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

function escapeHtml(unsafe) {
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.remove();
    }, 3000);
} 