function updateTime() {
    const now = new Date();
    const options = { 
        weekday: 'long',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true
    };
    
    const dateOptions = {
        month: 'short',
        day: 'numeric',
        year: 'numeric'
    };
    
    const timeString = now.toLocaleTimeString('en-US', options);
    const dateString = now.toLocaleDateString('en-US', dateOptions);
    
    document.getElementById('currentTime').innerHTML = `
        ${dateString}<br>
        ${timeString}
    `;
}

// Update time immediately and then every second
updateTime();
setInterval(updateTime, 1000); 