<?php
header('Content-Type: text/plain');

$url = 'http://localhost/Billing/api/inventory.php?action=list';
echo "Testing API endpoint: $url\n\n";

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo "HTTP Response Code: $httpCode\n\n";
echo "Response:\n$response\n"; 