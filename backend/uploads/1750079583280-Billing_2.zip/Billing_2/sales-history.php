<?php
$pageTitle = "Sales History";
$pageScripts = [
    "../js/sales-history.js"
];
include 'includes/header.php';
include 'includes/sidebar.php';
?>

<main class="main-content">
    <div class="sales-history-section">
        <h2>Sales History</h2>
        
        <!-- Filters Section -->
        <div class="history-filters">
            <div class="filter-group">
                <label>Filter Type</label>
                <select id="filterType" class="filter-select">
                    <option value="all">All Time</option>
                    <option value="date">Date Range</option>
                    <option value="month">Month</option>
                    <option value="product">Product</option>    
                </select>
            </div>

            <!-- Date Range Filter -->
            <div id="dateFilterSection" class="filter-section" style="display: none;">
                <div class="date-inputs">
                    <div class="date-field">
                        <label>Start Date</label>
                        <input type="date" id="startDate">
                    </div>
                    <div class="date-field">
                        <label>End Date</label>
                        <input type="date" id="endDate">
                    </div>
                </div>
            </div>

            <!-- Product Filter -->
            <div id="productFilterSection" class="filter-section" style="display: none;">
                <div class="product-filter">
                    <div class="form-group">
                        <label for="productFilter">Select Product</label>
                        <select id="productFilter" class="filter-select">
                            <option value="">All Products</option>
                        </select>
                    </div>
                    <div class="product-info" style="display: none;">
                        <div class="info-card">
                            <h4>Product Details</h4>
                            <div class="info-row">
                                <span class="label">Item Code:</span>
                                <span id="selectedItemCode">-</span>
                            </div>
                            <div class="info-row">
                                <span class="label">Brand:</span>
                                <span id="selectedBrand">-</span>
                            </div>
                            <div class="info-row">
                                <span class="label">Current Stock:</span>
                                <span id="selectedStock">-</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Month Filter -->
            <div id="monthFilterSection" class="filter-section" style="display: none;">
                <div class="month-filter">
                    <select id="historyMonth" class="filter-select">
                        <option value="01">January</option>
                        <option value="02">February</option>
                        <option value="03">March</option>
                        <option value="04">April</option>
                        <option value="05">May</option>
                        <option value="06">June</option>
                        <option value="07">July</option>
                        <option value="08">August</option>
                        <option value="09">September</option>
                        <option value="10">October</option>
                        <option value="11">November</option>
                        <option value="12">December</option>
                    </select>
                    <select id="historyYear" class="filter-select"></select>
                </div>
            </div>

            <!-- Filter Actions -->
            <div class="filter-actions">
                <button id="applyFilter" class="apply-filter-btn">Apply Filter</button>
                <button id="resetFilter" class="reset-filter-btn">Reset</button>
                <div class="download-controls">
                    <button onclick="downloadHistory('pdf')" class="download-btn">
                        <span class="download-icon">📄</span> PDF
                    </button>
                </div>
            </div>
        </div>

        <!-- Summary Cards -->
        <div class="history-summary">
            <div class="summary-card">
                <h4>Total Sales</h4>
                <div id="totalSales">₹0.00</div>
            </div>
            <div class="summary-card">
                <h4>Total Transactions</h4>
                <div id="totalTransactions">0</div>
            </div>
            <div class="summary-card">
                <h4>Average Bill</h4>
                <div id="averageBill">₹0.00</div>
            </div>
            <div class="summary-card">
                <h4>Top Product</h4>
                <div id="topProduct">-</div>
            </div>
        </div>

        <!-- Sales History Table -->
        <div class="history-table-container">
            <table id="historyTable">
                <thead>
                    <tr>
                        <th>Date & Time</th>
                        <th>Bill Number</th>
                        <th>Product</th>
                        <th>Brand</th>
                        <th>Quantity</th>
                        <th>Unit Price</th>
                        <th>Total Amount</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody></tbody>
            </table>
        </div>

        <!-- Bill Details Modal -->
        <div id="billDetailsModal" class="modal" style="display: none;">
            <div class="modal-content">
                <div class="modal-header">
                    <h3>Bill Details</h3>
                    <span class="close" onclick="closeBillDetails()">&times;</span>
                </div>
                <div class="modal-body">
                    <div class="bill-info">
                        <div class="info-row">
                            <span class="label">Bill Number:</span>
                            <span id="modalBillNumber">-</span>
                        </div>
                        <div class="info-row">
                            <span class="label">Date & Time:</span>
                            <span id="modalBillDate">-</span>
                        </div>
                    </div>
                    <table class="bill-items">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Brand</th>
                                <th>Quantity</th>
                                <th>Unit Price</th>
                                <th>Total</th>
                            </tr>
                        </thead>
                        <tbody id="modalBillItems"></tbody>
                        <tfoot>
                            <tr>
                                <td colspan="4" class="total-label">Total Amount:</td>
                                <td id="modalTotalAmount">₹0.00</td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <div class="modal-footer">
                    <button onclick="printBill()" class="action-btn print-btn">
                        <span class="icon">🖨️</span> Print
                    </button>
                    <button onclick="downloadBill()" class="action-btn download-btn">
                        <span class="icon">📥</span> Download
                    </button>
                </div>
            </div>
        </div>
    </div>
</main>

<?php include 'includes/footer.php'; ?> 