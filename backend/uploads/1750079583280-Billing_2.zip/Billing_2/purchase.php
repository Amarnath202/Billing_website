<?php include 'header.php'; ?>

<div class="container">
    <h1>Purchase Management</h1>
    
    <div class="search-container">
        <input type="text" id="searchInput" placeholder="Search by supplier name..." onkeyup="searchFunction()">
    </div>

    <button class="add-purchase-btn" onclick="window.location.href='add_purchase.php'">
        <i class="fas fa-plus"></i>
        Add New Purchase
    </button>

    <table class="purchase-table" id="purchaseTable">
        <thead>
            <tr>
                <th>DATE</th>
                <th>SUPPLIER</th>
                <th>PRODUCT</th>
                <th>QUANTITY</th>
                <th>RATE/UNIT</th>
                <th>TOTAL</th>
                <th>ACTIONS</th>
            </tr>
        </thead>
        <tbody>
            <?php
            include 'config.php';
            $sql = "SELECT * FROM purchase ORDER BY date DESC";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["date"] . "</td>";
                    echo "<td>" . $row["supplier"] . "</td>";
                    echo "<td>" . $row["product"] . "</td>";
                    echo "<td>" . $row["quantity"] . "</td>";
                    echo "<td>$" . number_format($row["rate"], 2) . "</td>";
                    echo "<td>$" . number_format($row["total"], 2) . "</td>";
                    echo "<td>
                            <div class='purchase-actions'>
                                <button class='purchase-edit-btn' onclick='window.location.href=\"edit_purchase.php?id=" . $row["id"] . "\"'>
                                    <i class='fas fa-pencil-alt'></i>
                                </button>
                                <button class='purchase-delete-btn' onclick='deletePurchase(" . $row["id"] . ")'>
                                    <i class='fas fa-trash-alt'></i>
                                </button>
                            </div>
                          </td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='7' style='text-align: center;'>No purchases found</td></tr>";
            }
            $conn->close();
            ?>
        </tbody>
    </table>
</div>

<script>
function searchFunction() {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById("searchInput");
    filter = input.value.toUpperCase();
    table = document.getElementById("purchaseTable");
    tr = table.getElementsByTagName("tr");

    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName("td")[1]; // Search by supplier name (index 1)
        if (td) {
            txtValue = td.textContent || td.innerText;
            if (txtValue.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
            } else {
                tr[i].style.display = "none";
            }
        }
    }
}

function deletePurchase(id) {
    if (confirm("Are you sure you want to delete this purchase?")) {
        window.location.href = "delete_purchase.php?id=" + id;
    }
}
</script>

<?php include 'footer.php'; ?> 