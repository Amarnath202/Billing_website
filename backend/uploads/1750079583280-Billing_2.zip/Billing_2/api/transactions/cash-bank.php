<?php
header('Content-Type: application/json');
require_once '../../config/db.php';

try {
    $conn = getDBConnection();
    
    switch ($_SERVER['REQUEST_METHOD']) {
        case 'GET':
            if (isset($_GET['id'])) {
                // Get single transaction
                $stmt = $conn->prepare("
                    SELECT pt.*, s.name as supplier_name, p.name as product_name,
                           (p.purchase_price * pt.quantity) as total_amount,
                           ((p.purchase_price * pt.quantity) - pt.amount_paid) as balance
                    FROM payment_transactions pt
                    JOIN supplier s ON pt.supplier_id = s.id
                    JOIN products p ON pt.product_id = p.id
                    WHERE pt.id = ? AND pt.type = 'cash_bank'
                ");
                $stmt->bind_param("i", $_GET['id']);
                $stmt->execute();
                $result = $stmt->get_result();
                $transaction = $result->fetch_assoc();
                
                if (!$transaction) {
                    throw new Exception('Transaction not found');
                }
                
                echo json_encode(['success' => true, 'transaction' => $transaction]);
            } else {
                // List all transactions
                $result = $conn->query("
                    SELECT pt.*, s.name as supplier_name, p.name as product_name,
                           (p.purchase_price * pt.quantity) as total_amount,
                           ((p.purchase_price * pt.quantity) - pt.amount_paid) as balance
                    FROM payment_transactions pt
                    JOIN supplier s ON pt.supplier_id = s.id
                    JOIN products p ON pt.product_id = p.id
                    WHERE pt.type = 'cash_bank'
                    ORDER BY pt.transaction_date DESC
                ");
                
                $transactions = [];
                while ($row = $result->fetch_assoc()) {
                    $transactions[] = $row;
                }
                
                echo json_encode(['success' => true, 'transactions' => $transactions]);
            }
            break;
            
        case 'POST':
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!$data) {
                throw new Exception('Invalid JSON data');
            }
            
            // Validate required fields
            $required_fields = ['supplierId', 'productId', 'quantity', 'amountPaid', 'date', 'bankAccount', 'referenceNumber'];
            foreach ($required_fields as $field) {
                if (!isset($data[$field])) {
                    throw new Exception("Missing required field: $field");
                }
            }
            
            // Get product price
            $stmt = $conn->prepare("SELECT purchase_price FROM products WHERE id = ?");
            $stmt->bind_param("i", $data['productId']);
            $stmt->execute();
            $result = $stmt->get_result();
            $product = $result->fetch_assoc();
            
            if (!$product) {
                throw new Exception('Product not found');
            }
            
            $total_amount = $product['purchase_price'] * $data['quantity'];
            $status = $data['amountPaid'] >= $total_amount ? 'paid' : 
                     ($data['amountPaid'] > 0 ? 'partial' : 'pending');
            
            $stmt = $conn->prepare("
                INSERT INTO payment_transactions (
                    type, supplier_id, product_id, quantity, amount_paid,
                    transaction_date, status, notes, bank_account, reference_number
                ) VALUES (
                    'cash_bank', ?, ?, ?, ?, ?, ?, ?, ?, ?
                )
            ");
            
            $stmt->bind_param(
                "iiidsssss",
                $data['supplierId'],
                $data['productId'],
                $data['quantity'],
                $data['amountPaid'],
                $data['date'],
                $status,
                $data['notes'] ?? null,
                $data['bankAccount'],
                $data['referenceNumber']
            );
            
            if (!$stmt->execute()) {
                throw new Exception('Failed to create transaction');
            }
            
            echo json_encode([
                'success' => true,
                'message' => 'Transaction created successfully',
                'id' => $conn->insert_id
            ]);
            break;
            
        case 'PUT':
            if (!isset($_GET['id'])) {
                throw new Exception('Transaction ID is required');
            }
            
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!$data) {
                throw new Exception('Invalid JSON data');
            }
            
            // Check if transaction exists
            $stmt = $conn->prepare("SELECT id FROM payment_transactions WHERE id = ? AND type = 'cash_bank'");
            $stmt->bind_param("i", $_GET['id']);
            $stmt->execute();
            if (!$stmt->get_result()->fetch_assoc()) {
                throw new Exception('Transaction not found');
            }
            
            // Get product price
            $stmt = $conn->prepare("SELECT purchase_price FROM products WHERE id = ?");
            $stmt->bind_param("i", $data['productId']);
            $stmt->execute();
            $result = $stmt->get_result();
            $product = $result->fetch_assoc();
            
            if (!$product) {
                throw new Exception('Product not found');
            }
            
            $total_amount = $product['purchase_price'] * $data['quantity'];
            $status = $data['amountPaid'] >= $total_amount ? 'paid' : 
                     ($data['amountPaid'] > 0 ? 'partial' : 'pending');
            
            $stmt = $conn->prepare("
                UPDATE payment_transactions SET
                    supplier_id = ?,
                    product_id = ?,
                    quantity = ?,
                    amount_paid = ?,
                    transaction_date = ?,
                    status = ?,
                    notes = ?,
                    bank_account = ?,
                    reference_number = ?
                WHERE id = ? AND type = 'cash_bank'
            ");
            
            $stmt->bind_param(
                "iiidsssssi",
                $data['supplierId'],
                $data['productId'],
                $data['quantity'],
                $data['amountPaid'],
                $data['date'],
                $status,
                $data['notes'] ?? null,
                $data['bankAccount'],
                $data['referenceNumber'],
                $_GET['id']
            );
            
            if (!$stmt->execute()) {
                throw new Exception('Failed to update transaction');
            }
            
            echo json_encode([
                'success' => true,
                'message' => 'Transaction updated successfully'
            ]);
            break;
            
        case 'DELETE':
            if (!isset($_GET['id'])) {
                throw new Exception('Transaction ID is required');
            }
            
            $stmt = $conn->prepare("DELETE FROM payment_transactions WHERE id = ? AND type = 'cash_bank'");
            $stmt->bind_param("i", $_GET['id']);
            
            if (!$stmt->execute()) {
                throw new Exception('Failed to delete transaction');
            }
            
            if ($stmt->affected_rows === 0) {
                throw new Exception('Transaction not found');
            }
            
            echo json_encode([
                'success' => true,
                'message' => 'Transaction deleted successfully'
            ]);
            break;
            
        default:
            throw new Exception('Method not allowed');
    }
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
} 