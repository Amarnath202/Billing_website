<?php
require_once '../config/db.php';
header('Content-Type: application/json');

try {
    $method = $_SERVER['REQUEST_METHOD'];

    switch ($method) {
        case 'GET':
            if (isset($_GET['id'])) {
                // Get single payable
                $query = "
                    SELECT 
                        ap.*,
                        s.name as supplier_name,
                        DATE_FORMAT(ap.due_date, '%Y-%m-%d') as due_date,
                        DATE_FORMAT(ap.payment_date, '%Y-%m-%d') as payment_date,
                        DATE_FORMAT(ap.created_at, '%Y-%m-%d %H:%i:%s') as created_at
                    FROM account_payable ap
                    JOIN supplier s ON ap.supplier_id = s.id
                    WHERE ap.id = :id
                ";
                
                $stmt = $pdo->prepare($query);
                $stmt->execute(['id' => $_GET['id']]);
                $payable = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$payable) {
                    throw new Exception('Payable not found');
                }
                
                // Format amount to 2 decimal places
                $payable['amount'] = number_format((float)$payable['amount'], 2, '.', '');
                
                echo json_encode([
                    'success' => true,
                    'data' => $payable
                ]);
                break;
            }
            
            // List payables
            $query = "
                SELECT 
                    ap.*,
                    s.name as supplier_name,
                    DATE_FORMAT(ap.due_date, '%Y-%m-%d') as due_date,
                    DATE_FORMAT(ap.payment_date, '%Y-%m-%d') as payment_date,
                    DATE_FORMAT(ap.created_at, '%Y-%m-%d %H:%i:%s') as created_at
                FROM account_payable ap
                JOIN supplier s ON ap.supplier_id = s.id
                ORDER BY ap.due_date ASC
            ";
            
            $stmt = $pdo->prepare($query);
            $stmt->execute();
            $payables = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Update status based on due date
            foreach ($payables as &$payable) {
                if ($payable['status'] === 'pending') {
                    $dueDate = new DateTime($payable['due_date']);
                    $today = new DateTime();
                    if ($dueDate < $today) {
                        // Update status to overdue in database
                        $updateQuery = "UPDATE account_payable SET status = 'overdue' WHERE id = ?";
                        $updateStmt = $pdo->prepare($updateQuery);
                        $updateStmt->execute([$payable['id']]);
                        $payable['status'] = 'overdue';
                    }
                }
                // Format amount to 2 decimal places
                $payable['amount'] = number_format((float)$payable['amount'], 2, '.', '');
            }

            echo json_encode([
                'success' => true,
                'data' => $payables
            ]);
            break;

        case 'POST':
            // Add new payable
            $data = json_decode(file_get_contents('php://input'), true);
            
            // Validate required fields
            $required = ['supplier_id', 'invoice_number', 'amount', 'due_date'];
            foreach ($required as $field) {
                if (!isset($data[$field]) || empty($data[$field])) {
                    throw new Exception("Missing required field: $field");
                }
            }

            // Validate and format amount
            if (!is_numeric($data['amount'])) {
                throw new Exception("Invalid amount value");
            }
            $data['amount'] = number_format((float)$data['amount'], 2, '.', '');

            // Validate dates
            if (!DateTime::createFromFormat('Y-m-d', $data['due_date'])) {
                throw new Exception("Invalid due date format");
            }
            if (isset($data['payment_date']) && $data['payment_date'] && !DateTime::createFromFormat('Y-m-d', $data['payment_date'])) {
                throw new Exception("Invalid payment date format");
            }

            $query = "
                INSERT INTO account_payable (
                    supplier_id, invoice_number, description, 
                    amount, due_date, payment_date, status
                ) VALUES (
                    :supplier_id, :invoice_number, :description,
                    :amount, :due_date, :payment_date, :status
                )
            ";

            $stmt = $pdo->prepare($query);
            $stmt->execute([
                'supplier_id' => $data['supplier_id'],
                'invoice_number' => $data['invoice_number'],
                'description' => $data['description'] ?? null,
                'amount' => $data['amount'],
                'due_date' => $data['due_date'],
                'payment_date' => $data['payment_date'] ?? null,
                'status' => $data['status'] ?? 'pending'
            ]);

            echo json_encode([
                'success' => true,
                'message' => 'Payable added successfully'
            ]);
            break;

        case 'PUT':
            // Update payable
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!isset($data['id'])) {
                throw new Exception('Missing payable ID');
            }

            // Validate and format amount if provided
            if (isset($data['amount'])) {
                if (!is_numeric($data['amount'])) {
                    throw new Exception("Invalid amount value");
                }
                $data['amount'] = number_format((float)$data['amount'], 2, '.', '');
            }

            // Validate dates if provided
            if (isset($data['due_date']) && !DateTime::createFromFormat('Y-m-d', $data['due_date'])) {
                throw new Exception("Invalid due date format");
            }
            if (isset($data['payment_date']) && $data['payment_date'] && !DateTime::createFromFormat('Y-m-d', $data['payment_date'])) {
                throw new Exception("Invalid payment date format");
            }

            $query = "
                UPDATE account_payable SET
                    supplier_id = :supplier_id,
                    invoice_number = :invoice_number,
                    description = :description,
                    amount = :amount,
                    due_date = :due_date,
                    payment_date = :payment_date,
                    status = :status
                WHERE id = :id
            ";

            $stmt = $pdo->prepare($query);
            $stmt->execute([
                'id' => $data['id'],
                'supplier_id' => $data['supplier_id'],
                'invoice_number' => $data['invoice_number'],
                'description' => $data['description'] ?? null,
                'amount' => $data['amount'],
                'due_date' => $data['due_date'],
                'payment_date' => $data['payment_date'] ?? null,
                'status' => $data['status']
            ]);

            echo json_encode([
                'success' => true,
                'message' => 'Payable updated successfully'
            ]);
            break;

        case 'DELETE':
            // Delete payable
            $id = $_GET['id'] ?? null;
            if (!$id) {
                throw new Exception('Missing payable ID');
            }

            $query = "DELETE FROM account_payable WHERE id = ?";
            $stmt = $pdo->prepare($query);
            $stmt->execute([$id]);

            echo json_encode([
                'success' => true,
                'message' => 'Payable deleted successfully'
            ]);
            break;

        default:
            throw new Exception('Method not allowed');
    }

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?> 