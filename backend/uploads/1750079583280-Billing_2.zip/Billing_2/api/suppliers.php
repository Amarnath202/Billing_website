<?php
header('Content-Type: application/json');
require_once '../config/db.php';

try {
    $method = $_SERVER['REQUEST_METHOD'];

    switch ($method) {
        case 'GET':
            // List all suppliers
            $query = "SELECT * FROM supplier ORDER BY name";
            $stmt = $pdo->prepare($query);
            $stmt->execute();
            $suppliers = $stmt->fetchAll(PDO::FETCH_ASSOC);

            echo json_encode([
                'success' => true,
                'suppliers' => $suppliers
            ]);
            break;

        case 'POST':
            // Add new supplier
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!$data) {
                throw new Exception('Invalid JSON data');
            }
            
            // Validate required fields
            $required = ['name', 'phone', 'street', 'city', 'state'];
            foreach ($required as $field) {
                if (empty($data[$field])) {
                    throw new Exception("Missing required field: $field");
                }
            }
            
            $query = "
                INSERT INTO supplier (
                    name, phone, email, street, city, state
                ) VALUES (
                    :name, :phone, :email, :street, :city, :state
                )
            ";
            
            $stmt = $pdo->prepare($query);
            $stmt->execute([
                'name' => $data['name'],
                'phone' => $data['phone'],
                'email' => $data['email'] ?? null,
                'street' => $data['street'],
                'city' => $data['city'],
                'state' => $data['state']
            ]);
            
            echo json_encode([
                'success' => true,
                'id' => $pdo->lastInsertId()
            ]);
            break;

        case 'PUT':
            // Update supplier
            if (!isset($_GET['id'])) {
                throw new Exception('Supplier ID is required');
            }
            
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!$data) {
                throw new Exception('Invalid JSON data');
            }
            
            $query = "
                UPDATE supplier SET
                    name = :name,
                    phone = :phone,
                    email = :email,
                    street = :street,
                    city = :city,
                    state = :state
                WHERE id = :id
            ";
            
            $stmt = $pdo->prepare($query);
            $stmt->execute([
                'id' => $_GET['id'],
                'name' => $data['name'],
                'phone' => $data['phone'],
                'email' => $data['email'] ?? null,
                'street' => $data['street'],
                'city' => $data['city'],
                'state' => $data['state']
            ]);
            
            if ($stmt->rowCount() > 0) {
                echo json_encode(['success' => true]);
            } else {
                throw new Exception('Supplier not found');
            }
            break;

        case 'DELETE':
            // Delete supplier
            if (!isset($_GET['id'])) {
                throw new Exception('Supplier ID is required');
            }
            
            $stmt = $pdo->prepare("DELETE FROM supplier WHERE id = ?");
            $stmt->execute([$_GET['id']]);
            
            if ($stmt->rowCount() > 0) {
                echo json_encode(['success' => true]);
            } else {
                throw new Exception('Supplier not found');
            }
            break;

        default:
            throw new Exception('Method not allowed');
    }
} catch (PDOException $e) {
    error_log('Database error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error occurred']);
} catch (Exception $e) {
    error_log('General error: ' . $e->getMessage());
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?> 