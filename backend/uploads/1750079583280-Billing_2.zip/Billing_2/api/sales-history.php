<?php
header('Content-Type: application/json');
require_once '../config/db.php';

try {
    $conn = getDBConnection();
    
    // Get filters from query parameters
    $filters = [];
    if (isset($_GET['startDate']) && isset($_GET['endDate'])) {
        $filters['date_range'] = "s.sale_date BETWEEN ? AND ?";
        $filters['params'][] = $_GET['startDate'];
        $filters['params'][] = $_GET['endDate'];
    } elseif (isset($_GET['month']) && isset($_GET['year'])) {
        $filters['date_range'] = "MONTH(s.sale_date) = ? AND YEAR(s.sale_date) = ?";
        $filters['params'][] = $_GET['month'];
        $filters['params'][] = $_GET['year'];
    }
    
    if (isset($_GET['productId'])) {
        $filters['product'] = "s.product_id = ?";
        $filters['params'][] = $_GET['productId'];
    }
    
    // Build WHERE clause
    $where_clause = "";
    if (!empty($filters)) {
        $conditions = [];
        if (isset($filters['date_range'])) {
            $conditions[] = $filters['date_range'];
        }
        if (isset($filters['product'])) {
            $conditions[] = $filters['product'];
        }
        $where_clause = "WHERE " . implode(" AND ", $conditions);
    }
    
    // Get sales data
    $query = "
        SELECT 
            s.id,
            s.sale_date as datetime,
            s.bill_number as billNumber,
            p.name as product,
            p.brand,
            s.quantity,
            s.unit_price as unitPrice,
            s.total_amount as totalAmount
        FROM sales s
        JOIN products p ON s.product_id = p.id
        $where_clause
        ORDER BY s.sale_date DESC
    ";
    
    $stmt = $conn->prepare($query);
    if (!empty($filters['params'])) {
        $types = str_repeat('s', count($filters['params']));
        $stmt->bind_param($types, ...$filters['params']);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    
    $sales = [];
    while ($row = $result->fetch_assoc()) {
        $sales[] = $row;
    }
    
    // Calculate summary
    $summary = [
        'totalSales' => 0,
        'totalTransactions' => count($sales),
        'averageBill' => 0,
        'topProduct' => ''
    ];
    
    $productTotals = [];
    foreach ($sales as $sale) {
        $summary['totalSales'] += $sale['totalAmount'];
        
        if (!isset($productTotals[$sale['product']])) {
            $productTotals[$sale['product']] = 0;
        }
        $productTotals[$sale['product']] += $sale['totalAmount'];
    }
    
    // Find top product
    arsort($productTotals);
    $summary['topProduct'] = key($productTotals);
    
    // Calculate average bill
    if ($summary['totalTransactions'] > 0) {
        $summary['averageBill'] = $summary['totalSales'] / $summary['totalTransactions'];
    }
    
    // Format currency values
    $summary['totalSales'] = number_format($summary['totalSales'], 2);
    $summary['averageBill'] = number_format($summary['averageBill'], 2);
    
    echo json_encode([
        'success' => true,
        'sales' => $sales,
        'summary' => $summary
    ]);
    
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
} 