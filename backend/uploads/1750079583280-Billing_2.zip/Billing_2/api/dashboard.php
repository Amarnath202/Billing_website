<?php
header('Content-Type: application/json');
require_once '../config/db.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

try {
    // Verify database connection
    if (!isset($pdo)) {
        throw new Exception('Database connection not established');
    }

    // Get today's sales statistics
    $todayQuery = $pdo->prepare("
        SELECT 
            COALESCE(SUM(total_amount), 0) as total_sales,
            COUNT(DISTINCT id) as total_transactions
        FROM sales 
        WHERE DATE(sale_date) = CURRENT_DATE()
    ");
    
    if (!$todayQuery->execute()) {
        throw new Exception('Failed to fetch today\'s sales data: ' . implode(', ', $todayQuery->errorInfo()));
    }
    $todayData = $todayQuery->fetch(PDO::FETCH_ASSOC);

    // Get this month's statistics
    $monthQuery = $pdo->prepare("
        SELECT 
            COALESCE(SUM(total_amount), 0) as total_sales,
            COUNT(DISTINCT id) as total_transactions,
            COALESCE(AVG(total_amount), 0) as avg_transaction
        FROM sales 
        WHERE MONTH(sale_date) = MONTH(CURRENT_DATE()) 
        AND YEAR(sale_date) = YEAR(CURRENT_DATE())
    ");
    
    if (!$monthQuery->execute()) {
        throw new Exception('Failed to fetch monthly sales data: ' . implode(', ', $monthQuery->errorInfo()));
    }
    $monthData = $monthQuery->fetch(PDO::FETCH_ASSOC);

    // Get inventory statistics
    $inventoryQuery = $pdo->prepare("
        SELECT 
            COUNT(id) as total_products,
            COALESCE(SUM(CASE WHEN quantity <= 0 THEN 1 ELSE 0 END), 0) as low_stock_items
        FROM products
    ");
    
    if (!$inventoryQuery->execute()) {
        throw new Exception('Failed to fetch inventory data: ' . implode(', ', $inventoryQuery->errorInfo()));
    }
    $inventoryData = $inventoryQuery->fetch(PDO::FETCH_ASSOC);

    // Get daily sales data (last 7 days)
    $dailyComparisonQuery = $pdo->prepare("
        SELECT 
            DATE_FORMAT(sale_date, '%Y-%m-%d') as sale_day,
            COALESCE(SUM(total_amount), 0) as total_revenue,
            COUNT(DISTINCT id) as total_transactions,
            COALESCE(SUM(quantity), 0) as total_quantity
        FROM sales 
        WHERE sale_date >= DATE_SUB(CURRENT_DATE(), INTERVAL 7 DAY)
        GROUP BY DATE(sale_date)
        ORDER BY sale_day ASC
    ");
    
    if (!$dailyComparisonQuery->execute()) {
        throw new Exception('Failed to fetch daily comparison data: ' . implode(', ', $dailyComparisonQuery->errorInfo()));
    }
    $monthlyComparison = $dailyComparisonQuery->fetchAll(PDO::FETCH_ASSOC);

    // Format the dates properly
    foreach ($monthlyComparison as &$day) {
        $day['total_revenue'] = number_format((float)$day['total_revenue'], 2, '.', '');
        // Ensure the date is in YYYY-MM-DD format
        $day['sale_day'] = date('Y-m-d', strtotime($day['sale_day']));
    }

    // Get top selling products
    $topProductsQuery = $pdo->prepare("
        SELECT 
            p.name,
            COALESCE(SUM(s.quantity), 0) as total_quantity,
            COALESCE(SUM(s.total_amount), 0) as total_revenue
        FROM products p
        LEFT JOIN sales s ON p.id = s.product_id
            AND MONTH(s.sale_date) = MONTH(CURRENT_DATE())
            AND YEAR(s.sale_date) = YEAR(CURRENT_DATE())
        GROUP BY p.id, p.name
        HAVING total_quantity > 0 OR total_revenue > 0
        ORDER BY total_revenue DESC
        LIMIT 5
    ");
    
    if (!$topProductsQuery->execute()) {
        throw new Exception('Failed to fetch top products data: ' . implode(', ', $topProductsQuery->errorInfo()));
    }
    $topProducts = $topProductsQuery->fetchAll(PDO::FETCH_ASSOC);

    // Get recent sales
    $recentSalesQuery = $pdo->prepare("
        SELECT 
            s.id,
            s.sale_date,
            s.bill_number,
            p.name as product_name,
            s.quantity,
            s.unit_price,
            s.total_amount
        FROM sales s
        JOIN products p ON s.product_id = p.id
        ORDER BY s.sale_date DESC, s.id DESC
        LIMIT 5
    ");
    
    if (!$recentSalesQuery->execute()) {
        throw new Exception('Failed to fetch recent sales data: ' . implode(', ', $recentSalesQuery->errorInfo()));
    }
    $recentSales = $recentSalesQuery->fetchAll(PDO::FETCH_ASSOC);

    // Format monetary values
    foreach ($recentSales as &$sale) {
        $sale['unit_price'] = number_format((float)$sale['unit_price'], 2, '.', '');
        $sale['total_amount'] = number_format((float)$sale['total_amount'], 2, '.', '');
        $sale['sale_date'] = date('Y-m-d H:i:s', strtotime($sale['sale_date']));
    }

    // Format all monetary values to 2 decimal places
    $todayData['total_sales'] = number_format((float)$todayData['total_sales'], 2, '.', '');
    $monthData['total_sales'] = number_format((float)$monthData['total_sales'], 2, '.', '');
    $monthData['avg_transaction'] = number_format((float)$monthData['avg_transaction'], 2, '.', '');

    foreach ($monthlyComparison as &$day) {
        $day['total_revenue'] = number_format((float)$day['total_revenue'], 2, '.', '');
    }

    foreach ($topProducts as &$product) {
        $product['total_revenue'] = number_format((float)$product['total_revenue'], 2, '.', '');
    }

    // Debug log
    error_log('Dashboard Data: ' . json_encode([
        'today' => $todayData,
        'month' => $monthData,
        'inventory' => $inventoryData,
        'monthly_comparison' => $monthlyComparison,
        'top_products' => $topProducts,
        'recent_sales' => $recentSales
    ], JSON_PRETTY_PRINT));

    // Prepare response
    echo json_encode([
        'status' => 'success',
        'data' => [
            'today' => [
                'sales' => (float)$todayData['total_sales'],
                'transactions' => (int)$todayData['total_transactions']
            ],
            'month' => [
                'sales' => (float)$monthData['total_sales'],
                'transactions' => (int)$monthData['total_transactions'],
                'avg_transaction' => (float)$monthData['avg_transaction']
            ],
            'inventory' => [
                'total_products' => (int)$inventoryData['total_products'],
                'low_stock_items' => (int)$inventoryData['low_stock_items']
            ],
            'monthly_comparison' => $monthlyComparison,
            'top_products' => $topProducts,
            'recent_sales' => $recentSales
        ]
    ]);

} catch (Exception $e) {
    error_log('Dashboard Error: ' . $e->getMessage());
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}
?> 