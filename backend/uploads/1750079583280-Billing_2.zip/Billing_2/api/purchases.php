<?php
require_once '../config/db.php';
header('Content-Type: application/json');

try {
    $method = $_SERVER['REQUEST_METHOD'];

    switch ($method) {
        case 'GET':
            // List all purchases with supplier and product names
            $query = "
                SELECT p.*, s.name as supplier_name, pr.name as product_name 
                FROM purchases p
                JOIN supplier s ON p.supplier_id = s.id
                JOIN products pr ON p.item_id = pr.id
                ORDER BY p.purchase_date DESC
            ";
            $stmt = $pdo->prepare($query);
            $stmt->execute();
            $purchases = $stmt->fetchAll(PDO::FETCH_ASSOC);

            echo json_encode([
                'success' => true,
                'purchases' => $purchases
            ]);
            break;

        case 'POST':
            // Add new purchase
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!$data) {
                throw new Exception('Invalid JSON data');
            }
            
            // Validate required fields
            $required = ['supplierId', 'productId', 'date', 'quantity', 'pricePerUnit'];
            foreach ($required as $field) {
                if (empty($data[$field])) {
                    throw new Exception("Missing required field: $field");
                }
            }
            
            $query = "
                INSERT INTO purchases (
                    purchase_date, supplier_id, item_id, quantity, 
                    price_per_unit, total_amount, notes
                ) VALUES (
                    :date, :supplier_id, :item_id, :quantity,
                    :price_per_unit, :total_amount, :notes
                )
            ";
            
            $total_amount = $data['quantity'] * $data['pricePerUnit'];
            
            $stmt = $pdo->prepare($query);
            $stmt->execute([
                'date' => $data['date'],
                'supplier_id' => $data['supplierId'],
                'item_id' => $data['productId'],
                'quantity' => $data['quantity'],
                'price_per_unit' => $data['pricePerUnit'],
                'total_amount' => $total_amount,
                'notes' => $data['notes'] ?? null
            ]);
            
            // Update product quantity
            $update_query = "
                UPDATE products 
                SET quantity = quantity + :quantity 
                WHERE id = :product_id
            ";
            $update_stmt = $pdo->prepare($update_query);
            $update_stmt->execute([
                'quantity' => $data['quantity'],
                'product_id' => $data['productId']
            ]);
            
            echo json_encode([
                'success' => true,
                'id' => $pdo->lastInsertId()
            ]);
            break;

        case 'PUT':
            // Update purchase
            if (!isset($_GET['id'])) {
                throw new Exception('Purchase ID is required');
            }
            
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!$data) {
                throw new Exception('Invalid JSON data');
            }
            
            // Get old purchase data
            $old_query = "SELECT * FROM purchases WHERE id = ?";
            $old_stmt = $pdo->prepare($old_query);
            $old_stmt->execute([$_GET['id']]);
            $old_purchase = $old_stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$old_purchase) {
                throw new Exception('Purchase not found');
            }
            
            // Update purchase
            $query = "
                UPDATE purchases SET
                    purchase_date = :date,
                    supplier_id = :supplier_id,
                    item_id = :item_id,
                    quantity = :quantity,
                    price_per_unit = :price_per_unit,
                    total_amount = :total_amount,
                    notes = :notes
                WHERE id = :id
            ";
            
            $total_amount = $data['quantity'] * $data['pricePerUnit'];
            
            $stmt = $pdo->prepare($query);
            $stmt->execute([
                'id' => $_GET['id'],
                'date' => $data['date'],
                'supplier_id' => $data['supplierId'],
                'item_id' => $data['productId'],
                'quantity' => $data['quantity'],
                'price_per_unit' => $data['pricePerUnit'],
                'total_amount' => $total_amount,
                'notes' => $data['notes'] ?? null
            ]);
            
            // Update product quantity
            $quantity_diff = $data['quantity'] - $old_purchase['quantity'];
            if ($quantity_diff != 0) {
                $update_query = "
                    UPDATE products 
                    SET quantity = quantity + :quantity_diff 
                    WHERE id = :product_id
                ";
                $update_stmt = $pdo->prepare($update_query);
                $update_stmt->execute([
                    'quantity_diff' => $quantity_diff,
                    'product_id' => $data['productId']
                ]);
            }
            
            echo json_encode(['success' => true]);
            break;

        case 'DELETE':
            // Delete purchase
            if (!isset($_GET['id'])) {
                throw new Exception('Purchase ID is required');
            }
            
            // Get purchase data
            $query = "SELECT * FROM purchases WHERE id = ?";
            $stmt = $pdo->prepare($query);
            $stmt->execute([$_GET['id']]);
            $purchase = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$purchase) {
                throw new Exception('Purchase not found');
            }
            
            // Delete purchase
            $delete_stmt = $pdo->prepare("DELETE FROM purchases WHERE id = ?");
            $delete_stmt->execute([$_GET['id']]);
            
            // Update product quantity
            $update_query = "
                UPDATE products 
                SET quantity = quantity - :quantity 
                WHERE id = :product_id
            ";
            $update_stmt = $pdo->prepare($update_query);
            $update_stmt->execute([
                'quantity' => $purchase['quantity'],
                'product_id' => $purchase['item_id']
            ]);
            
            echo json_encode(['success' => true]);
            break;

        default:
            throw new Exception('Method not allowed');
    }
} catch (PDOException $e) {
    error_log('Database error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error occurred']);
} catch (Exception $e) {
    error_log('General error: ' . $e->getMessage());
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
?> 