<?php
require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        // Validate format parameter
        $format = $_GET['format'] ?? 'csv';
        if ($format !== 'csv') {
            throw new Exception('Invalid format specified');
        }

        // Build the query based on filter type
        $query = "
            SELECT 
                s.id,
                s.sale_date,
                p.item_code,
                p.name as product_name,
                p.brand,
                s.quantity,
                s.unit_price,
                s.total_amount
            FROM sales s
            JOIN products p ON s.product_id = p.id
            WHERE 1=1
        ";
        $params = [];
        $filename = 'sales';

        // Handle different filter types
        if (isset($_GET['start_date']) && isset($_GET['end_date'])) {
            // Validate dates
            $start_date = DateTime::createFromFormat('Y-m-d', $_GET['start_date']);
            $end_date = DateTime::createFromFormat('Y-m-d', $_GET['end_date']);
            
            if (!$start_date || !$end_date) {
                throw new Exception('Invalid date format. Use YYYY-MM-DD');
            }
            
            if ($end_date < $start_date) {
                throw new Exception('End date cannot be earlier than start date');
            }

            $query .= " AND DATE(s.sale_date) BETWEEN ? AND ?";
            $params[] = $start_date->format('Y-m-d');
            $params[] = $end_date->format('Y-m-d');
            $filename = 'sales_' . $start_date->format('Y-m-d') . '_to_' . $end_date->format('Y-m-d');
        } elseif (isset($_GET['month']) && isset($_GET['year'])) {
            // Validate month and year
            $month = filter_var($_GET['month'], FILTER_VALIDATE_INT, [
                "options" => ["min_range" => 1, "max_range" => 12]
            ]);
            $year = filter_var($_GET['year'], FILTER_VALIDATE_INT, [
                "options" => ["min_range" => 2000, "max_range" => date('Y')]
            ]);
            
            if ($month === false || $year === false) {
                throw new Exception('Invalid month or year');
            }

            $query .= " AND MONTH(s.sale_date) = ? AND YEAR(s.sale_date) = ?";
            $params[] = $month;
            $params[] = $year;
            $monthName = date('F', mktime(0, 0, 0, $month, 1));
            $filename = 'sales_' . $monthName . '_' . $year;
        } else {
            $filename = 'sales_all_time';
        }

        $query .= " ORDER BY s.sale_date DESC";
        
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        $sales = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Sanitize filename
        $filename = preg_replace('/[^a-zA-Z0-9_-]/', '', $filename);
        
        // Set headers for CSV download
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '.csv"');
        header('Pragma: no-cache');
        header('Expires: 0');
        
        // Add BOM for Excel UTF-8 compatibility
        echo "\xEF\xBB\xBF";
        
        $output = fopen('php://output', 'w');
        
        // Add headers
        fputcsv($output, ['Bill Number', 'Date & Time', 'Item Code', 'Product', 'Brand', 'Quantity', 'Unit Price', 'Total Amount']);
        
        // Add data
        foreach ($sales as $index => $sale) {
            $billNumber = 'BILL' . date('Ymd', strtotime($sale['sale_date'])) . '-' . str_pad($index + 1, 4, '0', STR_PAD_LEFT);
            fputcsv($output, [
                $billNumber,
                $sale['sale_date'],
                $sale['item_code'],
                $sale['product_name'],
                $sale['brand'],
                $sale['quantity'],
                number_format($sale['unit_price'], 2),
                number_format($sale['total_amount'], 2)
            ]);
        }
        
        fclose($output);
        exit;
        
    } catch (Exception $e) {
        header('Content-Type: application/json');
        echo json_encode([
            'status' => 'error', 
            'message' => $e->getMessage(),
            'code' => $e->getCode()
        ]);
        exit;
    }
}
?> 