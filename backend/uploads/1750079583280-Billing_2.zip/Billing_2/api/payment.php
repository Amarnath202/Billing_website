<?php
require_once '../config/database.php';

header('Content-Type: application/json');

// Create tables if they don't exist
try {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS supplier (
            id INT PRIMARY KEY AUTO_INCREMENT,
            name VARCHAR(255) NOT NULL,
            phone VARCHAR(20) NOT NULL,
            email VARCHAR(255),
            street VARCHAR(255) NOT NULL,
            city VARCHAR(100) NOT NULL,
            state VARCHAR(100) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        );
        
        CREATE TABLE IF NOT EXISTS products (
            id INT PRIMARY KEY AUTO_INCREMENT,
            item_code VARCHAR(50) UNIQUE NOT NULL,
            name VARCHAR(255) NOT NULL,
            brand VARCHAR(100) NOT NULL,
            description TEXT,
            purchase_price DECIMAL(10,2) NOT NULL,
            sales_price DECIMAL(10,2) NOT NULL,
            quantity INT NOT NULL DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        );
        
        CREATE TABLE IF NOT EXISTS payment_transactions (
            id INT PRIMARY KEY AUTO_INCREMENT,
            type ENUM('cash_hand', 'cash_bank') NOT NULL,
            supplier_id INT NOT NULL,
            product_id INT NOT NULL,
            quantity INT NOT NULL,
            amount_paid DECIMAL(10,2) NOT NULL,
            transaction_date DATE NOT NULL,
            status ENUM('pending', 'partial', 'paid') NOT NULL DEFAULT 'pending',
            notes TEXT,
            bank_account VARCHAR(50),
            reference_number VARCHAR(50),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (supplier_id) REFERENCES supplier(id) ON DELETE RESTRICT,
            FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT
        );
        
        CREATE TABLE IF NOT EXISTS account_payable (
            id INT PRIMARY KEY AUTO_INCREMENT,
            supplier_id INT NOT NULL,
            invoice_number VARCHAR(50) NOT NULL,
            description TEXT,
            amount DECIMAL(10,2) NOT NULL,
            due_date DATE NOT NULL,
            payment_date DATE,
            status ENUM('pending', 'paid', 'overdue') DEFAULT 'pending',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (supplier_id) REFERENCES supplier(id) ON DELETE RESTRICT
        );
    ");
} catch (PDOException $e) {
    error_log('Table creation error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database setup error: ' . $e->getMessage()]);
    exit;
}

// Validate payment data
function validatePaymentData($data) {
    $errors = [];
    
    if (empty($data['supplier_id'])) {
        $errors[] = 'Supplier is required';
    }
    if (empty($data['product_id'])) {
        $errors[] = 'Product is required';
    }
    if (empty($data['quantity']) || $data['quantity'] < 1) {
        $errors[] = 'Valid quantity is required';
    }
    if (empty($data['amount_paid']) || $data['amount_paid'] < 0) {
        $errors[] = 'Valid amount is required';
    }
    if (empty($data['transaction_date'])) {
        $errors[] = 'Transaction date is required';
    }
    if (empty($data['status'])) {
        $errors[] = 'Status is required';
    }
    
    // Additional validation for bank transactions
    if ($data['type'] === 'cash_bank') {
        if (empty($data['bank_account'])) {
            $errors[] = 'Bank account is required for bank transactions';
        }
        if (empty($data['reference_number'])) {
            $errors[] = 'Reference number is required for bank transactions';
        }
    }
    
    return $errors;
}

// Handle different HTTP methods
$method = $_SERVER['REQUEST_METHOD'];

try {
    switch ($method) {
        case 'GET':
            // Get transactions by type or specific transaction
            if (isset($_GET['id'])) {
                // Get specific transaction
                $query = "
                    SELECT 
                        pt.*,
                        s.name as supplier_name,
                        p.name as product_name,
                        p.item_code,
                        p.brand,
                        p.purchase_price,
                        (pt.amount_paid - (p.purchase_price * pt.quantity)) as balance
                    FROM payment_transactions pt
                    LEFT JOIN supplier s ON pt.supplier_id = s.id
                    LEFT JOIN products p ON pt.product_id = p.id
                    WHERE pt.id = :id
                ";
                
                $stmt = $pdo->prepare($query);
                $stmt->execute(['id' => $_GET['id']]);
                $transaction = $stmt->fetch();
                
                if ($transaction) {
                    echo json_encode([
                        'status' => 'success',
                        'data' => $transaction
                    ]);
                } else {
                    http_response_code(404);
                    echo json_encode([
                        'status' => 'error',
                        'message' => 'Transaction not found'
                    ]);
                }
            } else if (isset($_GET['type'])) {
                // Get transactions by type
                $query = "
                    SELECT 
                        pt.*,
                        s.name as supplier_name,
                        p.name as product_name,
                        p.item_code,
                        p.brand,
                        p.purchase_price,
                        (pt.amount_paid - (p.purchase_price * pt.quantity)) as balance
                    FROM payment_transactions pt
                    LEFT JOIN supplier s ON pt.supplier_id = s.id
                    LEFT JOIN products p ON pt.product_id = p.id
                    WHERE pt.type = :type
                    ORDER BY pt.transaction_date DESC
                ";
                
                $stmt = $pdo->prepare($query);
                $stmt->execute(['type' => $_GET['type']]);
                $transactions = $stmt->fetchAll();
                
                echo json_encode([
                    'status' => 'success',
                    'data' => $transactions
                ]);
            } else {
                throw new Exception('Missing required parameter: type or id');
            }
            break;

        case 'POST':
            // Add new transaction
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!$data) {
                throw new Exception('Invalid JSON data');
            }
            
            // Validate required fields
            $required = [
                'type', 'supplier_id', 'product_id', 'quantity',
                'amount_paid', 'transaction_date'
            ];
            
            foreach ($required as $field) {
                if (empty($data[$field])) {
                    throw new Exception("Missing required field: $field");
                }
            }
            
            // Start transaction
            $pdo->beginTransaction();
            
            try {
                // Insert payment transaction
                $query = "
                    INSERT INTO payment_transactions (
                        type, supplier_id, product_id,
                        quantity, amount_paid, transaction_date,
                        status, notes, bank_account, reference_number
                    ) VALUES (
                        :type, :supplier_id, :product_id,
                        :quantity, :amount_paid, :transaction_date,
                        :status, :notes, :bank_account, :reference_number
                    )
                ";
                
                $stmt = $pdo->prepare($query);
                $stmt->execute([
                    'type' => $data['type'],
                    'supplier_id' => $data['supplier_id'],
                    'product_id' => $data['product_id'],
                    'quantity' => $data['quantity'],
                    'amount_paid' => $data['amount_paid'],
                    'transaction_date' => $data['transaction_date'],
                    'status' => $data['status'] ?? 'pending',
                    'notes' => $data['notes'] ?? null,
                    'bank_account' => $data['bank_account'] ?? null,
                    'reference_number' => $data['reference_number'] ?? null
                ]);
                
                $transactionId = $pdo->lastInsertId();
                
                // Update product quantity
                $updateQuery = "
                    UPDATE products 
                    SET quantity = quantity + :quantity
                    WHERE id = :product_id
                ";
                
                $updateStmt = $pdo->prepare($updateQuery);
                $updateStmt->execute([
                    'quantity' => $data['quantity'],
                    'product_id' => $data['product_id']
                ]);
                
                // If it's a cash bank transaction, create account payable
                if ($data['type'] === 'cash_bank') {
                    $payableQuery = "
                        INSERT INTO account_payable (
                            supplier_id, invoice_number, amount,
                            due_date, status
                        ) VALUES (
                            :supplier_id, :invoice_number, :amount,
                            :due_date, 'pending'
                        )
                    ";
                    
                    $payableStmt = $pdo->prepare($payableQuery);
                    $payableStmt->execute([
                        'supplier_id' => $data['supplier_id'],
                        'invoice_number' => 'INV-' . $transactionId,
                        'amount' => $data['amount_paid'],
                        'due_date' => date('Y-m-d', strtotime('+30 days'))
                    ]);
                }
                
                $pdo->commit();
                
                echo json_encode([
                    'status' => 'success',
                    'id' => $transactionId
                ]);
                
            } catch (Exception $e) {
                $pdo->rollBack();
                throw $e;
            }
            break;

        case 'PUT':
            // Update existing transaction
            if (!isset($_GET['id'])) {
                throw new Exception('Transaction ID is required for updates');
            }

            $data = json_decode(file_get_contents('php://input'), true);
            if (!$data) {
                throw new Exception('Invalid JSON data');
            }

            // Validate the data
            $errors = validatePaymentData($data);
            if (!empty($errors)) {
                throw new Exception('Validation failed: ' . implode(', ', $errors));
            }

            // Calculate total amount and determine status
            $stmt = $pdo->prepare("SELECT purchase_price FROM products WHERE id = ?");
            $stmt->execute([$data['product_id']]);
            $product = $stmt->fetch();
            
            if (!$product) {
                throw new Exception('Product not found');
            }

            $totalAmount = $product['purchase_price'] * $data['quantity'];
            if ($data['amount_paid'] >= $totalAmount) {
                $data['status'] = 'paid';
            } elseif ($data['amount_paid'] > 0) {
                $data['status'] = 'partial';
            } else {
                $data['status'] = 'pending';
            }

            // Update the transaction
            $query = "UPDATE payment_transactions SET 
                supplier_id = :supplier_id,
                product_id = :product_id,
                quantity = :quantity,
                amount_paid = :amount_paid,
                transaction_date = :transaction_date,
                status = :status,
                notes = :notes";

            // Add bank-specific fields if it's a bank transaction
            if ($data['type'] === 'cash_bank') {
                $query .= ",
                    bank_account = :bank_account,
                    reference_number = :reference_number";
            }

            $query .= " WHERE id = :id";

            $stmt = $pdo->prepare($query);
            
            $params = [
                'id' => $_GET['id'],
                'supplier_id' => $data['supplier_id'],
                'product_id' => $data['product_id'],
                'quantity' => $data['quantity'],
                'amount_paid' => $data['amount_paid'],
                'transaction_date' => $data['transaction_date'],
                'status' => $data['status'],
                'notes' => $data['notes'] ?? null
            ];

            if ($data['type'] === 'cash_bank') {
                $params['bank_account'] = $data['bank_account'];
                $params['reference_number'] = $data['reference_number'];
            }

            $stmt->execute($params);

            if ($stmt->rowCount() > 0) {
                echo json_encode([
                    'status' => 'success',
                    'message' => 'Transaction updated successfully'
                ]);
            } else {
                throw new Exception('No changes were made to the transaction');
            }
            break;

        case 'DELETE':
            // Delete transaction
            if (!isset($_GET['id'])) {
                throw new Exception('Transaction ID is required');
            }
            
            // Start transaction
            $pdo->beginTransaction();
            
            try {
                // Get transaction data
                $query = "
                    SELECT quantity, product_id, supplier_id, type
                    FROM payment_transactions
                    WHERE id = :id
                ";
                
                $stmt = $pdo->prepare($query);
                $stmt->execute(['id' => $_GET['id']]);
                $transaction = $stmt->fetch();
                
                if (!$transaction) {
                    throw new Exception('Transaction not found');
                }
                
                // Delete transaction
                $deleteQuery = "DELETE FROM payment_transactions WHERE id = :id";
                $deleteStmt = $pdo->prepare($deleteQuery);
                $deleteStmt->execute(['id' => $_GET['id']]);
                
                // Update product quantity
                $updateQuery = "
                    UPDATE products 
                    SET quantity = quantity - :quantity
                    WHERE id = :product_id
                ";
                
                $updateStmt = $pdo->prepare($updateQuery);
                $updateStmt->execute([
                    'quantity' => $transaction['quantity'],
                    'product_id' => $transaction['product_id']
                ]);
                
                // Delete account payable if it's a cash bank transaction
                if ($transaction['type'] === 'cash_bank') {
                    $payableQuery = "
                        DELETE FROM account_payable 
                        WHERE supplier_id = :supplier_id 
                        AND invoice_number = :invoice_number
                    ";
                    
                    $payableStmt = $pdo->prepare($payableQuery);
                    $payableStmt->execute([
                        'supplier_id' => $transaction['supplier_id'],
                        'invoice_number' => 'INV-' . $_GET['id']
                    ]);
                }
                
                $pdo->commit();
                
                echo json_encode(['status' => 'success']);
                
            } catch (Exception $e) {
                $pdo->rollBack();
                throw $e;
            }
            break;

        default:
            throw new Exception('Unsupported request method');
    }
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Database error: ' . $e->getMessage()
    ]);
}
?> 