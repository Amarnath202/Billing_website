<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', '../logs/inventory_api.log');

// Allow CORS
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../config/db.php';
header('Content-Type: application/json');

try {
    $action = $_GET['action'] ?? '';
    error_log("Inventory API called with action: " . $action);

    switch ($action) {
        case 'list':
            try {
                $stmt = $pdo->query("
                    SELECT id, item_code, name, brand, description, 
                           purchase_price, sales_price, quantity 
                    FROM products 
                    ORDER BY name ASC
                ");
                $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
                error_log("Found " . count($products) . " products");
                
                echo json_encode([
                    'status' => 'success',
                    'data' => $products,
                    'message' => count($products) . ' products found'
                ]);
            } catch (PDOException $e) {
                error_log("Database error in list action: " . $e->getMessage());
                throw new Exception("Failed to fetch products");
            }
            break;

        case 'add':
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!$data) {
                throw new Exception('Invalid input data');
            }

            $stmt = $pdo->prepare("
                INSERT INTO products (item_code, name, brand, description, purchase_price, sales_price, quantity)
                VALUES (:item_code, :name, :brand, :description, :purchase_price, :sales_price, :quantity)
            ");
            
            $stmt->execute([
                'item_code' => $data['item_code'],
                'name' => $data['name'],
                'brand' => $data['brand'],
                'description' => $data['description'],
                'purchase_price' => $data['purchase_price'],
                'sales_price' => $data['sales_price'],
                'quantity' => $data['quantity']
            ]);
            
            echo json_encode(['status' => 'success', 'message' => 'Product added successfully']);
            break;

        case 'update':
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!$data || !isset($data['id'])) {
                throw new Exception('Invalid input data');
            }

            $stmt = $pdo->prepare("
                UPDATE products 
                SET item_code = :item_code,
                    name = :name,
                    brand = :brand,
                    description = :description,
                    purchase_price = :purchase_price,
                    sales_price = :sales_price,
                    quantity = :quantity
                WHERE id = :id
            ");
            
            $stmt->execute([
                'id' => $data['id'],
                'item_code' => $data['item_code'],
                'name' => $data['name'],
                'brand' => $data['brand'],
                'description' => $data['description'],
                'purchase_price' => $data['purchase_price'],
                'sales_price' => $data['sales_price'],
                'quantity' => $data['quantity']
            ]);
            
            echo json_encode(['status' => 'success', 'message' => 'Product updated successfully']);
            break;

        case 'delete':
            $id = $_GET['id'] ?? null;
            
            if (!$id) {
                throw new Exception('Product ID is required');
            }

            $stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
            $stmt->execute([$id]);
            
            echo json_encode(['status' => 'success', 'message' => 'Product deleted successfully']);
            break;

        case 'get':
            $id = $_GET['id'] ?? null;
            
            if (!$id) {
                throw new Exception('Product ID is required');
            }

            $stmt = $pdo->prepare("
                SELECT id, item_code, name, brand, description, 
                       purchase_price, sales_price, quantity 
                FROM products 
                WHERE id = ?
            ");
            $stmt->execute([$id]);
            $product = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$product) {
                throw new Exception('Product not found');
            }

            echo json_encode(['status' => 'success', 'data' => $product]);
            break;

        case 'search':
            $query = $_GET['query'] ?? '';
            
            $stmt = $pdo->prepare("
                SELECT id, item_code, name, brand, description, 
                       purchase_price, sales_price, quantity 
                FROM products 
                WHERE name LIKE ? OR item_code LIKE ? OR brand LIKE ?
                ORDER BY name ASC
            ");
            
            $searchTerm = "%{$query}%";
            $stmt->execute([$searchTerm, $searchTerm, $searchTerm]);
            $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            echo json_encode(['status' => 'success', 'data' => $products]);
            break;

        default:
            throw new Exception('Invalid action');
    }
} catch (Exception $e) {
    error_log("API Error: " . $e->getMessage());
    http_response_code(400);
    echo json_encode([
        'status' => 'error',
        'message' => $e->getMessage()
    ]);
}