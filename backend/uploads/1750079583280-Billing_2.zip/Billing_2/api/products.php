<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once '../config/db.php';

try {
    $conn = getDBConnection();
    
    if (!$conn) {
        throw new Exception('Database connection failed');
    }
    
    // Log request details
    error_log("Products API Request: " . $_SERVER['REQUEST_METHOD'] . " " . $_SERVER['REQUEST_URI']);
    
    // Handle GET request
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        if (isset($_GET['check_item_code'])) {
            // Check if item code exists
            $stmt = $conn->prepare("SELECT id FROM products WHERE item_code = ?");
            $stmt->bind_param("s", $_GET['check_item_code']);
            $stmt->execute();
            $result = $stmt->get_result();
            
            echo json_encode([
                'success' => !$result->fetch_assoc(), // success is true if item code doesn't exist
                'message' => $result->fetch_assoc() ? 'Item code already exists' : 'Item code is available'
            ]);
        }
        else if (isset($_GET['id'])) {
            // Get single product
            $stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
            $stmt->bind_param("i", $_GET['id']);
            $stmt->execute();
            $result = $stmt->get_result();
            $product = $result->fetch_assoc();
            
            if ($product) {
                echo json_encode([
                    'success' => true,
                    'product' => $product
                ]);
            } else {
                throw new Exception('Product not found');
            }
        } else {
            // Get all products
            $result = $conn->query("SELECT * FROM products ORDER BY name");
            $products = [];
            while ($row = $result->fetch_assoc()) {
                $products[] = $row;
            }
            
            echo json_encode([
                'success' => true,
                'products' => $products
            ]);
        }
    }
    
    // Handle POST request
    else if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $data = json_decode(file_get_contents('php://input'), true);
        
        // Validate required fields
        $required_fields = ['item_code', 'name', 'brand', 'purchase_price', 'sales_price'];
        foreach ($required_fields as $field) {
            if (!isset($data[$field]) || trim($data[$field]) === '') {
                throw new Exception("Missing or empty required field: $field");
            }
        }

        // Validate numeric fields
        if (!is_numeric($data['purchase_price']) || $data['purchase_price'] <= 0) {
            throw new Exception("Invalid purchase price: must be a positive number");
        }

        if (!is_numeric($data['sales_price']) || $data['sales_price'] <= 0) {
            throw new Exception("Invalid sales price: must be a positive number");
        }

        if (isset($data['quantity']) && (!is_numeric($data['quantity']) || $data['quantity'] < 0)) {
            throw new Exception("Invalid quantity: must be a non-negative number");
        }

        // Check for duplicate item code
        $stmt = $conn->prepare("SELECT id FROM products WHERE item_code = ? AND id != ?");
        $id = $data['id'] ?? 0;
        $stmt->bind_param("si", $data['item_code'], $id);
        $stmt->execute();
        if ($stmt->get_result()->fetch_assoc()) {
            throw new Exception("Item code already exists");
        }
        
        $stmt = $conn->prepare("
            INSERT INTO products (item_code, name, brand, description, purchase_price, sales_price, quantity)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        
        $description = $data['description'] ?? '';
        $quantity = $data['quantity'] ?? 0;
        
        $stmt->bind_param(
            "ssssddi",
            $data['item_code'],
            $data['name'],
            $data['brand'],
            $description,
            $data['purchase_price'],
            $data['sales_price'],
            $quantity
        );
        
        if ($stmt->execute()) {
            echo json_encode([
                'success' => true,
                'message' => 'Product added successfully',
                'product_id' => $conn->insert_id
            ]);
        } else {
            throw new Exception('Failed to add product: ' . $stmt->error);
        }
    }
    
    // Handle PUT request
    else if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($data['id'])) {
            throw new Exception('Product ID is required');
        }
        
        // Check if product exists
        $stmt = $conn->prepare("SELECT id FROM products WHERE id = ?");
        $stmt->bind_param("i", $data['id']);
        $stmt->execute();
        if (!$stmt->get_result()->fetch_assoc()) {
            throw new Exception('Product not found');
        }
        
        $updates = [];
        $types = "";
        $values = [];
        
        $fields = [
            'item_code' => 's',
            'name' => 's',
            'brand' => 's',
            'description' => 's',
            'purchase_price' => 'd',
            'sales_price' => 'd',
            'quantity' => 'i'
        ];
        
        foreach ($fields as $field => $type) {
            if (isset($data[$field])) {
                $updates[] = "$field = ?";
                $types .= $type;
                $values[] = $data[$field];
            }
        }
        
        if (empty($updates)) {
            throw new Exception('No fields to update');
        }
        
        $types .= "i"; // for the WHERE id = ? clause
        $values[] = $data['id'];
        
        $query = "UPDATE products SET " . implode(", ", $updates) . " WHERE id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param($types, ...$values);
        
        if ($stmt->execute()) {
            echo json_encode([
                'success' => true,
                'message' => 'Product updated successfully'
            ]);
        } else {
            throw new Exception('Failed to update product');
        }
    }
    
    // Handle DELETE request
    else if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
        if (!isset($_GET['id'])) {
            throw new Exception('Product ID is required');
        }

        $product_id = $_GET['id'];
        
        // Start transaction
        $conn->begin_transaction();
        
        try {
            // Check if product exists
            $stmt = $conn->prepare("SELECT id, name FROM products WHERE id = ?");
            $stmt->bind_param("i", $product_id);
            $stmt->execute();
            $product = $stmt->get_result()->fetch_assoc();
            if (!$product) {
                throw new Exception('Product not found');
            }
            
            // Check for related records in sales
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM sales WHERE product_id = ?");
            $stmt->bind_param("i", $product_id);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            if ($result['count'] > 0) {
                throw new Exception("Cannot delete product '{$product['name']}': It has {$result['count']} associated sales records");
            }
            
            // Check for related records in payment_transactions
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM payment_transactions WHERE product_id = ?");
            $stmt->bind_param("i", $product_id);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            if ($result['count'] > 0) {
                throw new Exception("Cannot delete product '{$product['name']}': It has {$result['count']} associated payment records");
            }
            
            // If no related records exist, delete the product
            $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
            $stmt->bind_param("i", $product_id);
            
            if ($stmt->execute()) {
                $conn->commit();
                echo json_encode([
                    'success' => true,
                    'message' => "Product '{$product['name']}' deleted successfully"
                ]);
            } else {
                throw new Exception("Failed to delete product '{$product['name']}'");
            }
        } catch (Exception $e) {
            $conn->rollback();
            throw $e;
        }
    }
    
} catch (Exception $e) {
    error_log("Products API Error: " . $e->getMessage());
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
} 