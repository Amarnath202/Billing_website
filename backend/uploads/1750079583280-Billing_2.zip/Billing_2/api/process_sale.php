<?php
// Prevent any output before JSON response
error_reporting(E_ALL);
ini_set('display_errors', 0);

require_once '../config/db.php';

header('Content-Type: application/json');

// Only allow POST requests
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
    }

// Get POST data
    $data = json_decode(file_get_contents('php://input'), true);
    
if (!$data || !isset($data['items']) || !isset($data['total'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Invalid request data']);
    exit;
}

try {
    $pdo->beginTransaction();

    // Insert into sales table
    $stmt = $pdo->prepare("
        INSERT INTO sales (
            bill_number,
            total_amount,
            sale_date
        ) VALUES (?, ?, NOW())
    ");
    
    $stmt->execute([
        $data['bill_number'],
        $data['total']
    ]);
    
    $saleId = $pdo->lastInsertId();

    // Insert sale items and update product quantities
    foreach ($data['items'] as $item) {
        // First check if enough stock is available
        $checkStock = $pdo->prepare("SELECT quantity FROM products WHERE id = ? AND quantity >= ?");
        $checkStock->execute([$item['id'], $item['quantity']]);
        
        if (!$checkStock->fetch()) {
            throw new Exception("Insufficient stock for product: " . $item['name']);
        }

        // Insert sale item
        $stmt = $pdo->prepare("
            INSERT INTO sales (
                product_id, 
                quantity, 
                unit_price, 
                total_amount,
                sale_date
            ) VALUES (?, ?, ?, ?, NOW())
        ");

        $stmt->execute([
            $item['id'],
            $item['quantity'],
            $item['price'],
            $item['total']
        ]);

        // Update product quantity
        $stmt = $pdo->prepare("
            UPDATE products 
            SET quantity = quantity - ? 
            WHERE id = ?
        ");
        
        $stmt->execute([
            $item['quantity'],
            $item['id']
        ]);
    }

    $pdo->commit();
    echo json_encode([
        'success' => true,
        'message' => 'Sale processed successfully',
        'sale_id' => $saleId,
        'bill_number' => $data['bill_number']
    ]);

} catch (Exception $e) {
    if (isset($pdo)) {
        $pdo->rollBack();
    }
    error_log("Sale processing error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Error processing sale: ' . $e->getMessage()]);
}
?> 