<?php
require_once '../config/db.php';
header('Content-Type: application/json');

try {
    $method = $_SERVER['REQUEST_METHOD'];

    switch ($method) {
        case 'GET':
            // List receivables
            $query = "
                SELECT 
                    ar.*,
                    s.name as supplier_name,
                    DATE_FORMAT(ar.due_date, '%Y-%m-%d') as due_date,
                    DATE_FORMAT(ar.payment_date, '%Y-%m-%d') as payment_date,
                    DATE_FORMAT(ar.created_at, '%Y-%m-%d %H:%i:%s') as created_at
                FROM account_receivable ar
                JOIN supplier s ON ar.supplier_id = s.id
                ORDER BY ar.due_date ASC
            ";
            
            $stmt = $pdo->prepare($query);
            $stmt->execute();
            $receivables = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Update status based on due date
            foreach ($receivables as &$receivable) {
                if ($receivable['status'] === 'pending') {
                    $dueDate = new DateTime($receivable['due_date']);
                    $today = new DateTime();
                    if ($dueDate < $today) {
                        // Update status to overdue in database
                        $updateQuery = "UPDATE account_receivable SET status = 'overdue' WHERE id = ?";
                        $updateStmt = $pdo->prepare($updateQuery);
                        $updateStmt->execute([$receivable['id']]);
                        $receivable['status'] = 'overdue';
                    }
                }
                // Format amount to 2 decimal places
                $receivable['amount'] = number_format((float)$receivable['amount'], 2, '.', '');
            }

            echo json_encode([
                'success' => true,
                'data' => $receivables
            ]);
            break;

        case 'POST':
            // Add new receivable
            $data = json_decode(file_get_contents('php://input'), true);
            
            // Validate required fields
            $required = ['supplier_id', 'invoice_number', 'amount', 'due_date'];
            foreach ($required as $field) {
                if (!isset($data[$field]) || empty($data[$field])) {
                    throw new Exception("Missing required field: $field");
                }
            }

            // Validate and format amount
            if (!is_numeric($data['amount'])) {
                throw new Exception("Invalid amount value");
            }
            $data['amount'] = number_format((float)$data['amount'], 2, '.', '');

            // Validate dates
            if (!DateTime::createFromFormat('Y-m-d', $data['due_date'])) {
                throw new Exception("Invalid due date format");
            }
            if (isset($data['payment_date']) && $data['payment_date'] && !DateTime::createFromFormat('Y-m-d', $data['payment_date'])) {
                throw new Exception("Invalid payment date format");
            }

            $query = "
                INSERT INTO account_receivable (
                    supplier_id, invoice_number, description, 
                    amount, due_date, payment_date, status
                ) VALUES (
                    :supplier_id, :invoice_number, :description,
                    :amount, :due_date, :payment_date, :status
                )
            ";

            $stmt = $pdo->prepare($query);
            $stmt->execute([
                'supplier_id' => $data['supplier_id'],
                'invoice_number' => $data['invoice_number'],
                'description' => $data['description'] ?? null,
                'amount' => $data['amount'],
                'due_date' => $data['due_date'],
                'payment_date' => $data['payment_date'] ?? null,
                'status' => $data['status'] ?? 'pending'
            ]);

            echo json_encode([
                'success' => true,
                'message' => 'Receivable added successfully'
            ]);
            break;

        case 'PUT':
            // Update receivable
            $data = json_decode(file_get_contents('php://input'), true);
            
            if (!isset($data['id'])) {
                throw new Exception('Missing receivable ID');
            }

            // Validate and format amount if provided
            if (isset($data['amount'])) {
                if (!is_numeric($data['amount'])) {
                    throw new Exception("Invalid amount value");
                }
                $data['amount'] = number_format((float)$data['amount'], 2, '.', '');
            }

            // Validate dates if provided
            if (isset($data['due_date']) && !DateTime::createFromFormat('Y-m-d', $data['due_date'])) {
                throw new Exception("Invalid due date format");
            }
            if (isset($data['payment_date']) && $data['payment_date'] && !DateTime::createFromFormat('Y-m-d', $data['payment_date'])) {
                throw new Exception("Invalid payment date format");
            }

            $query = "
                UPDATE account_receivable SET
                    supplier_id = :supplier_id,
                    invoice_number = :invoice_number,
                    description = :description,
                    amount = :amount,
                    due_date = :due_date,
                    payment_date = :payment_date,
                    status = :status
                WHERE id = :id
            ";

            $stmt = $pdo->prepare($query);
            $stmt->execute([
                'id' => $data['id'],
                'supplier_id' => $data['supplier_id'],
                'invoice_number' => $data['invoice_number'],
                'description' => $data['description'] ?? null,
                'amount' => $data['amount'],
                'due_date' => $data['due_date'],
                'payment_date' => $data['payment_date'] ?? null,
                'status' => $data['status']
            ]);

            echo json_encode([
                'success' => true,
                'message' => 'Receivable updated successfully'
            ]);
            break;

        case 'DELETE':
            // Delete receivable
            $id = $_GET['id'] ?? null;
            if (!$id) {
                throw new Exception('Missing receivable ID');
            }

            $query = "DELETE FROM account_receivable WHERE id = ?";
            $stmt = $pdo->prepare($query);
            $stmt->execute([$id]);

            echo json_encode([
                'success' => true,
                'message' => 'Receivable deleted successfully'
            ]);
            break;

        default:
            throw new Exception('Method not allowed');
    }

} catch (Exception $e) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?> 