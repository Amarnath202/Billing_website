<?php
$pageTitle = "Product Management";
$pageScripts = [
    "js/products.js"
];
include 'includes/header.php';
include 'includes/sidebar.php';
require_once 'config/db.php';

// Fetch products from database
try {
    $stmt = $pdo->query("SELECT * FROM products ORDER BY id DESC");
    $products = $stmt->fetchAll();
} catch(PDOException $e) {
    $products = [];
    error_log("Error fetching products: " . $e->getMessage());
}
?>

<main class="main-content">
    <div class="section-header">
        <h2>Product Management</h2>
        <div class="search-container">
            <input type="text" id="productSearch" placeholder="Search products by name, code, or brand..." class="search-input">
            <button id="showAddProductForm" class="add-product-btn">
                <span class="icon">➕</span> Add New Product
            </button>
        </div>
    </div>

    <!-- Products Table -->
    <div class="table-container">
        <table id="productsTable">
            <thead>
                <tr>
                    <th>Item Code</th>
                    <th>Name</th>
                    <th>Brand</th>
                    <th>Description</th>    
                    <th class="price-column">Purchase Price</th>
                    <th class="price-column">Selling Price</th> 
                    <th>Stock</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($products as $product): ?>
                <tr>
                    <td><?php echo htmlspecialchars($product['item_code']); ?></td>
                    <td><?php echo htmlspecialchars($product['name']); ?></td>
                    <td><?php echo htmlspecialchars($product['brand']); ?></td>
                    <td><?php echo htmlspecialchars($product['description']); ?></td>
                    <td class="price-column">₹<?php echo number_format($product['purchase_price'], 2); ?></td>
                    <td class="price-column">₹<?php echo number_format($product['sales_price'], 2); ?></td>
                    <td class="stock-column <?php 
                        $stock = $product['quantity'];
                        if ($stock > 100) echo 'stock-high';
                        else if ($stock > 20) echo 'stock-medium';
                        else echo 'stock-low';
                    ?>"><?php echo htmlspecialchars($stock); ?></td>
                    <td>
                        <div class="action-buttons">
                            <button onclick="editProduct(<?php echo $product['id']; ?>)" class="action-btn edit-btn" title="Edit Product">
                                <span class="icon">✏️</span>
                            </button>
                            <button onclick="deleteProduct(<?php echo $product['id']; ?>)" class="action-btn delete-btn" title="Delete Product">
                                <span class="icon">🗑️</span>
                            </button>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <!-- Add/Edit Product Modal -->
    <div id="productFormModal" class="modal">
        <div class="modal-content">
            <form id="addProductForm" class="product-form">
                <button type="button" class="close" onclick="closeProductForm()"></button>
                <div class="modal-header">
                    <h3 id="modalTitle">Add New Product</h3>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="productId" value="">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="itemCode">Item Code</label>
                            <input type="text" id="itemCode" placeholder="Enter item code" required>
                        </div>
                        <div class="form-group">
                            <label for="productName">Product Name</label>
                            <input type="text" id="productName" placeholder="Enter product name" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="productBrand">Brand</label>
                            <input type="text" id="productBrand" placeholder="Enter brand name" required>
                        </div>
                        <div class="form-group">
                            <label for="productQuantity">Stock Quantity</label>
                            <input type="number" id="productQuantity" min="0" placeholder="Enter stock quantity" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label for="purchasePrice">Purchase Price (₹)</label>
                            <input type="number" id="purchasePrice" step="0.01" min="0" placeholder="Enter purchase price" required>
                        </div>
                        <div class="form-group">
                            <label for="salesPrice">Selling Price (₹)</label>
                            <input type="number" id="salesPrice" step="0.01" min="0" placeholder="Enter selling price" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-group full-width">
                            <label for="productDescription">Description</label>
                            <textarea id="productDescription" placeholder="Enter product description" rows="3"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="cancel-btn" onclick="closeProductForm()">Cancel</button>
                    <button type="submit" class="save-btn" id="submitButton">Add Product</button>
                </div>
            </form>
        </div>
    </div>
</main>

<?php include 'includes/footer.php'; ?>